-- ============================================================================
-- NexPOS Fleet & Operations Platform - PostgreSQL Schema & Supabase Migration
-- Version: 1.0.0
-- Description: Centralized POS fleet, merchant hierarchy, transactional records,
--              temporal assignments, operational alerts, and immutable audit logs.
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ----------------------------------------------------------------------------
-- ENUMS
-- ----------------------------------------------------------------------------
DO $$ BEGIN
    CREATE TYPE user_role_enum AS ENUM ('super_admin', 'admin', 'operator', 'viewer');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE company_status_enum AS ENUM ('active', 'inactive', 'archived');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE terminal_status_enum AS ENUM ('active', 'inactive', 'maintenance', 'lost', 'retired');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE transaction_type_enum AS ENUM ('sale', 'refund', 'void', 'adjustment', 'other');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE transaction_status_enum AS ENUM ('pending', 'completed', 'failed', 'cancelled', 'under_review');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE alert_severity_enum AS ENUM ('critical', 'warning', 'info');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE alert_status_enum AS ENUM ('open', 'acknowledged', 'resolved');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- ----------------------------------------------------------------------------
-- 1. COMPANIES
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS companies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    legal_name VARCHAR(255) NOT NULL,
    registration_number VARCHAR(100) UNIQUE NOT NULL,
    contact_name VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(50) NOT NULL,
    contact_email VARCHAR(255) NOT NULL,
    status company_status_enum NOT NULL DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 2. PROFILES (Users & Role-Based Access)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    auth_user_id UUID UNIQUE,
    full_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone VARCHAR(50),
    role user_role_enum NOT NULL DEFAULT 'operator',
    avatar_url TEXT,
    company_id UUID REFERENCES companies(id) ON DELETE SET NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 3. LOCATIONS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS locations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    city VARCHAR(100) NOT NULL,
    area VARCHAR(100) NOT NULL,
    latitude DECIMAL(10, 8),
    longitude DECIMAL(11, 8),
    contact_name VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(50) NOT NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 4. MERCHANTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS merchants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    merchant_name VARCHAR(255) NOT NULL,
    merchant_identifier VARCHAR(100) UNIQUE NOT NULL, -- MID
    business_category VARCHAR(150) NOT NULL,
    contact_name VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(50) NOT NULL,
    location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NOW()
);

-- ----------------------------------------------------------------------------
-- 5. POS TERMINALS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS terminals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    merchant_id UUID REFERENCES merchants(id) ON DELETE SET NULL,
    terminal_name VARCHAR(255) NOT NULL,
    terminal_identifier VARCHAR(100) UNIQUE NOT NULL, -- TID
    terminal_model VARCHAR(150) NOT NULL,
    provider VARCHAR(100) NOT NULL,
    serial_number VARCHAR(100) UNIQUE NOT NULL, -- Serial Number
    owner_name VARCHAR(255) NOT NULL,
    assigned_user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    location_id UUID REFERENCES locations(id) ON DELETE SET NULL,
    status terminal_status_enum NOT NULL DEFAULT 'active',
    installation_date DATE NOT NULL DEFAULT CURRENT_DATE,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6. TERMINAL ASSIGNMENT HISTORY (Temporal Auditing)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    terminal_id UUID NOT NULL REFERENCES terminals(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    assigned_by UUID NOT NULL REFERENCES profiles(id),
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    unassigned_at TIMESTAMPTZ,
    status VARCHAR(50) NOT NULL DEFAULT 'active',
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 7. TRANSACTION RECORDS
-- Note: PCI compliance enforced. No raw PAN, CVV, or PINs stored.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS transaction_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    merchant_id UUID NOT NULL REFERENCES merchants(id) ON DELETE CASCADE,
    terminal_id UUID NOT NULL REFERENCES terminals(id) ON DELETE CASCADE,
    operator_id UUID NOT NULL REFERENCES profiles(id) ON DELETE SET NULL,
    external_reference VARCHAR(150) UNIQUE NOT NULL, -- Duplicate check enforced
    masked_reference VARCHAR(50), -- e.g. "VISA ···· 4242"
    transaction_type transaction_type_enum NOT NULL DEFAULT 'sale',
    amount DECIMAL(14, 2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(10) NOT NULL DEFAULT 'EGP',
    status transaction_status_enum NOT NULL DEFAULT 'completed',
    transaction_time TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    notes TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 8. OPERATIONAL ACTIVITY FEED
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type VARCHAR(100) NOT NULL,
    terminal_id UUID REFERENCES terminals(id) ON DELETE SET NULL,
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 9. OPERATIONAL ALERTS
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS alerts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    severity alert_severity_enum NOT NULL DEFAULT 'warning',
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    related_entity_type VARCHAR(50) NOT NULL,
    related_entity_id VARCHAR(100) NOT NULL,
    related_entity_label VARCHAR(255) NOT NULL,
    status alert_status_enum NOT NULL DEFAULT 'open',
    acknowledged_by VARCHAR(255),
    acknowledged_at TIMESTAMPTZ,
    resolved_by VARCHAR(255),
    resolved_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 10. AUDIT LOGS (Strictly Immutable)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL,
    user_name VARCHAR(255) NOT NULL,
    user_email VARCHAR(255) NOT NULL,
    user_role user_role_enum NOT NULL,
    action VARCHAR(100) NOT NULL,
    entity VARCHAR(100) NOT NULL,
    entity_id VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    ip_address VARCHAR(50),
    metadata JSONB DEFAULT '{}'::jsonb,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- PERFORMANCE INDEXES
-- ----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_companies_status ON companies(status);
CREATE INDEX IF NOT EXISTS idx_merchants_company_id ON merchants(company_id);
CREATE INDEX IF NOT EXISTS idx_terminals_company_id ON terminals(company_id);
CREATE INDEX IF NOT EXISTS idx_terminals_merchant_id ON terminals(merchant_id);
CREATE INDEX IF NOT EXISTS idx_terminals_status ON terminals(status);
CREATE INDEX IF NOT EXISTS idx_terminals_location_id ON terminals(location_id);
CREATE INDEX IF NOT EXISTS idx_terminals_assigned_user_id ON terminals(assigned_user_id);
CREATE INDEX IF NOT EXISTS idx_terminals_tid ON terminals(terminal_identifier);
CREATE INDEX IF NOT EXISTS idx_assignments_terminal_id ON assignments(terminal_id);
CREATE INDEX IF NOT EXISTS idx_tx_records_company_id ON transaction_records(company_id);
CREATE INDEX IF NOT EXISTS idx_tx_records_merchant_id ON transaction_records(merchant_id);
CREATE INDEX IF NOT EXISTS idx_tx_records_terminal_id ON transaction_records(terminal_id);
CREATE INDEX IF NOT EXISTS idx_tx_records_tx_time ON transaction_records(transaction_time);
CREATE INDEX IF NOT EXISTS idx_tx_records_ext_ref ON transaction_records(external_reference);
CREATE INDEX IF NOT EXISTS idx_activity_company_id ON activity(company_id);
CREATE INDEX IF NOT EXISTS idx_activity_terminal_id ON activity(terminal_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at DESC);

-- ----------------------------------------------------------------------------
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ----------------------------------------------------------------------------
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE merchants ENABLE ROW LEVEL SECURITY;
ALTER TABLE locations ENABLE ROW LEVEL SECURITY;
ALTER TABLE terminals ENABLE ROW LEVEL SECURITY;
ALTER TABLE assignments ENABLE ROW LEVEL SECURITY;
ALTER TABLE transaction_records ENABLE ROW LEVEL SECURITY;
ALTER TABLE activity ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

-- Helper security function: get current profile role
CREATE OR REPLACE FUNCTION get_current_user_role()
RETURNS user_role_enum AS $$
  SELECT role FROM profiles WHERE auth_user_id = auth.uid() LIMIT 1;
$$ LANGUAGE sql STABLE SECURITY DEFINER;

-- Super Admin has full unrestricted access
CREATE POLICY super_admin_all_companies ON companies FOR ALL USING (get_current_user_role() = 'super_admin');
CREATE POLICY super_admin_all_terminals ON terminals FOR ALL USING (get_current_user_role() = 'super_admin');
CREATE POLICY super_admin_all_transactions ON transaction_records FOR ALL USING (get_current_user_role() = 'super_admin');
CREATE POLICY super_admin_all_audit ON audit_logs FOR ALL USING (get_current_user_role() = 'super_admin');

-- Read-only policy for Viewers
CREATE POLICY viewer_select_terminals ON terminals FOR SELECT USING (true);
CREATE POLICY viewer_select_transactions ON transaction_records FOR SELECT USING (true);
CREATE POLICY viewer_select_companies ON companies FOR SELECT USING (true);

-- Operators can view assigned terminals & insert transactions
CREATE POLICY operator_read_assigned_terminals ON terminals FOR SELECT USING (
  assigned_user_id = (SELECT id FROM profiles WHERE auth_user_id = auth.uid() LIMIT 1)
  OR get_current_user_role() IN ('super_admin', 'admin')
);

CREATE POLICY operator_insert_transactions ON transaction_records FOR INSERT WITH CHECK (
  get_current_user_role() IN ('super_admin', 'admin', 'operator')
);

-- Audit logs cannot be edited or deleted by anyone via standard DML
CREATE POLICY audit_logs_read_only ON audit_logs FOR SELECT USING (
  get_current_user_role() IN ('super_admin', 'admin')
);
