-- ============================================================================
-- NexPOS Fleet & Operations Platform - Supabase Seed SQL
-- Realistic production-grade test dataset for companies, merchants, terminals,
-- locations, and operational history.
-- ============================================================================

INSERT INTO companies (id, name, legal_name, registration_number, contact_name, contact_phone, contact_email, status, notes)
VALUES
('b9e6e326-1111-4a1b-90f1-111111111111', 'ABC Retail Group', 'ABC Retail & Distribution S.A.E.', 'CR-9041284', 'Tarek Ibrahim', '+20 2 2450 1100', 'compliance@abcretail.com', 'active', 'National supermarket and apparel merchant network.'),
('b9e6e326-2222-4a1b-90f1-222222222222', 'Nile Electronics Co.', 'Nile Consumer Electronics LLC', 'CR-8820194', 'Farida Kamel', '+20 2 3345 8890', 'ops@nileelectronics.eg', 'active', 'Premium consumer electronics and accessories chain.'),
('b9e6e326-3333-4a1b-90f1-333333333333', 'Cairo Food Services', 'Cairo Modern Food Industries S.A.E.', 'CR-7719230', 'Hossam El-Din', '+20 2 2794 3311', 'pos.operations@cairofoods.com', 'active', 'QSR food court chain and cloud kitchens across Greater Cairo.'),
('b9e6e326-4444-4a1b-90f1-444444444444', 'Delta Furniture', 'Delta Wood & Home Living Ltd.', 'CR-6621901', 'Gamal Abdelrahman', '+20 3 4870 9900', 'accounts@deltafurniture.com', 'active', 'Showrooms in Alexandria, Cairo, and Tanta.')
ON CONFLICT (registration_number) DO NOTHING;

INSERT INTO locations (id, company_id, name, address, city, area, latitude, longitude, contact_name, contact_phone, status)
VALUES
('c1e6e326-1111-4a1b-90f1-111111111111', 'b9e6e326-1111-4a1b-90f1-111111111111', 'Downtown Flagship Branch', '14 Talaat Harb Street, Downtown', 'Cairo', 'Downtown', 30.0475, 31.2389, 'Samy Fathy', '+20 100 123 9090', 'active'),
('c1e6e326-2222-4a1b-90f1-222222222222', 'b9e6e326-1111-4a1b-90f1-111111111111', 'Nasr City Citystars Branch', 'Citystars Center, Level 1, Omar Ibn El-Khattab', 'Cairo', 'Nasr City', 30.0732, 31.3456, 'Mona Zaki', '+20 102 345 6789', 'active'),
('c1e6e326-3333-4a1b-90f1-333333333333', 'b9e6e326-2222-4a1b-90f1-222222222222', 'Mall of Arabia Tech Hub', 'Mall of Arabia, Gate 4, Juhayna Square', 'Giza', '6th of October', 30.0075, 30.9734, 'Khaled Samir', '+20 111 887 6655', 'active')
ON CONFLICT DO NOTHING;

INSERT INTO merchants (id, company_id, merchant_name, merchant_identifier, business_category, contact_name, contact_phone, location_id, status)
VALUES
('d1e6e326-1111-4a1b-90f1-111111111111', 'b9e6e326-1111-4a1b-90f1-111111111111', 'ABC Downtown Market', 'MID-1002931', 'Supermarket & Groceries', 'Samy Fathy', '+20 100 123 9090', 'c1e6e326-1111-4a1b-90f1-111111111111', 'active'),
('d1e6e326-2222-4a1b-90f1-222222222222', 'b9e6e326-2222-4a1b-90f1-222222222222', 'Nile Tech Mall of Arabia', 'MID-2005412', 'Consumer Electronics', 'Khaled Samir', '+20 111 887 6655', 'c1e6e326-3333-4a1b-90f1-333333333333', 'active')
ON CONFLICT (merchant_identifier) DO NOTHING;
