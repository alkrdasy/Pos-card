import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';
import { DEMO_USERS } from '../lib/constants';
import { storageService } from '../services/storageService';

interface AuthContextType {
  currentUser: UserProfile | null;
  allUsers: UserProfile[];
  isAuthenticated: boolean;
  switchPersona: (userId: string) => void;
  switchRole: (role: UserRole) => void;
  login: (email: string) => boolean;
  logout: () => void;
  can: (action: string) => boolean;
  activeCompanyFilter: string;
  setActiveCompanyFilter: (companyId: string) => void;
  isDarkMode: boolean;
  toggleDarkMode: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const CURRENT_USER_KEY = 'nexpos_current_user_v1';
const DARK_MODE_KEY = 'nexpos_dark_mode_v1';
const COMPANY_FILTER_KEY = 'nexpos_active_company_v1';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [activeCompanyFilter, setActiveCompanyFilterState] = useState<string>('all');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem(DARK_MODE_KEY);
      if (saved !== null) return saved === 'true';
      return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  // Sync users from storage service
  useEffect(() => {
    const refreshUsers = () => {
      const users = storageService.getUsers();
      setAllUsers(users);

      const savedUserId = localStorage.getItem(CURRENT_USER_KEY);
      if (savedUserId) {
        const found = users.find(u => u.id === savedUserId);
        if (found) {
          setCurrentUser(found);
          return;
        }
      }
      // Default to Super Admin (Karim Mansour)
      const defaultAdmin = users.find(u => u.role === 'super_admin') || users[0] || DEMO_USERS[0];
      setCurrentUser(defaultAdmin);
    };

    refreshUsers();
    const unsubscribe = storageService.subscribe(refreshUsers);
    return () => unsubscribe();
  }, []);

  // Sync dark mode class on HTML document
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
    localStorage.setItem(DARK_MODE_KEY, String(isDarkMode));
  }, [isDarkMode]);

  // Load saved company filter
  useEffect(() => {
    try {
      const saved = localStorage.getItem(COMPANY_FILTER_KEY);
      if (saved) setActiveCompanyFilterState(saved);
    } catch {
      // ignore
    }
  }, []);

  const setActiveCompanyFilter = (companyId: string) => {
    setActiveCompanyFilterState(companyId);
    localStorage.setItem(COMPANY_FILTER_KEY, companyId);
  };

  const toggleDarkMode = () => {
    setIsDarkMode(prev => !prev);
  };

  const switchPersona = (userId: string) => {
    const target = allUsers.find(u => u.id === userId);
    if (target) {
      setCurrentUser(target);
      localStorage.setItem(CURRENT_USER_KEY, target.id);
      storageService.logAudit({
        user_id: target.id,
        user_name: target.full_name,
        user_email: target.email,
        user_role: target.role,
        action: 'user_switched_persona',
        entity: 'auth',
        entity_id: target.id,
        description: `Switched active persona to ${target.full_name} (${target.role})`
      });
    }
  };

  const switchRole = (role: UserRole) => {
    const target = allUsers.find(u => u.role === role);
    if (target) {
      switchPersona(target.id);
    }
  };

  const login = (email: string): boolean => {
    const user = allUsers.find(u => u.email.toLowerCase() === email.trim().toLowerCase());
    if (user) {
      setCurrentUser(user);
      localStorage.setItem(CURRENT_USER_KEY, user.id);
      storageService.logAudit({
        user_id: user.id,
        user_name: user.full_name,
        user_email: user.email,
        user_role: user.role,
        action: 'user_login',
        entity: 'auth',
        entity_id: user.id,
        description: `${user.full_name} logged into NexPOS Operations platform`
      });
      return true;
    }
    return false;
  };

  const logout = () => {
    if (currentUser) {
      storageService.logAudit({
        user_id: currentUser.id,
        user_name: currentUser.full_name,
        user_email: currentUser.email,
        user_role: currentUser.role,
        action: 'user_logout',
        entity: 'auth',
        entity_id: currentUser.id,
        description: `${currentUser.full_name} logged out`
      });
    }
    setCurrentUser(null);
    localStorage.removeItem(CURRENT_USER_KEY);
  };

  /**
   * Server-authoritative capability check based on active role
   */
  const can = (action: string): boolean => {
    if (!currentUser) return false;
    const { role } = currentUser;

    switch (action) {
      case 'manage:companies':
        return role === 'super_admin';
      case 'edit:company':
        return role === 'super_admin' || role === 'admin';
      case 'manage:merchants':
      case 'manage:locations':
        return role === 'super_admin' || role === 'admin';
      case 'manage:terminals':
      case 'create:terminal':
        return role === 'super_admin' || role === 'admin';
      case 'assign:terminal':
        // Super admin and admin can assign/reassign terminals
        return role === 'super_admin' || role === 'admin';
      case 'record:transaction':
        // Operators and Admins can record authorized transactions
        return role === 'super_admin' || role === 'admin' || role === 'operator';
      case 'record:activity':
        return role === 'super_admin' || role === 'admin' || role === 'operator';
      case 'manage:alerts':
        return role === 'super_admin' || role === 'admin';
      case 'view:audit_logs':
        return role === 'super_admin' || role === 'admin';
      case 'manage:settings':
        return role === 'super_admin';
      case 'manage:users':
        return role === 'super_admin' || role === 'admin';
      case 'export:reports':
        return true; // All authenticated users can view/export allowed reports
      default:
        return false;
    }
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        allUsers,
        isAuthenticated: !!currentUser,
        switchPersona,
        switchRole,
        login,
        logout,
        can,
        activeCompanyFilter,
        setActiveCompanyFilter,
        isDarkMode,
        toggleDarkMode
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
