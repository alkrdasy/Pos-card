import React, { useState, useMemo } from 'react';
import {
  AlertTriangle,
  AlertOctagon,
  Info,
  CheckCircle2,
  Clock,
  Filter,
  Search,
  Check,
  ShieldAlert
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { formatDateTime, formatRelativeTime } from '../../lib/utils';
import { AlertItem, AlertSeverity, AlertStatus } from '../../types';

interface AlertCenterViewProps {
  onNavigateToEntity?: (entityType: string, entityId: string) => void;
}

export const AlertCenterView: React.FC<AlertCenterViewProps> = ({ onNavigateToEntity }) => {
  const { currentUser, can } = useAuth();
  const { success, error } = useToast();
  const alerts = storageService.getAlerts();

  const [selectedSeverity, setSelectedSeverity] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('open');
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = useMemo(() => {
    return alerts.filter(a => {
      if (selectedSeverity && a.severity !== selectedSeverity) return false;
      if (selectedStatus && a.status !== selectedStatus) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          a.title.toLowerCase().includes(q) ||
          a.description.toLowerCase().includes(q) ||
          a.related_entity_label.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [alerts, selectedSeverity, selectedStatus, searchQuery]);

  const handleAcknowledge = (alertId: string) => {
    if (!currentUser) return;
    try {
      storageService.acknowledgeAlert(alertId, currentUser);
      success('Alert Acknowledged', 'Operational alert marked as under investigation.');
    } catch (err: any) {
      error('Failed to acknowledge alert', err.message);
    }
  };

  const handleResolve = (alertId: string) => {
    if (!currentUser) return;
    try {
      storageService.resolveAlert(alertId, currentUser);
      success('Alert Resolved', 'Operational issue verified and closed.');
    } catch (err: any) {
      error('Failed to resolve alert', err.message);
    }
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Operational Alerts Center
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real-time fleet exception monitoring, duplicate reference warnings, and hardware health flags
          </p>
        </div>
      </div>

      {/* KPI status pills */}
      <div className="grid grid-cols-3 gap-3">
        <button
          type="button"
          onClick={() => setSelectedSeverity('critical')}
          className={`p-3.5 rounded-xl border text-left transition-colors ${
            selectedSeverity === 'critical'
              ? 'bg-rose-50 border-rose-300 dark:bg-rose-950/40 dark:border-rose-800'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-600 dark:text-rose-400">
            <AlertOctagon className="w-4 h-4" />
            <span>Critical Severity</span>
          </div>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {alerts.filter(a => a.severity === 'critical' && a.status === 'open').length} Open
          </p>
        </button>

        <button
          type="button"
          onClick={() => setSelectedSeverity('warning')}
          className={`p-3.5 rounded-xl border text-left transition-colors ${
            selectedSeverity === 'warning'
              ? 'bg-amber-50 border-amber-300 dark:bg-amber-950/40 dark:border-amber-800'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-600 dark:text-amber-400">
            <AlertTriangle className="w-4 h-4" />
            <span>Operational Warnings</span>
          </div>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {alerts.filter(a => a.severity === 'warning' && a.status === 'open').length} Open
          </p>
        </button>

        <button
          type="button"
          onClick={() => setSelectedSeverity('info')}
          className={`p-3.5 rounded-xl border text-left transition-colors ${
            selectedSeverity === 'info'
              ? 'bg-sky-50 border-sky-300 dark:bg-sky-950/40 dark:border-sky-800'
              : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800'
          }`}
        >
          <div className="flex items-center gap-1.5 text-xs font-semibold text-sky-600 dark:text-sky-400">
            <Info className="w-4 h-4" />
            <span>Maintenance & Info</span>
          </div>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {alerts.filter(a => a.severity === 'info' && a.status === 'open').length} Open
          </p>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search alerts by title, description, or target entity..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">All Statuses</option>
            <option value="open">Open (Unresolved)</option>
            <option value="acknowledged">Acknowledged</option>
            <option value="resolved">Resolved</option>
          </select>

          <select
            value={selectedSeverity}
            onChange={e => setSelectedSeverity(e.target.value)}
            className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">All Severities</option>
            <option value="critical">Critical</option>
            <option value="warning">Warning</option>
            <option value="info">Info</option>
          </select>

          {(searchQuery || selectedStatus || selectedSeverity) && (
            <button
              type="button"
              onClick={() => {
                setSearchQuery('');
                setSelectedStatus('');
                setSelectedSeverity('');
              }}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline px-2"
            >
              Reset
            </button>
          )}
        </div>
      </div>

      {/* Alerts Feed */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="p-8 text-center bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto" />
            <h3 className="text-sm font-semibold text-slate-800 dark:text-slate-200">
              No Operational Alerts
            </h3>
            <p className="text-xs text-slate-500">
              All terminal heartbeat indicators and transaction integrity checks are nominal.
            </p>
          </div>
        ) : (
          filtered.map(alert => (
            <div
              key={alert.id}
              className={`p-4 bg-white dark:bg-slate-900 border rounded-xl space-y-3 transition-colors ${
                alert.status === 'resolved'
                  ? 'border-slate-200 dark:border-slate-800 opacity-60'
                  : alert.severity === 'critical'
                  ? 'border-rose-300 dark:border-rose-900/60 shadow-xs'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <StatusBadge type="alert" status={alert.severity} />
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {alert.title}
                  </h3>
                </div>

                <div className="flex items-center gap-2">
                  <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded ${
                    alert.status === 'open'
                      ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                      : alert.status === 'acknowledged'
                      ? 'bg-amber-100 text-amber-700 dark:bg-amber-950 dark:text-amber-300'
                      : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                  }`}>
                    {alert.status}
                  </span>
                  <span className="text-[11px] text-slate-400 font-mono tabular-nums">
                    {formatRelativeTime(alert.created_at)}
                  </span>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                {alert.description}
              </p>

              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pt-2 border-t border-slate-100 dark:border-slate-800/80 text-[11px] text-slate-500">
                <div className="flex items-center gap-3">
                  <span>Target: <strong className="font-mono text-slate-700 dark:text-slate-300">{alert.related_entity_label}</strong></span>
                  {alert.acknowledged_by && (
                    <span>· Ack by: {alert.acknowledged_by}</span>
                  )}
                  {alert.resolved_by && (
                    <span>· Resolved by: {alert.resolved_by}</span>
                  )}
                </div>

                {/* Supervisor Resolution Buttons */}
                {can('manage:alerts') && alert.status !== 'resolved' && (
                  <div className="flex items-center gap-2">
                    {alert.status === 'open' && (
                      <button
                        type="button"
                        onClick={() => handleAcknowledge(alert.id)}
                        className="px-2.5 py-1 text-xs font-medium text-amber-700 dark:text-amber-300 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-md hover:bg-amber-100 transition-colors"
                      >
                        Acknowledge
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleResolve(alert.id)}
                      className="px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-md hover:bg-emerald-100 transition-colors"
                    >
                      Mark Resolved
                    </button>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
