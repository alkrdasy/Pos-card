import React from 'react';
import {
  ArrowLeft,
  Store,
  Building2,
  CreditCard,
  MapPin,
  Phone,
  Receipt,
  Edit,
  ExternalLink
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, formatDateTime } from '../../lib/utils';
import { Merchant } from '../../types';

interface MerchantDetailViewProps {
  merchantId: string;
  onBack: () => void;
  onOpenEditModal: (merchant: Merchant) => void;
  onSelectTerminal: (terminalId: string) => void;
}

export const MerchantDetailView: React.FC<MerchantDetailViewProps> = ({
  merchantId,
  onBack,
  onOpenEditModal,
  onSelectTerminal
}) => {
  const { can } = useAuth();
  const merchant = storageService.getMerchantById(merchantId);

  if (!merchant) {
    return (
      <div className="p-8 text-center space-y-3">
        <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Merchant not found</p>
        <button onClick={onBack} className="px-3 py-1.5 text-xs text-white bg-indigo-600 rounded-md">
          Back to merchants
        </button>
      </div>
    );
  }

  const terminals = storageService.getTerminals().filter(t => t.merchant_id === merchant.id);
  const transactions = storageService.getTransactions().filter(t => t.merchant_id === merchant.id);
  const totalVolume = transactions.reduce((acc, t) => acc + (t.status === 'completed' ? t.amount : 0), 0);

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-150">
      <div className="flex items-center gap-2 text-xs text-slate-500">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-400 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Merchants</span>
        </button>
        <span>/</span>
        <span className="text-slate-800 dark:text-slate-200 font-medium truncate max-w-xs">
          {merchant.merchant_name}
        </span>
      </div>

      {/* Header */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                {merchant.merchant_name}
              </h2>
              <span className="px-2 py-0.5 text-xs font-semibold uppercase bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 rounded">
                {merchant.status}
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-1">
              MID: <strong className="font-mono text-indigo-600 dark:text-indigo-400">{merchant.merchant_identifier}</strong> · Parent: <strong className="text-slate-800 dark:text-slate-200">{merchant.company_name}</strong> · Category: {merchant.business_category}
            </p>
          </div>

          {can('manage:merchants') && (
            <button
              type="button"
              onClick={() => onOpenEditModal(merchant)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs self-start md:self-auto"
            >
              <Edit className="w-3.5 h-3.5" />
              <span>Edit Merchant</span>
            </button>
          )}
        </div>

        {/* Metrics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <span className="text-slate-500 block text-[11px]">Active POS Units</span>
            <span className="text-lg font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
              {terminals.filter(t => t.status === 'active').length} of {terminals.length}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Completed Transactions</span>
            <span className="text-lg font-bold text-slate-800 dark:text-slate-200 tabular-nums">
              {transactions.filter(t => t.status === 'completed').length}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Total Volume</span>
            <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
              {formatCurrency(totalVolume, 'EGP')}
            </span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Location</span>
            <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate block mt-1">
              {merchant.location_name || 'Unassigned'}
            </span>
          </div>
        </div>
      </div>

      {/* POS Fleet for this Merchant */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
        <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
          <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Deployed POS Terminals ({terminals.length})
          </h3>
        </div>
        <table className="w-full text-left text-xs">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 text-[10px] uppercase">
              <th className="py-3 px-4 font-semibold">Terminal</th>
              <th className="py-3 px-4 font-semibold">TID</th>
              <th className="py-3 px-4 font-semibold">Model</th>
              <th className="py-3 px-4 font-semibold">Serial</th>
              <th className="py-3 px-4 font-semibold">Custodian</th>
              <th className="py-3 px-4 font-semibold">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
            {terminals.map(t => (
              <tr
                key={t.id}
                onClick={() => onSelectTerminal(t.id)}
                className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer"
              >
                <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                  {t.terminal_name}
                </td>
                <td className="py-3 px-4 font-mono text-indigo-600 dark:text-indigo-400 font-semibold">
                  {t.terminal_identifier}
                </td>
                <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                  {t.provider} · {t.terminal_model}
                </td>
                <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                  {t.serial_number}
                </td>
                <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                  {t.assigned_user_name || t.owner_name}
                </td>
                <td className="py-3 px-4">
                  <StatusBadge type="terminal" status={t.status} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
