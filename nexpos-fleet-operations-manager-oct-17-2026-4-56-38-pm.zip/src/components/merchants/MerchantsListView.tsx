import React, { useState, useMemo } from 'react';
import {
  Store,
  Plus,
  Download,
  Search,
  Building2,
  CreditCard,
  MapPin,
  ChevronRight,
  Edit
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { exportToCsv } from '../../lib/utils';
import { Merchant } from '../../types';

interface MerchantsListViewProps {
  onSelectMerchant: (merchantId: string) => void;
  onOpenCreateModal: () => void;
  onOpenEditModal: (merchant: Merchant) => void;
}

export const MerchantsListView: React.FC<MerchantsListViewProps> = ({
  onSelectMerchant,
  onOpenCreateModal,
  onOpenEditModal
}) => {
  const { activeCompanyFilter, can } = useAuth();
  const merchants = storageService.getMerchants();
  const companies = storageService.getCompanies();
  const terminals = storageService.getTerminals();
  const locations = storageService.getLocations();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<string>(activeCompanyFilter !== 'all' ? activeCompanyFilter : '');
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  const filtered = useMemo(() => {
    return merchants.filter(m => {
      if (activeCompanyFilter !== 'all' && m.company_id !== activeCompanyFilter) return false;
      if (selectedCompany && m.company_id !== selectedCompany) return false;
      if (selectedStatus && m.status !== selectedStatus) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          m.merchant_name.toLowerCase().includes(q) ||
          m.merchant_identifier.toLowerCase().includes(q) ||
          (m.company_name && m.company_name.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [merchants, activeCompanyFilter, selectedCompany, selectedStatus, searchQuery]);

  const handleExportCsv = () => {
    const rows = filtered.map(m => ({
      merchant_name: m.merchant_name,
      merchant_identifier: m.merchant_identifier,
      business_category: m.business_category,
      company: m.company_name,
      location: m.location_name || 'N/A',
      contact_name: m.contact_name,
      contact_phone: m.contact_phone,
      status: m.status
    }));
    exportToCsv('merchants_outlets', rows);
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Merchants & Outlets
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Acquiring Merchant Identifiers (MIDs) and store trade entities
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {can('manage:merchants') && (
            <button
              type="button"
              onClick={onOpenCreateModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Merchant</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by merchant name, MID, or parent company..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2">
          {activeCompanyFilter === 'all' && (
            <select
              value={selectedCompany}
              onChange={e => setSelectedCompany(e.target.value)}
              className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">All Companies</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          )}

          <select
            value={selectedStatus}
            onChange={e => setSelectedStatus(e.target.value)}
            className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
          >
            <option value="">All Statuses</option>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {/* Table view */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4 font-semibold">Merchant Outlet</th>
                <th className="py-3 px-4 font-semibold">MID</th>
                <th className="py-3 px-4 font-semibold">Company</th>
                <th className="py-3 px-4 font-semibold">Category</th>
                <th className="py-3 px-4 font-semibold">Branch Location</th>
                <th className="py-3 px-4 font-semibold text-center">POS Fleet</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map(merchant => {
                const posCount = terminals.filter(t => t.merchant_id === merchant.id).length;

                return (
                  <tr
                    key={merchant.id}
                    onClick={() => onSelectMerchant(merchant.id)}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-slate-100">
                        {merchant.merchant_name}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        Lead: {merchant.contact_name}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                      {merchant.merchant_identifier}
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800 dark:text-slate-200">
                      {merchant.company_name}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {merchant.business_category}
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {merchant.location_name || '—'}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                      {posCount}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 text-[10px] font-semibold uppercase bg-emerald-50 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300 rounded">
                        {merchant.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                        {can('manage:merchants') && (
                          <button
                            type="button"
                            onClick={() => onOpenEditModal(merchant)}
                            className="px-2 py-1 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                          >
                            Edit
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onSelectMerchant(merchant.id)}
                          className="p-1 text-slate-400 hover:text-slate-700"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
