import React, { useState } from 'react';
import {
  Settings,
  Database,
  Shield,
  RotateCcw,
  Download,
  CheckCircle2,
  Code,
  Copy,
  Key,
  Layers,
  Terminal,
  Server
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';

export const SettingsView: React.FC = () => {
  const { currentUser, can } = useAuth();
  const { success, error } = useToast();
  const [activeTab, setActiveTab] = useState<'general' | 'database' | 'roles' | 'maintenance'>('general');
  const [copied, setCopied] = useState(false);

  // Settings form states
  const [platformName, setPlatformName] = useState('NexPOS Fleet Operations');
  const [defaultCurrency, setDefaultCurrency] = useState('EGP');
  const [duplicateWindowMinutes, setDuplicateWindowMinutes] = useState('15');
  const [inactivityThresholdHours, setInactivityThresholdHours] = useState('48');

  // Supabase simulated status
  const supabaseUrl = 'https://pos-operations-prod.supabase.co';
  const supabaseStatus = 'Connected · DDL Active';

  const sqlMigrationSample = `-- PostgreSQL / Supabase Schema Definition for NexPOS Fleet
CREATE TABLE IF NOT EXISTS terminals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    merchant_id UUID REFERENCES merchants(id) ON DELETE SET NULL,
    terminal_name VARCHAR(255) NOT NULL,
    terminal_identifier VARCHAR(100) UNIQUE NOT NULL, -- TID (Unique)
    terminal_model VARCHAR(150) NOT NULL,
    provider VARCHAR(100) NOT NULL,
    serial_number VARCHAR(100) UNIQUE NOT NULL, -- Hardware S/N (Unique)
    owner_name VARCHAR(255) NOT NULL,
    assigned_user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    status terminal_status_enum NOT NULL DEFAULT 'active',
    installation_date DATE NOT NULL DEFAULT CURRENT_DATE,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Operational Duplicate Transaction Restriction:
CREATE TABLE IF NOT EXISTS transaction_records (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    company_id UUID NOT NULL REFERENCES companies(id),
    merchant_id UUID NOT NULL REFERENCES merchants(id),
    terminal_id UUID NOT NULL REFERENCES terminals(id),
    external_reference VARCHAR(150) UNIQUE NOT NULL, -- Accidental duplicate blocked
    amount DECIMAL(14, 2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(10) NOT NULL DEFAULT 'EGP',
    status transaction_status_enum NOT NULL DEFAULT 'completed',
    transaction_time TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Row Level Security (RLS) Policy
ALTER TABLE terminals ENABLE ROW LEVEL SECURITY;
CREATE POLICY super_admin_all_terminals ON terminals FOR ALL USING (get_current_user_role() = 'super_admin');
CREATE POLICY operator_assigned_terminals ON terminals FOR SELECT USING (
  assigned_user_id = (SELECT id FROM profiles WHERE auth_user_id = auth.uid() LIMIT 1)
);`;

  const handleCopySql = () => {
    navigator.clipboard.writeText(sqlMigrationSample);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
    success('Copied to Clipboard', 'PostgreSQL schema copied.');
  };

  const handleResetData = () => {
    if (window.confirm('Reset local fleet data back to original realistic seed records?')) {
      storageService.resetToDefaults();
      success('Database Reset', 'Restored pristine enterprise demo dataset.');
    }
  };

  const handleDownloadBackup = () => {
    const backup = {
      companies: storageService.getCompanies(),
      merchants: storageService.getMerchants(),
      terminals: storageService.getTerminals(),
      locations: storageService.getLocations(),
      users: storageService.getUsers(),
      transactions: storageService.getTransactions(),
      activities: storageService.getActivities(),
      alerts: storageService.getAlerts(),
      auditLogs: storageService.getAuditLogs(),
      assignments: storageService.getAssignments(),
      exportedAt: new Date().toISOString()
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `nexpos_fleet_backup_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    success('Backup Created', 'Full platform database exported to JSON.');
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            System & Organization Settings
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Platform governance, PostgreSQL schema migrations, and operational thresholds
          </p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('general')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            activeTab === 'general'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          General Preferences
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('database')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            activeTab === 'database'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          PostgreSQL & Supabase DDL
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('roles')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            activeTab === 'roles'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Permissions Matrix (RBAC)
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('maintenance')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            activeTab === 'maintenance'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Data & Database Reset
        </button>
      </div>

      {/* Tab 1: General Preferences */}
      {activeTab === 'general' && (
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-5 shadow-2xs max-w-2xl">
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Platform Organization Name
              </label>
              <input
                type="text"
                value={platformName}
                onChange={e => setPlatformName(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Default Settlement Currency
                </label>
                <select
                  value={defaultCurrency}
                  onChange={e => setDefaultCurrency(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                >
                  <option value="EGP">EGP (Egyptian Pound)</option>
                  <option value="USD">USD (US Dollar)</option>
                  <option value="EUR">EUR (Euro)</option>
                  <option value="SAR">SAR (Saudi Riyal)</option>
                  <option value="AED">AED (UAE Dirham)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                  Duplicate Pattern Window (Minutes)
                </label>
                <input
                  type="number"
                  value={duplicateWindowMinutes}
                  onChange={e => setDuplicateWindowMinutes(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Hardware Inactivity Flag Threshold (Hours)
              </label>
              <input
                type="number"
                value={inactivityThresholdHours}
                onChange={e => setInactivityThresholdHours(e.target.value)}
                className="w-full text-xs p-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg"
              />
              <p className="text-[11px] text-slate-500 mt-1">
                Trigger operational warning alert if an active terminal reports no transaction or heartbeat within this time.
              </p>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">
            <button
              type="button"
              onClick={() => success('Preferences Saved', 'Operational thresholds updated.')}
              className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Save Preferences
            </button>
          </div>
        </div>
      )}

      {/* Tab 2: PostgreSQL & Supabase DDL */}
      {activeTab === 'database' && (
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-indigo-600" />
                <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                  Supabase & PostgreSQL Production Schema
                </h3>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Target database: <code className="font-mono text-indigo-600">{supabaseUrl}</code> ({supabaseStatus})
              </p>
            </div>

            <button
              type="button"
              onClick={handleCopySql}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs self-start sm:self-auto"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>{copied ? 'Copied!' : 'Copy SQL Migration'}</span>
            </button>
          </div>

          <div className="p-4 bg-slate-950 text-slate-200 rounded-xl text-xs font-mono overflow-x-auto border border-slate-800">
            <pre className="text-[11px] leading-relaxed">
              {sqlMigrationSample}
            </pre>
          </div>

          <p className="text-[11px] text-slate-500">
            Full migration file is also saved at <code className="text-indigo-600 font-mono">/supabase/migrations/20250101000000_init_pos_fleet.sql</code> with row-level security policies, indices, and audit trigger definitions.
          </p>
        </div>
      )}

      {/* Tab 3: Permissions Matrix */}
      {activeTab === 'roles' && (
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs">
          <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
            Role-Based Access Control (RBAC) Specification
          </h3>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase text-[10px]">
                <th className="py-2.5 px-3 font-semibold">Capability</th>
                <th className="py-2.5 px-3 font-semibold text-center">Super Admin</th>
                <th className="py-2.5 px-3 font-semibold text-center">Admin</th>
                <th className="py-2.5 px-3 font-semibold text-center">Operator</th>
                <th className="py-2.5 px-3 font-semibold text-center">Viewer</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              <tr>
                <td className="py-2.5 px-3 font-medium">Create & Archive Companies</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Register & Edit Terminals</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Reassign Hardware Custody</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Record Authorized Transactions</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">View Immutable Audit Logs</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-medium">Configure System Settings</td>
                <td className="py-2.5 px-3 text-center text-emerald-600 font-bold">✓</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
                <td className="py-2.5 px-3 text-center text-slate-400">—</td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 4: Maintenance & Reset */}
      {activeTab === 'maintenance' && (
        <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-6 shadow-2xs max-w-xl">
          <div className="space-y-2">
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
              Fleet Database Maintenance & Backup
            </h3>
            <p className="text-xs text-slate-500">
              Export entire fleet configuration as JSON or restore factory demo seed records.
            </p>
          </div>

          <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-3">
            <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              Download Fleet State Backup
            </h4>
            <p className="text-[11px] text-slate-500">
              Generates a full JSON snapshot of companies, merchants, terminals, assignments, and audit logs.
            </p>
            <button
              type="button"
              onClick={handleDownloadBackup}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-slate-800 dark:text-slate-100 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download JSON Backup</span>
            </button>
          </div>

          <div className="p-4 bg-rose-50 dark:bg-rose-950/30 border border-rose-200 dark:border-rose-900/60 rounded-xl space-y-3">
            <h4 className="text-xs font-semibold text-rose-800 dark:text-rose-200">
              Reset Demo Dataset
            </h4>
            <p className="text-[11px] text-rose-700/80 dark:text-rose-300/80 leading-relaxed">
              Resets all companies, merchants, POS terminals, and transaction receipts back to the initial demo baseline (ABC Retail, Nile Electronics, Cairo Food Services, Delta Furniture).
            </p>
            <button
              type="button"
              onClick={handleResetData}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium text-white bg-rose-600 rounded-lg hover:bg-rose-700 transition-colors shadow-xs"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset to Factory Demo State</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
