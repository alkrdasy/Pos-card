import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Plus,
  Receipt,
  AlertTriangle,
  Clock,
  CheckCircle2,
  XCircle,
  ShieldCheck,
  Building2,
  CreditCard,
  ChevronRight
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { EmptyState } from '../common/EmptyState';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, formatDateTime, exportToCsv } from '../../lib/utils';
import { TransactionRecord, TransactionStatus, TransactionType } from '../../types';

interface TransactionsListViewProps {
  onOpenRecordModal: () => void;
  selectedTransactionId?: string;
}

export const TransactionsListView: React.FC<TransactionsListViewProps> = ({
  onOpenRecordModal,
  selectedTransactionId
}) => {
  const { activeCompanyFilter, can, currentUser } = useAuth();
  const transactions = storageService.getTransactions();
  const companies = storageService.getCompanies();
  const terminals = storageService.getTerminals();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<string>(activeCompanyFilter !== 'all' ? activeCompanyFilter : '');
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [viewTransaction, setViewTransaction] = useState<TransactionRecord | null>(() => {
    if (selectedTransactionId) {
      return transactions.find(t => t.id === selectedTransactionId) || null;
    }
    return null;
  });

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 12;

  const filtered = useMemo(() => {
    return transactions.filter(tx => {
      if (activeCompanyFilter !== 'all' && tx.company_id !== activeCompanyFilter) return false;
      if (selectedCompany && tx.company_id !== selectedCompany) return false;
      if (selectedType && tx.transaction_type !== selectedType) return false;
      if (selectedStatus && tx.status !== selectedStatus) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesRef = tx.external_reference.toLowerCase().includes(q);
        const matchesTerm = (tx.terminal_name && tx.terminal_name.toLowerCase().includes(q)) || false;
        const matchesMerch = (tx.merchant_name && tx.merchant_name.toLowerCase().includes(q)) || false;
        const matchesNotes = (tx.notes && tx.notes.toLowerCase().includes(q)) || false;
        if (!matchesRef && !matchesTerm && !matchesMerch && !matchesNotes) return false;
      }

      return true;
    });
  }, [transactions, activeCompanyFilter, selectedCompany, selectedType, selectedStatus, searchQuery]);

  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  const totalPages = Math.ceil(filtered.length / pageSize) || 1;

  const handleExportCsv = () => {
    const rows = filtered.map(tx => ({
      reference: tx.external_reference,
      company: tx.company_name,
      merchant: tx.merchant_name,
      terminal: tx.terminal_name,
      operator: tx.operator_name,
      type: tx.transaction_type,
      amount: tx.amount,
      currency: tx.currency,
      status: tx.status,
      masked_instrument: tx.masked_reference || 'POS Slip',
      transaction_time: tx.transaction_time,
      recorded_at: tx.recorded_at,
      notes: tx.notes || ''
    }));
    exportToCsv('authorized_transactions_ledger', rows);
  };

  const handleUpdateStatus = (txId: string, status: TransactionStatus) => {
    if (!currentUser) return;
    const updated = storageService.updateTransactionStatus(txId, status, currentUser);
    setViewTransaction(updated);
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Authorized Transaction Records
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Reconciled POS receipts, duplicate integrity checks, and masked payment instrument references
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export Ledger CSV</span>
          </button>

          {can('record:transaction') && (
            <button
              type="button"
              onClick={onOpenRecordModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Record Transaction</span>
            </button>
          )}
        </div>
      </div>

      {/* Compliance Callout Banner */}
      <div className="flex items-center gap-2.5 p-3 bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-200/60 dark:border-indigo-800/60 rounded-xl text-xs text-indigo-900 dark:text-indigo-200">
        <ShieldCheck className="w-4 h-4 text-indigo-600 dark:text-indigo-400 shrink-0" />
        <span>
          <strong>Operational Data Boundary:</strong> Raw Primary Account Numbers (PAN), CVVs, and magnetic stripes are never stored. Duplicate reference collisions are automatically blocked.
        </span>
      </div>

      {/* Search and Filters */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search reference # (REF-...), terminal, merchant, notes..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>

          <div className="grid grid-cols-2 sm:flex items-center gap-2">
            <select
              value={selectedType}
              onChange={e => {
                setSelectedType(e.target.value);
                setCurrentPage(1);
              }}
              className="text-xs py-2 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">All Types</option>
              <option value="sale">Sale</option>
              <option value="refund">Refund</option>
              <option value="void">Void</option>
              <option value="adjustment">Adjustment</option>
              <option value="other">Other</option>
            </select>

            <select
              value={selectedStatus}
              onChange={e => {
                setSelectedStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="text-xs py-2 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">All Statuses</option>
              <option value="completed">Completed</option>
              <option value="pending">Pending</option>
              <option value="under_review">Under Review</option>
              <option value="failed">Failed</option>
              <option value="cancelled">Cancelled</option>
            </select>

            {activeCompanyFilter === 'all' && (
              <select
                value={selectedCompany}
                onChange={e => {
                  setSelectedCompany(e.target.value);
                  setCurrentPage(1);
                }}
                className="text-xs py-2 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg truncate max-w-[130px]"
              >
                <option value="">All Companies</option>
                {companies.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            )}

            {(searchQuery || selectedType || selectedStatus || selectedCompany) && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedType('');
                  setSelectedStatus('');
                  setSelectedCompany('');
                  setCurrentPage(1);
                }}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline px-2"
              >
                Clear
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Table view */}
      {filtered.length === 0 ? (
        <EmptyState
          icon={Receipt}
          title="No Transactions Found"
          description="No transaction records match the specified filters. Use the Quick Action to log an authorized POS slip receipt."
          actionLabel={can('record:transaction') ? '+ Record Transaction' : undefined}
          onAction={onOpenRecordModal}
        />
      ) : (
        <>
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 uppercase tracking-wider text-[10px]">
                    <th className="py-3 px-4 font-semibold">Slip Reference #</th>
                    <th className="py-3 px-4 font-semibold">Terminal</th>
                    <th className="py-3 px-4 font-semibold">Merchant / Company</th>
                    <th className="py-3 px-4 font-semibold">Type</th>
                    <th className="py-3 px-4 font-semibold text-right">Amount</th>
                    <th className="py-3 px-4 font-semibold">Instrument Reference</th>
                    <th className="py-3 px-4 font-semibold">Operator</th>
                    <th className="py-3 px-4 font-semibold">Status</th>
                    <th className="py-3 px-4 font-semibold">Transaction Time</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {paginated.map(tx => (
                    <tr
                      key={tx.id}
                      onClick={() => setViewTransaction(tx)}
                      className={`hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors ${
                        tx.is_duplicate_warning ? 'bg-amber-50/30 dark:bg-amber-950/20' : ''
                      }`}
                    >
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-1.5 font-mono font-bold text-indigo-600 dark:text-indigo-400">
                          {tx.external_reference}
                          {tx.is_duplicate_warning && (
                            <span title="Repeated transaction pattern detected">
                              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
                            </span>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-medium text-slate-800 dark:text-slate-200">
                        {tx.terminal_name}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800 dark:text-slate-200">
                          {tx.merchant_name}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {tx.company_name}
                        </div>
                      </td>
                      <td className="py-3 px-4 uppercase text-[10px] font-semibold text-slate-500">
                        {tx.transaction_type}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                        {formatCurrency(tx.amount, tx.currency)}
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-600 dark:text-slate-400">
                        {tx.masked_reference || 'POS Receipt Slip'}
                      </td>
                      <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                        {tx.operator_name}
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge type="transaction" status={tx.status} />
                      </td>
                      <td className="py-3 px-4 text-slate-500 tabular-nums">
                        {formatDateTime(tx.transaction_time)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-2 pt-2 text-xs text-slate-500">
              <span>
                Showing {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, filtered.length)} of {filtered.length} transactions
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  className="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-40"
                >
                  Previous
                </button>
                <span className="px-2 font-mono">
                  {currentPage} / {totalPages}
                </span>
                <button
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  className="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}

      {/* Transaction Details Drawer / Modal */}
      {viewTransaction && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
          <div className="w-full max-w-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl p-6 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-start justify-between">
              <div>
                <span className="text-[10px] font-semibold uppercase text-slate-500 tracking-wider">
                  Transaction Receipt Record
                </span>
                <h3 className="text-xl font-bold font-mono text-slate-900 dark:text-slate-100 mt-0.5">
                  #{viewTransaction.external_reference}
                </h3>
              </div>
              <StatusBadge type="transaction" status={viewTransaction.status} />
            </div>

            <div className="p-4 bg-slate-50 dark:bg-slate-800/60 rounded-xl space-y-2 text-xs">
              <div className="flex justify-between">
                <span className="text-slate-500">Gross Amount</span>
                <span className="text-base font-bold font-mono tabular-nums text-slate-900 dark:text-slate-100">
                  {formatCurrency(viewTransaction.amount, viewTransaction.currency)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Transaction Type</span>
                <span className="font-semibold uppercase">{viewTransaction.transaction_type}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Masked Payment Instrument</span>
                <span className="font-mono">{viewTransaction.masked_reference || 'Direct Slip Token'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Terminal</span>
                <span className="font-medium">{viewTransaction.terminal_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Merchant Outlet</span>
                <span className="font-medium">{viewTransaction.merchant_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Parent Company</span>
                <span className="font-medium">{viewTransaction.company_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Recording Operator</span>
                <span className="font-medium">{viewTransaction.operator_name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Recorded At</span>
                <span className="font-mono tabular-nums">{formatDateTime(viewTransaction.recorded_at)}</span>
              </div>
            </div>

            {viewTransaction.notes && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800 rounded-lg text-xs text-slate-600 dark:text-slate-300">
                <span className="font-semibold block mb-0.5">Operator Notes:</span>
                {viewTransaction.notes}
              </div>
            )}

            {/* Supervisor Status Reconciliation Actions */}
            {can('manage:terminals') && (
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-slate-500">Supervisory Review:</span>
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => handleUpdateStatus(viewTransaction.id, 'completed')}
                    className="px-2.5 py-1 font-medium bg-emerald-50 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300 rounded"
                  >
                    Mark Completed
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(viewTransaction.id, 'under_review')}
                    className="px-2.5 py-1 font-medium bg-indigo-50 text-indigo-700 dark:bg-indigo-950 dark:text-indigo-300 rounded"
                  >
                    Flag For Review
                  </button>
                  <button
                    onClick={() => handleUpdateStatus(viewTransaction.id, 'cancelled')}
                    className="px-2.5 py-1 font-medium bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 rounded"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                type="button"
                onClick={() => setViewTransaction(null)}
                className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50"
              >
                Close Receipt
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
