import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Search,
  Sliders,
  Building2,
  Store,
  CreditCard,
  MapPin,
  FileText,
  Activity,
  AlertTriangle,
  History,
  Settings,
  Users,
  PlusCircle,
  ArrowRight,
  X
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';

interface CommandPaletteProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (path: string, entityId?: string) => void;
  onOpenActionModal?: (action: string) => void;
}

export const CommandPalette: React.FC<CommandPaletteProps> = ({
  isOpen,
  onClose,
  onNavigate,
  onOpenActionModal
}) => {
  const [query, setQuery] = useState('');
  const [selectedIndex, setSelectedIndex] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const { can } = useAuth();

  const companies = storageService.getCompanies();
  const merchants = storageService.getMerchants();
  const terminals = storageService.getTerminals();
  const locations = storageService.getLocations();
  const transactions = storageService.getTransactions();
  const users = storageService.getUsers();

  useEffect(() => {
    if (isOpen) {
      setQuery('');
      setSelectedIndex(0);
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [isOpen]);

  // Global keyboard listener for Cmd+K / Ctrl+K / '/'
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          // trigger open handled by parent
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    const items: Array<{
      id: string;
      category: 'Pages' | 'Actions' | 'Terminals' | 'Merchants' | 'Companies' | 'Transactions' | 'Locations' | 'Users';
      title: string;
      subtitle: string;
      icon: any;
      onSelect: () => void;
    }> = [];

    // Quick Action Commands
    if (can('record:transaction')) {
      items.push({
        id: 'act_record_tx',
        category: 'Actions',
        title: 'Record Authorized Transaction',
        subtitle: 'Log a new POS receipt reference and amount',
        icon: PlusCircle,
        onSelect: () => {
          onClose();
          onOpenActionModal?.('record_transaction');
        }
      });
    }

    if (can('record:activity')) {
      items.push({
        id: 'act_record_act',
        category: 'Actions',
        title: 'Log Operational Activity',
        subtitle: 'Record maintenance, dispatch, or terminal inspection',
        icon: Activity,
        onSelect: () => {
          onClose();
          onOpenActionModal?.('record_activity');
        }
      });
    }

    if (can('create:terminal')) {
      items.push({
        id: 'act_add_terminal',
        category: 'Actions',
        title: 'Register New POS Terminal',
        subtitle: 'Add terminal TID, serial number, and provider',
        icon: PlusCircle,
        onSelect: () => {
          onClose();
          onOpenActionModal?.('add_terminal');
        }
      });
    }

    // Standard Navigation
    const pages = [
      { id: 'p_dash', title: 'Dashboard', subtitle: 'Fleet overview and KPI cards', path: 'dashboard', icon: Sliders },
      { id: 'p_term', title: 'POS Terminals', subtitle: 'Browse all fleet hardware', path: 'terminals', icon: CreditCard },
      { id: 'p_tx', title: 'Transactions', subtitle: 'Authorized transaction records', path: 'transactions', icon: FileText },
      { id: 'p_merch', title: 'Merchants', subtitle: 'Merchant categories and IDs', path: 'merchants', icon: Store },
      { id: 'p_comp', title: 'Companies', subtitle: 'Operating company accounts', path: 'companies', icon: Building2 },
      { id: 'p_loc', title: 'Locations', subtitle: 'Branch sites and stores', path: 'locations', icon: MapPin },
      { id: 'p_act', title: 'Operational Activity', subtitle: 'Chronological fleet feed', path: 'activity', icon: Activity },
      { id: 'p_alt', title: 'Alerts Center', subtitle: 'Operational flags and duplicates', path: 'alerts', icon: AlertTriangle },
      { id: 'p_rep', title: 'Reports & Exports', subtitle: 'Fleet summaries and CSVs', path: 'reports', icon: FileText },
      { id: 'p_aud', title: 'Audit Trail', subtitle: 'Immutable compliance log', path: 'audit', icon: History },
      { id: 'p_usr', title: 'Team & Operators', subtitle: 'Manage operator profiles', path: 'users', icon: Users },
      { id: 'p_set', title: 'System Settings', subtitle: 'Supabase schema and preferences', path: 'settings', icon: Settings },
    ];

    pages.forEach(p => {
      items.push({
        id: p.id,
        category: 'Pages',
        title: p.title,
        subtitle: p.subtitle,
        icon: p.icon,
        onSelect: () => {
          onClose();
          onNavigate(p.path);
        }
      });
    });

    if (!q) {
      return items.slice(0, 10);
    }

    // Entity Searching
    // Terminals
    terminals
      .filter(
        t =>
          t.terminal_name.toLowerCase().includes(q) ||
          t.terminal_identifier.toLowerCase().includes(q) ||
          t.serial_number.toLowerCase().includes(q) ||
          t.owner_name.toLowerCase().includes(q)
      )
      .slice(0, 5)
      .forEach(t => {
        items.push({
          id: `term_${t.id}`,
          category: 'Terminals',
          title: `${t.terminal_name} (${t.terminal_identifier})`,
          subtitle: `${t.provider} · Serial: ${t.serial_number} · Owner: ${t.owner_name}`,
          icon: CreditCard,
          onSelect: () => {
            onClose();
            onNavigate('terminals', t.id);
          }
        });
      });

    // Transactions
    transactions
      .filter(
        tx =>
          tx.external_reference.toLowerCase().includes(q) ||
          (tx.notes && tx.notes.toLowerCase().includes(q))
      )
      .slice(0, 4)
      .forEach(tx => {
        items.push({
          id: `tx_${tx.id}`,
          category: 'Transactions',
          title: `Ref #${tx.external_reference} (${tx.currency} ${tx.amount.toFixed(2)})`,
          subtitle: `${tx.terminal_name || 'Terminal'} · ${tx.transaction_type} · ${tx.status}`,
          icon: FileText,
          onSelect: () => {
            onClose();
            onNavigate('transactions', tx.id);
          }
        });
      });

    // Merchants
    merchants
      .filter(
        m =>
          m.merchant_name.toLowerCase().includes(q) ||
          m.merchant_identifier.toLowerCase().includes(q)
      )
      .slice(0, 4)
      .forEach(m => {
        items.push({
          id: `merch_${m.id}`,
          category: 'Merchants',
          title: `${m.merchant_name} (${m.merchant_identifier})`,
          subtitle: `${m.business_category} · ${m.company_name || 'Company'}`,
          icon: Store,
          onSelect: () => {
            onClose();
            onNavigate('merchants', m.id);
          }
        });
      });

    // Companies
    companies
      .filter(
        c =>
          c.name.toLowerCase().includes(q) ||
          c.registration_number.toLowerCase().includes(q)
      )
      .slice(0, 3)
      .forEach(c => {
        items.push({
          id: `comp_${c.id}`,
          category: 'Companies',
          title: c.name,
          subtitle: `CR: ${c.registration_number} · ${c.status}`,
          icon: Building2,
          onSelect: () => {
            onClose();
            onNavigate('companies', c.id);
          }
        });
      });

    // Locations
    locations
      .filter(l => l.name.toLowerCase().includes(q) || l.city.toLowerCase().includes(q))
      .slice(0, 3)
      .forEach(l => {
        items.push({
          id: `loc_${l.id}`,
          category: 'Locations',
          title: l.name,
          subtitle: `${l.address}, ${l.city}`,
          icon: MapPin,
          onSelect: () => {
            onClose();
            onNavigate('locations', l.id);
          }
        });
      });

    // Filter items based on query
    return items.filter(
      item =>
        item.title.toLowerCase().includes(q) ||
        item.subtitle.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q)
    );
  }, [query, can, companies, merchants, terminals, locations, transactions, users, onNavigate, onClose, onOpenActionModal]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setSelectedIndex(prev => (prev < results.length - 1 ? prev + 1 : 0));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setSelectedIndex(prev => (prev > 0 ? prev - 1 : results.length - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (results[selectedIndex]) {
        results[selectedIndex].onSelect();
      }
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24"
    >
      <div
        className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="relative w-full max-w-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl overflow-hidden z-10 animate-in fade-in zoom-in-95">
        {/* Search Input Bar */}
        <div className="flex items-center px-4 py-3.5 border-b border-slate-100 dark:border-slate-800 gap-3">
          <Search className="w-4 h-4 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={e => {
              setQuery(e.target.value);
              setSelectedIndex(0);
            }}
            onKeyDown={handleKeyDown}
            placeholder="Search terminals, merchants, companies, transactions (e.g. POS-1001, REF-2025)..."
            className="w-full bg-transparent text-sm text-slate-900 dark:text-slate-100 placeholder:text-slate-400 focus:outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-slate-100 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded">
            ESC
          </kbd>
        </div>

        {/* Results List */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-slate-100 dark:divide-slate-800/40">
          {results.length === 0 ? (
            <div className="p-8 text-center text-xs text-slate-500">
              No matching records found for "{query}".
            </div>
          ) : (
            results.map((item, idx) => {
              const isSelected = idx === selectedIndex;
              const Icon = item.icon;
              return (
                <div
                  key={item.id}
                  onClick={item.onSelect}
                  onMouseEnter={() => setSelectedIndex(idx)}
                  className={`flex items-center justify-between p-2.5 rounded-lg cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-slate-50'
                      : 'text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/60'
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <div
                      className={`p-1.5 rounded-md shrink-0 ${
                        isSelected
                          ? 'bg-indigo-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="truncate">
                      <p className="text-xs font-semibold truncate">{item.title}</p>
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 truncate">
                        {item.subtitle}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0 ml-3">
                    <span className="text-[10px] font-medium uppercase tracking-wider text-slate-400 dark:text-slate-500">
                      {item.category}
                    </span>
                    {isSelected && <ArrowRight className="w-3.5 h-3.5 text-indigo-500" />}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800 bg-slate-50 dark:bg-slate-900/60 flex items-center justify-between text-[11px] text-slate-500">
          <div className="flex items-center gap-3">
            <span>
              <kbd className="font-mono bg-white dark:bg-slate-800 px-1 py-0.5 border border-slate-200 dark:border-slate-700 rounded text-[10px]">↑↓</kbd> Navigate
            </span>
            <span>
              <kbd className="font-mono bg-white dark:bg-slate-800 px-1 py-0.5 border border-slate-200 dark:border-slate-700 rounded text-[10px]">↵</kbd> Select
            </span>
          </div>
          <span>POS Fleet Omnisearch</span>
        </div>
      </div>
    </div>
  );
};
