import React from 'react';
import { TerminalStatus, TransactionStatus, AlertSeverity, CompanyStatus, UserRole } from '../../types';
import { CheckCircle2, AlertTriangle, AlertOctagon, Info, Clock, XCircle, Wrench, Shield, User, HelpCircle, Archive } from 'lucide-react';
import { cn } from '../../lib/utils';

interface StatusBadgeProps {
  type: 'terminal' | 'transaction' | 'alert' | 'company' | 'role';
  status: string;
  className?: string;
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ type, status, className }) => {
  if (type === 'terminal') {
    const s = status as TerminalStatus;
    switch (s) {
      case 'active':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200/60 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800/60 rounded', className)}>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>ACTIVE</span>
          </span>
        );
      case 'inactive':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-slate-700 bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded', className)}>
            <Clock className="w-3.5 h-3.5 text-slate-500" />
            <span>INACTIVE</span>
          </span>
        );
      case 'maintenance':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200/70 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800/60 rounded', className)}>
            <Wrench className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            <span>MAINTENANCE</span>
          </span>
        );
      case 'lost':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800/60 rounded', className)}>
            <AlertOctagon className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
            <span>LOST</span>
          </span>
        );
      case 'retired':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-slate-600 bg-slate-100/80 border border-slate-300/80 dark:bg-slate-900 dark:text-slate-400 dark:border-slate-800 rounded', className)}>
            <Archive className="w-3.5 h-3.5 text-slate-400" />
            <span>RETIRED</span>
          </span>
        );
      default:
        return <span className="text-xs text-slate-500">{status}</span>;
    }
  }

  if (type === 'transaction') {
    const s = status as TransactionStatus;
    switch (s) {
      case 'completed':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200/60 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800/60 rounded', className)}>
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
            <span>Completed</span>
          </span>
        );
      case 'pending':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800 rounded', className)}>
            <Clock className="w-3.5 h-3.5 text-amber-600" />
            <span>Pending</span>
          </span>
        );
      case 'under_review':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-indigo-700 bg-indigo-50 border border-indigo-200 dark:bg-indigo-950/40 dark:text-indigo-300 dark:border-indigo-800 rounded', className)}>
            <AlertTriangle className="w-3.5 h-3.5 text-indigo-600" />
            <span>Under Review</span>
          </span>
        );
      case 'failed':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-rose-700 bg-rose-50 border border-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:border-rose-800 rounded', className)}>
            <XCircle className="w-3.5 h-3.5 text-rose-600" />
            <span>Failed</span>
          </span>
        );
      case 'cancelled':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-slate-600 bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:text-slate-400 dark:border-slate-700 rounded', className)}>
            <XCircle className="w-3.5 h-3.5 text-slate-400" />
            <span>Cancelled</span>
          </span>
        );
      default:
        return <span className="text-xs text-slate-500">{status}</span>;
    }
  }

  if (type === 'alert') {
    const s = status as AlertSeverity;
    switch (s) {
      case 'critical':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-semibold text-rose-700 bg-rose-50 border border-rose-200 dark:bg-rose-950/50 dark:text-rose-300 dark:border-rose-800 rounded', className)}>
            <AlertOctagon className="w-3.5 h-3.5 text-rose-600 dark:text-rose-400" />
            <span>CRITICAL</span>
          </span>
        );
      case 'warning':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-amber-700 bg-amber-50 border border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800 rounded', className)}>
            <AlertTriangle className="w-3.5 h-3.5 text-amber-600 dark:text-amber-400" />
            <span>WARNING</span>
          </span>
        );
      case 'info':
        return (
          <span className={cn('inline-flex items-center gap-1.5 px-2 py-0.5 text-xs font-medium text-sky-700 bg-sky-50 border border-sky-200 dark:bg-sky-950/40 dark:text-sky-300 dark:border-sky-800 rounded', className)}>
            <Info className="w-3.5 h-3.5 text-sky-600 dark:text-sky-400" />
            <span>INFO</span>
          </span>
        );
      default:
        return <span className="text-xs text-slate-500">{status}</span>;
    }
  }

  if (type === 'company') {
    const s = status as CompanyStatus;
    switch (s) {
      case 'active':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200/60 dark:bg-emerald-950/40 dark:text-emerald-300 rounded', className)}>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
            <span>Active</span>
          </span>
        );
      case 'inactive':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-600 bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:text-slate-400 rounded', className)}>
            <span className="w-1.5 h-1.5 rounded-full bg-slate-400" />
            <span>Inactive</span>
          </span>
        );
      case 'archived':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-500 bg-slate-50 border border-slate-200 dark:bg-slate-900 dark:text-slate-500 rounded', className)}>
            <Archive className="w-3 h-3 text-slate-400" />
            <span>Archived</span>
          </span>
        );
      default:
        return <span className="text-xs text-slate-500">{status}</span>;
    }
  }

  if (type === 'role') {
    const s = status as UserRole;
    switch (s) {
      case 'super_admin':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-purple-700 bg-purple-50 border border-purple-200 dark:bg-purple-950/40 dark:text-purple-300 dark:border-purple-800 rounded', className)}>
            <Shield className="w-3 h-3 text-purple-600" />
            <span>Super Admin</span>
          </span>
        );
      case 'admin':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-blue-700 bg-blue-50 border border-blue-200 dark:bg-blue-950/40 dark:text-blue-300 dark:border-blue-800 rounded', className)}>
            <Shield className="w-3 h-3 text-blue-600" />
            <span>Admin</span>
          </span>
        );
      case 'operator':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-50 border border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800 rounded', className)}>
            <User className="w-3 h-3 text-emerald-600" />
            <span>Operator</span>
          </span>
        );
      case 'viewer':
        return (
          <span className={cn('inline-flex items-center gap-1 px-2 py-0.5 text-xs font-medium text-slate-600 bg-slate-100 border border-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded', className)}>
            <HelpCircle className="w-3 h-3 text-slate-400" />
            <span>Viewer</span>
          </span>
        );
      default:
        return <span className="text-xs text-slate-500">{status}</span>;
    }
  }

  return <span className="text-xs text-slate-500">{status}</span>;
};
