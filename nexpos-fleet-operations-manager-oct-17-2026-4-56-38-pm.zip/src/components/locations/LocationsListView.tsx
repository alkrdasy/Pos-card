import React, { useState, useMemo } from 'react';
import {
  MapPin,
  Plus,
  Download,
  Search,
  Building2,
  CreditCard,
  Phone,
  User,
  Edit
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { exportToCsv } from '../../lib/utils';
import { Location } from '../../types';

interface LocationsListViewProps {
  onOpenCreateModal: () => void;
  onOpenEditModal: (loc: Location) => void;
  onSelectTerminal?: (terminalId: string) => void;
}

export const LocationsListView: React.FC<LocationsListViewProps> = ({
  onOpenCreateModal,
  onOpenEditModal,
  onSelectTerminal
}) => {
  const { activeCompanyFilter, can } = useAuth();
  const locations = storageService.getLocations();
  const terminals = storageService.getTerminals();
  const transactions = storageService.getTransactions();

  const [searchQuery, setSearchQuery] = useState('');

  const filtered = useMemo(() => {
    return locations.filter(l => {
      if (activeCompanyFilter !== 'all' && l.company_id !== activeCompanyFilter) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          l.name.toLowerCase().includes(q) ||
          l.city.toLowerCase().includes(q) ||
          l.area.toLowerCase().includes(q) ||
          l.address.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [locations, activeCompanyFilter, searchQuery]);

  const handleExportCsv = () => {
    const rows = filtered.map(l => ({
      name: l.name,
      address: l.address,
      city: l.city,
      area: l.area,
      company: l.company_name,
      contact_name: l.contact_name,
      contact_phone: l.contact_phone,
      status: l.status
    }));
    exportToCsv('operating_locations', rows);
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Locations & Branches
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Physical retail stores, showrooms, and warehouse POS terminal installation sites
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {can('manage:locations') && (
            <button
              type="button"
              onClick={onOpenCreateModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Location</span>
            </button>
          )}
        </div>
      </div>

      {/* Search */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search locations by site name, city, or area..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Grid of Location Cards (Requirement 25) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(location => {
          const locTerminals = terminals.filter(t => t.location_id === location.id);
          const activeCount = locTerminals.filter(t => t.status === 'active').length;
          const maintenanceCount = locTerminals.filter(t => t.status === 'maintenance').length;
          const locTxCount = transactions.filter(tx => locTerminals.some(t => t.id === tx.terminal_id)).length;

          return (
            <div
              key={location.id}
              className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs hover:border-slate-300 dark:hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                    {location.name}
                  </h3>
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span>{location.area}, {location.city}</span>
                  </div>
                </div>

                {can('manage:locations') && (
                  <button
                    type="button"
                    onClick={() => onOpenEditModal(location)}
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    title="Edit Location"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="text-xs text-slate-600 dark:text-slate-400">
                <span className="block text-[11px] text-slate-600 dark:text-slate-400">Company</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{location.company_name}</span>
              </div>

              {/* Hardware Deployment Summary */}
              <div className="grid grid-cols-3 gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-center text-xs">
                <div>
                  <span className="text-[10px] text-slate-600 dark:text-slate-400 uppercase font-semibold">Terminals</span>
                  <p className="text-base font-bold text-slate-900 dark:text-slate-100 tabular-nums">
                    {locTerminals.length}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-600 dark:text-slate-400 uppercase font-semibold">Active</span>
                  <p className="text-base font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                    {activeCount}
                  </p>
                </div>
                <div>
                  <span className="text-[10px] text-slate-600 dark:text-slate-400 uppercase font-semibold">Repair</span>
                  <p className="text-base font-bold text-amber-600 dark:text-amber-400 tabular-nums">
                    {maintenanceCount}
                  </p>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 flex items-center justify-between">
                <span>Supervisor: <strong>{location.contact_name}</strong></span>
                <span className="font-mono">{locTxCount} tx recorded</span>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
