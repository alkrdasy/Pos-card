import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { Location } from '../../types';

interface LocationModalProps {
  isOpen: boolean;
  onClose: () => void;
  locationToEdit?: Location | null;
  onSuccess?: (loc: Location) => void;
}

export const LocationModal: React.FC<LocationModalProps> = ({
  isOpen,
  onClose,
  locationToEdit,
  onSuccess
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();
  const companies = storageService.getCompanies();

  const [companyId, setCompanyId] = useState('');
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [area, setArea] = useState('');
  const [latitude, setLatitude] = useState('');
  const [longitude, setLongitude] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (locationToEdit) {
        setCompanyId(locationToEdit.company_id);
        setName(locationToEdit.name);
        setAddress(locationToEdit.address);
        setCity(locationToEdit.city);
        setArea(locationToEdit.area);
        setLatitude(locationToEdit.latitude ? String(locationToEdit.latitude) : '');
        setLongitude(locationToEdit.longitude ? String(locationToEdit.longitude) : '');
        setContactName(locationToEdit.contact_name);
        setContactPhone(locationToEdit.contact_phone);
        setStatus(locationToEdit.status);
        setNotes(locationToEdit.notes || '');
      } else {
        setCompanyId(companies[0]?.id || '');
        setName('');
        setAddress('');
        setCity('Cairo');
        setArea('');
        setLatitude('30.0444');
        setLongitude('31.2357');
        setContactName('');
        setContactPhone('');
        setStatus('active');
        setNotes('');
      }
    }
  }, [isOpen, locationToEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!name.trim()) {
      error('Validation Error', 'Location branch name is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      let result: Location;
      const lat = latitude ? parseFloat(latitude) : undefined;
      const lng = longitude ? parseFloat(longitude) : undefined;

      if (locationToEdit) {
        result = storageService.updateLocation(
          locationToEdit.id,
          {
            company_id: companyId,
            name: name.trim(),
            address: address.trim(),
            city: city.trim(),
            area: area.trim(),
            latitude: lat,
            longitude: lng,
            contact_name: contactName.trim(),
            contact_phone: contactPhone.trim(),
            status,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Location Updated', `Saved details for ${result.name}.`);
      } else {
        result = storageService.createLocation(
          {
            company_id: companyId,
            name: name.trim(),
            address: address.trim(),
            city: city.trim(),
            area: area.trim(),
            latitude: lat,
            longitude: lng,
            contact_name: contactName.trim(),
            contact_phone: contactPhone.trim(),
            status,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Location Added', `Created location ${result.name}.`);
      }

      onSuccess?.(result);
      onClose();
    } catch (err: any) {
      error('Failed to Save Location', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={locationToEdit ? `Edit Location: ${locationToEdit.name}` : 'Add Branch Location'}
      description="Define store site, physical address, and site supervisor details"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Company *
          </label>
          <select
            value={companyId}
            onChange={e => setCompanyId(e.target.value)}
            required
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            {companies.map(c => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Branch / Site Name *
          </label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            required
            placeholder="e.g. Downtown Flagship Branch"
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Street Address
          </label>
          <input
            type="text"
            value={address}
            onChange={e => setAddress(e.target.value)}
            placeholder="e.g. 14 Talaat Harb Street"
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              City
            </label>
            <input
              type="text"
              value={city}
              onChange={e => setCity(e.target.value)}
              placeholder="e.g. Cairo"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              District / Area
            </label>
            <input
              type="text"
              value={area}
              onChange={e => setArea(e.target.value)}
              placeholder="e.g. Downtown"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Person
            </label>
            <input
              type="text"
              value={contactName}
              onChange={e => setContactName(e.target.value)}
              placeholder="Branch manager"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Phone
            </label>
            <input
              type="text"
              value={contactPhone}
              onChange={e => setContactPhone(e.target.value)}
              placeholder="+20 100 000 0000"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {isSubmitting ? 'Saving...' : locationToEdit ? 'Save Changes' : 'Create Location'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
