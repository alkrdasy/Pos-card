import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { Company, CompanyStatus } from '../../types';

interface CompanyModalProps {
  isOpen: boolean;
  onClose: () => void;
  companyToEdit?: Company | null;
  onSuccess?: (company: Company) => void;
}

export const CompanyModal: React.FC<CompanyModalProps> = ({
  isOpen,
  onClose,
  companyToEdit,
  onSuccess
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();

  const [name, setName] = useState('');
  const [legalName, setLegalName] = useState('');
  const [registrationNumber, setRegistrationNumber] = useState('');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [status, setStatus] = useState<CompanyStatus>('active');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (companyToEdit) {
        setName(companyToEdit.name);
        setLegalName(companyToEdit.legal_name);
        setRegistrationNumber(companyToEdit.registration_number);
        setContactName(companyToEdit.contact_name);
        setContactPhone(companyToEdit.contact_phone);
        setContactEmail(companyToEdit.contact_email);
        setStatus(companyToEdit.status);
        setNotes(companyToEdit.notes || '');
      } else {
        setName('');
        setLegalName('');
        setRegistrationNumber(`CR-${Math.floor(1000000 + Math.random() * 9000000)}`);
        setContactName('');
        setContactPhone('');
        setContactEmail('');
        setStatus('active');
        setNotes('');
      }
    }
  }, [isOpen, companyToEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!name.trim()) {
      error('Company Name Required', 'Please enter a company brand name.');
      return;
    }
    if (!registrationNumber.trim()) {
      error('Registration Number Required', 'Commercial registration number is mandatory.');
      return;
    }

    setIsSubmitting(true);
    try {
      let result: Company;
      if (companyToEdit) {
        result = storageService.updateCompany(
          companyToEdit.id,
          {
            name: name.trim(),
            legal_name: legalName.trim() || name.trim(),
            registration_number: registrationNumber.trim(),
            contact_name: contactName.trim(),
            contact_phone: contactPhone.trim(),
            contact_email: contactEmail.trim(),
            status,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Company Updated', `Saved profile for ${result.name}.`);
      } else {
        result = storageService.createCompany(
          {
            name: name.trim(),
            legal_name: legalName.trim() || name.trim(),
            registration_number: registrationNumber.trim(),
            contact_name: contactName.trim(),
            contact_phone: contactPhone.trim(),
            contact_email: contactEmail.trim(),
            status,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Company Created', `Company ${result.name} established in platform.`);
      }

      onSuccess?.(result);
      onClose();
    } catch (err: any) {
      error('Failed to Save Company', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={companyToEdit ? `Edit Company: ${companyToEdit.name}` : 'Add Company Account'}
      description="Register merchant parent corporate entity and operational compliance info"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Company Brand Name *
            </label>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              required
              placeholder="e.g. ABC Retail Group"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Commercial Registration # (CR) *
            </label>
            <input
              type="text"
              value={registrationNumber}
              onChange={e => setRegistrationNumber(e.target.value)}
              required
              placeholder="e.g. CR-9041284"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Legal Entity Name
          </label>
          <input
            type="text"
            value={legalName}
            onChange={e => setLegalName(e.target.value)}
            placeholder="e.g. ABC Retail & Distribution S.A.E."
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Compliance Contact
            </label>
            <input
              type="text"
              value={contactName}
              onChange={e => setContactName(e.target.value)}
              placeholder="Primary officer"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Phone
            </label>
            <input
              type="text"
              value={contactPhone}
              onChange={e => setContactPhone(e.target.value)}
              placeholder="+20 2 2450 1100"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Email
            </label>
            <input
              type="email"
              value={contactEmail}
              onChange={e => setContactEmail(e.target.value)}
              placeholder="ops@company.com"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Status
          </label>
          <select
            value={status}
            onChange={e => setStatus(e.target.value as CompanyStatus)}
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="archived">Archived</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Operating Notes
          </label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            placeholder="Operational scope, billing details, or contractual terms..."
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {isSubmitting ? 'Saving...' : companyToEdit ? 'Save Changes' : 'Create Company'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
