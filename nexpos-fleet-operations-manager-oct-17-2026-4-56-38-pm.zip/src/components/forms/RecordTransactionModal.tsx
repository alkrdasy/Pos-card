import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { CURRENCIES } from '../../lib/constants';
import { TransactionType } from '../../types';
import { AlertCircle, CheckCircle2, ShieldCheck } from 'lucide-react';

interface RecordTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedTerminalId?: string;
}

export const RecordTransactionModal: React.FC<RecordTransactionModalProps> = ({
  isOpen,
  onClose,
  preselectedTerminalId
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();

  const companies = storageService.getCompanies().filter(c => c.status === 'active');
  const merchants = storageService.getMerchants().filter(m => m.status === 'active');
  const terminals = storageService.getTerminals().filter(t => t.status !== 'retired' && t.status !== 'lost');

  const [companyId, setCompanyId] = useState('');
  const [merchantId, setMerchantId] = useState('');
  const [terminalId, setTerminalId] = useState('');
  const [externalReference, setExternalReference] = useState('');
  const [transactionType, setTransactionType] = useState<TransactionType>('sale');
  const [amount, setAmount] = useState('');
  const [currency, setCurrency] = useState('EGP');
  const [transactionTime, setTransactionTime] = useState('');
  const [maskedCard, setMaskedCard] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live duplicate state
  const isDuplicate = externalReference.trim() ? storageService.isDuplicateReference(externalReference.trim()) : false;

  useEffect(() => {
    if (isOpen) {
      const now = new Date();
      // Format local datetime-local string YYYY-MM-DDTHH:mm
      const localIso = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
      setTransactionTime(localIso);
      setExternalReference(`REF-${Date.now().toString().slice(-6)}`);
      setAmount('');
      setMaskedCard('');
      setNotes('');
      setTransactionType('sale');

      if (preselectedTerminalId) {
        const term = terminals.find(t => t.id === preselectedTerminalId);
        if (term) {
          setTerminalId(term.id);
          setCompanyId(term.company_id);
          if (term.merchant_id) setMerchantId(term.merchant_id);
          return;
        }
      }

      if (companies.length > 0) {
        setCompanyId(companies[0].id);
      }
    }
  }, [isOpen, preselectedTerminalId]);

  // Sync merchants and terminals when company changes
  const filteredMerchants = merchants.filter(m => !companyId || m.company_id === companyId);
  const filteredTerminals = terminals.filter(
    t => (!companyId || t.company_id === companyId) && (!merchantId || t.merchant_id === merchantId)
  );

  useEffect(() => {
    if (filteredMerchants.length > 0 && !filteredMerchants.some(m => m.id === merchantId)) {
      setMerchantId(filteredMerchants[0].id);
    }
  }, [companyId]);

  useEffect(() => {
    if (filteredTerminals.length > 0 && !filteredTerminals.some(t => t.id === terminalId)) {
      setTerminalId(filteredTerminals[0].id);
    }
  }, [merchantId, companyId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (isDuplicate) {
      error('DUPLICATE TRANSACTION REFERENCE', `Reference '${externalReference}' already exists in the system.`);
      return;
    }

    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) {
      error('Invalid Amount', 'Please provide a transaction amount greater than 0.');
      return;
    }

    if (!terminalId) {
      error('Terminal Required', 'Please select a valid POS terminal.');
      return;
    }

    setIsSubmitting(true);
    try {
      storageService.recordTransaction(
        {
          company_id: companyId,
          merchant_id: merchantId,
          terminal_id: terminalId,
          operator_id: currentUser.id,
          external_reference: externalReference.trim(),
          masked_reference: maskedCard.trim() || undefined,
          transaction_type: transactionType,
          amount: numAmount,
          currency,
          status: 'completed',
          transaction_time: new Date(transactionTime).toISOString(),
          notes: notes.trim() || undefined
        },
        currentUser
      );

      success('Transaction Recorded', `Reference #${externalReference} successfully logged to fleet ledger.`);
      onClose();
    } catch (err: any) {
      error('Submission Failed', err.message || 'Unable to record transaction.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Record Authorized Transaction"
      description="Log operational transaction record from POS terminal receipt slip"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Compliance Notice */}
        <div className="flex items-center gap-2 p-2.5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-lg text-xs text-slate-600 dark:text-slate-300">
          <ShieldCheck className="w-4 h-4 text-indigo-500 shrink-0" />
          <span>Operational records only. Never enter raw card numbers, CVV, or PINs.</span>
        </div>

        {/* Company & Merchant */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Company *
            </label>
            <select
              value={companyId}
              onChange={e => setCompanyId(e.target.value)}
              required
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Merchant Outlet *
            </label>
            <select
              value={merchantId}
              onChange={e => setMerchantId(e.target.value)}
              required
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              {filteredMerchants.map(m => (
                <option key={m.id} value={m.id}>
                  {m.merchant_name} ({m.merchant_identifier})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Terminal Selection */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            POS Terminal *
          </label>
          <select
            value={terminalId}
            onChange={e => setTerminalId(e.target.value)}
            required
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            {filteredTerminals.map(t => (
              <option key={t.id} value={t.id}>
                {t.terminal_name} [{t.terminal_identifier}] - {t.provider} ({t.status.toUpperCase()})
              </option>
            ))}
          </select>
        </div>

        {/* External Reference with DUPLICATE DETECTION */}
        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300">
              External Reference / POS Slip # *
            </label>
            {isDuplicate ? (
              <span className="flex items-center gap-1 text-[11px] font-semibold text-rose-600 dark:text-rose-400">
                <AlertCircle className="w-3 h-3" /> DUPLICATE REFERENCE DETECTED
              </span>
            ) : (
              externalReference && (
                <span className="flex items-center gap-1 text-[11px] text-emerald-600 dark:text-emerald-400">
                  <CheckCircle2 className="w-3 h-3" /> Reference Available
                </span>
              )
            )}
          </div>
          <input
            type="text"
            value={externalReference}
            onChange={e => setExternalReference(e.target.value)}
            placeholder="e.g. REF-20250217-091"
            required
            className={`w-full text-xs p-2 bg-white dark:bg-slate-800 border rounded-lg focus:ring-1 ${
              isDuplicate
                ? 'border-rose-500 text-rose-700 dark:text-rose-300 focus:ring-rose-500'
                : 'border-slate-300 dark:border-slate-700 focus:ring-indigo-500'
            }`}
          />
          {isDuplicate && (
            <p className="mt-1 text-xs text-rose-600 dark:text-rose-400">
              This transaction reference already exists in the system. Duplicate submissions are strictly blocked for data integrity.
            </p>
          )}
        </div>

        {/* Type, Amount & Currency */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Type *
            </label>
            <select
              value={transactionType}
              onChange={e => setTransactionType(e.target.value as TransactionType)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="sale">Sale</option>
              <option value="refund">Refund</option>
              <option value="void">Void</option>
              <option value="adjustment">Adjustment</option>
              <option value="other">Other</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Amount *
            </label>
            <input
              type="number"
              step="0.01"
              min="0.01"
              value={amount}
              onChange={e => setAmount(e.target.value)}
              placeholder="0.00"
              required
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Currency *
            </label>
            <select
              value={currency}
              onChange={e => setCurrency(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            >
              {CURRENCIES.map(c => (
                <option key={c.code} value={c.code}>
                  {c.code} ({c.symbol})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Date Time & Safe Masked Reference */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Transaction Date & Time *
            </label>
            <input
              type="datetime-local"
              value={transactionTime}
              onChange={e => setTransactionTime(e.target.value)}
              required
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
            </input>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Masked Card Token (Optional)
            </label>
            <input
              type="text"
              value={maskedCard}
              onChange={e => setMaskedCard(e.target.value)}
              placeholder="e.g. VISA ···· 4821"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        {/* Notes */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Operational Notes
          </label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            placeholder="Counter register, invoice reference, or customer remarks..."
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isDuplicate || isSubmitting}
            className={`px-4 py-2 text-xs font-medium text-white rounded-lg transition-colors ${
              isDuplicate
                ? 'bg-slate-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {isSubmitting ? 'Recording...' : 'Record Transaction'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
