import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { ActivityType } from '../../types';

interface RecordActivityModalProps {
  isOpen: boolean;
  onClose: () => void;
  preselectedTerminalId?: string;
}

export const RecordActivityModal: React.FC<RecordActivityModalProps> = ({
  isOpen,
  onClose,
  preselectedTerminalId
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();

  const companies = storageService.getCompanies();
  const terminals = storageService.getTerminals();

  const [companyId, setCompanyId] = useState('');
  const [terminalId, setTerminalId] = useState('');
  const [activityType, setActivityType] = useState<ActivityType>('terminal_updated');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setDescription('');
      setActivityType('terminal_updated');
      if (preselectedTerminalId) {
        const term = terminals.find(t => t.id === preselectedTerminalId);
        if (term) {
          setTerminalId(term.id);
          setCompanyId(term.company_id);
          return;
        }
      }
      if (companies.length > 0) {
        setCompanyId(companies[0].id);
      }
    }
  }, [isOpen, preselectedTerminalId]);

  const filteredTerminals = terminals.filter(t => !companyId || t.company_id === companyId);

  useEffect(() => {
    if (filteredTerminals.length > 0 && !filteredTerminals.some(t => t.id === terminalId)) {
      setTerminalId(filteredTerminals[0].id);
    }
  }, [companyId]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!description.trim()) {
      error('Description Required', 'Please enter a description of the operational event.');
      return;
    }

    const term = terminals.find(t => t.id === terminalId);
    const company = companies.find(c => c.id === companyId);

    setIsSubmitting(true);
    try {
      storageService.logActivity({
        type: activityType,
        terminal_id: term?.id,
        terminal_name: term?.terminal_name,
        company_id: companyId || (term?.company_id || ''),
        company_name: company?.name || term?.company_name,
        user_id: currentUser.id,
        user_name: currentUser.full_name,
        description: description.trim()
      });

      storageService.logAudit({
        user_id: currentUser.id,
        user_name: currentUser.full_name,
        user_email: currentUser.email,
        user_role: currentUser.role,
        action: 'operational_activity_logged',
        entity: 'terminal',
        entity_id: term?.id || 'fleet',
        description: `Logged activity: ${description.trim()}`
      });

      success('Activity Logged', 'Operational event added to timeline.');
      onClose();
    } catch (err: any) {
      error('Failed to Log Activity', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Record Operational Activity"
      description="Document fleet maintenance, field inspection, or hardware handling"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Company *
          </label>
          <select
            value={companyId}
            onChange={e => setCompanyId(e.target.value)}
            required
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            {companies.map(c => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Related POS Terminal
          </label>
          <select
            value={terminalId}
            onChange={e => setTerminalId(e.target.value)}
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            <option value="">General Fleet Action (No specific terminal)</option>
            {filteredTerminals.map(t => (
              <option key={t.id} value={t.id}>
                {t.terminal_name} ({t.terminal_identifier})
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Activity Type *
          </label>
          <select
            value={activityType}
            onChange={e => setActivityType(e.target.value as ActivityType)}
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            <option value="terminal_updated">General Update / Verification</option>
            <option value="maintenance_started">Maintenance Started</option>
            <option value="maintenance_completed">Maintenance Completed</option>
            <option value="location_changed">Location Relocation</option>
            <option value="terminal_activated">Terminal Activated</option>
            <option value="terminal_deactivated">Terminal Deactivated</option>
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Event Description *
          </label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={3}
            placeholder="e.g. Performed monthly tamper sticker inspection and cleaned smart card reader."
            required
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {isSubmitting ? 'Logging...' : 'Save Activity'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
