import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { UploadCloud, Download, CheckCircle2, AlertTriangle, XCircle, FileSpreadsheet } from 'lucide-react';

interface CsvImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  entityType?: 'terminals' | 'companies' | 'merchants' | 'locations';
}

interface ValidationReport {
  total: number;
  valid: any[];
  invalid: { row: number; error: string; data: any }[];
  duplicates: { row: number; reason: string; data: any }[];
}

export const CsvImportModal: React.FC<CsvImportModalProps> = ({
  isOpen,
  onClose,
  entityType = 'terminals'
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();

  const [selectedType, setSelectedType] = useState<'terminals' | 'companies' | 'merchants' | 'locations'>(entityType);
  const [csvRawText, setCsvRawText] = useState('');
  const [report, setReport] = useState<ValidationReport | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  // Download Sample Template
  const downloadTemplate = () => {
    let headers: string[] = [];
    let sampleRow: string[] = [];
    let filename = '';

    if (selectedType === 'terminals') {
      filename = 'terminals_import_template.csv';
      headers = [
        'terminal_name',
        'terminal_identifier',
        'serial_number',
        'provider',
        'model',
        'company_name',
        'merchant_identifier',
        'owner_name',
        'status'
      ];
      sampleRow = [
        'POS Terminal 9901',
        'TID-9901-X',
        'SN-PAX-998811',
        'PAX',
        'PAX A920 Smart POS',
        'ABC Retail Group',
        'MID-1002931',
        'Ahmed Hassan',
        'active'
      ];
    } else if (selectedType === 'companies') {
      filename = 'companies_import_template.csv';
      headers = ['name', 'legal_name', 'registration_number', 'contact_name', 'contact_phone', 'contact_email', 'status'];
      sampleRow = ['Apex Trading Ltd', 'Apex Trading S.A.E.', 'CR-9900112', 'Hazem Nour', '+20 2 2450 9999', 'compliance@apex.com', 'active'];
    } else if (selectedType === 'merchants') {
      filename = 'merchants_import_template.csv';
      headers = ['merchant_name', 'merchant_identifier', 'business_category', 'company_name', 'contact_name', 'contact_phone', 'status'];
      sampleRow = ['Apex Hypermarket', 'MID-9900112', 'FMCG Retail', 'ABC Retail Group', 'Tarek Omar', '+20 100 999 1111', 'active'];
    } else {
      filename = 'locations_import_template.csv';
      headers = ['name', 'address', 'city', 'area', 'company_name', 'contact_name', 'contact_phone'];
      sampleRow = ['New Cairo Outlet', 'Road 90 North, 5th Settlement', 'New Cairo', 'Fifth Settlement', 'ABC Retail Group', 'Omar Soliman', '+20 100 888 7777'];
    }

    const content = `${headers.join(',')}\r\n${sampleRow.join(',')}`;
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = evt => {
      const text = evt.target?.result as string;
      setCsvRawText(text);
      validateData(text);
    };
    reader.readAsText(file);
  };

  const validateData = (text: string) => {
    const lines = text.split(/\r?\n/).filter(line => line.trim().length > 0);
    if (lines.length <= 1) {
      error('Empty File', 'The uploaded file contains no data rows.');
      setReport(null);
      return;
    }

    const headers = lines[0].split(',').map(h => h.trim().replace(/^"|"$/g, ''));
    const rows = lines.slice(1);

    const valid: any[] = [];
    const invalid: ValidationReport['invalid'] = [];
    const duplicates: ValidationReport['duplicates'] = [];

    const existingTerminals = storageService.getTerminals();
    const existingCompanies = storageService.getCompanies();
    const existingMerchants = storageService.getMerchants();

    rows.forEach((line, index) => {
      const rowNum = index + 2; // header is row 1
      const values = line.split(',').map(v => v.trim().replace(/^"|"$/g, ''));
      const rowData: Record<string, string> = {};
      headers.forEach((h, i) => {
        rowData[h] = values[i] || '';
      });

      if (selectedType === 'terminals') {
        const tid = rowData.terminal_identifier;
        const serial = rowData.serial_number;
        const compName = rowData.company_name;

        if (!tid || !serial || !rowData.terminal_name) {
          invalid.push({ row: rowNum, error: 'Missing mandatory fields: terminal_name, terminal_identifier, or serial_number', data: rowData });
          return;
        }

        // Duplicate check
        const dupTid = existingTerminals.find(t => t.terminal_identifier.toLowerCase() === tid.toLowerCase());
        const dupSerial = existingTerminals.find(t => t.serial_number.toLowerCase() === serial.toLowerCase());
        if (dupTid || dupSerial) {
          duplicates.push({ row: rowNum, reason: dupTid ? `Duplicate TID: ${tid}` : `Duplicate Serial: ${serial}`, data: rowData });
          return;
        }

        // Match company
        const matchedComp = existingCompanies.find(c => c.name.toLowerCase() === (compName || '').toLowerCase()) || existingCompanies[0];
        valid.push({
          terminal_name: rowData.terminal_name,
          terminal_identifier: tid,
          serial_number: serial,
          provider: (rowData.provider as any) || 'Ingenico',
          terminal_model: rowData.model || 'Ingenico Move/5000 4G',
          company_id: matchedComp.id,
          owner_name: rowData.owner_name || 'Unassigned',
          status: (rowData.status as any) || 'active',
          installation_date: new Date().toISOString().slice(0, 10),
          notes: 'Imported via CSV batch'
        });
      } else if (selectedType === 'companies') {
        if (!rowData.name || !rowData.registration_number) {
          invalid.push({ row: rowNum, error: 'Missing name or registration_number', data: rowData });
          return;
        }
        const dupCR = existingCompanies.find(c => c.registration_number.toLowerCase() === rowData.registration_number.toLowerCase());
        if (dupCR) {
          duplicates.push({ row: rowNum, reason: `CR '${rowData.registration_number}' already exists`, data: rowData });
          return;
        }
        valid.push({
          name: rowData.name,
          legal_name: rowData.legal_name || rowData.name,
          registration_number: rowData.registration_number,
          contact_name: rowData.contact_name || 'Operations Lead',
          contact_phone: rowData.contact_phone || 'N/A',
          contact_email: rowData.contact_email || 'ops@company.com',
          status: 'active'
        });
      } else {
        valid.push(rowData);
      }
    });

    setReport({
      total: rows.length,
      valid,
      invalid,
      duplicates
    });
  };

  const handleExecuteImport = () => {
    if (!report || !currentUser) return;
    if (report.valid.length === 0) {
      error('Import Blocked', 'No valid rows found to import.');
      return;
    }

    setIsProcessing(true);
    try {
      let importedCount = 0;
      if (selectedType === 'terminals') {
        report.valid.forEach(item => {
          storageService.createTerminal(item, currentUser);
          importedCount++;
        });
      } else if (selectedType === 'companies') {
        report.valid.forEach(item => {
          storageService.createCompany(item, currentUser);
          importedCount++;
        });
      }

      success('Import Complete', `Successfully imported ${importedCount} records. ${report.duplicates.length} duplicates skipped.`);
      onClose();
    } catch (err: any) {
      error('Import Error', err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Batch CSV Fleet Import"
      description="Safely validate and import multiple records with duplicate checks"
      maxWidth="xl"
    >
      <div className="space-y-4">
        {/* Type Selector & Template Download */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-lg">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-indigo-600 dark:text-indigo-400 shrink-0" />
            <div>
              <label className="block text-xs font-semibold text-slate-800 dark:text-slate-200">
                Target Entity
              </label>
              <select
                value={selectedType}
                onChange={e => {
                  setSelectedType(e.target.value as any);
                  setReport(null);
                  setCsvRawText('');
                }}
                className="mt-1 text-xs py-1 px-2 bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-700 rounded-md"
              >
                <option value="terminals">POS Terminals</option>
                <option value="companies">Companies</option>
                <option value="merchants">Merchants</option>
                <option value="locations">Locations</option>
              </select>
            </div>
          </div>

          <button
            type="button"
            onClick={downloadTemplate}
            className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shrink-0"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download CSV Template</span>
          </button>
        </div>

        {/* Upload Dropzone */}
        <div className="border-2 border-dashed border-slate-300 dark:border-slate-700 rounded-xl p-6 text-center hover:border-indigo-400 dark:hover:border-indigo-500 transition-colors">
          <UploadCloud className="w-8 h-8 text-slate-400 mx-auto mb-2" />
          <p className="text-xs font-medium text-slate-800 dark:text-slate-200 mb-1">
            Choose CSV file to import
          </p>
          <p className="text-[11px] text-slate-500 mb-3">
            File must include proper header row matching the template
          </p>
          <label className="inline-block px-3.5 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg cursor-pointer hover:bg-indigo-700 transition-colors">
            Browse Computer
            <input
              type="file"
              accept=".csv,text/csv"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>
        </div>

        {/* Pre-Import Validation Report */}
        {report && (
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-slate-800 dark:text-slate-200">
              Pre-Import Integrity Check
            </h4>

            <div className="grid grid-cols-3 gap-3">
              <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-lg">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Valid Rows</span>
                </div>
                <p className="text-xl font-bold text-emerald-900 dark:text-emerald-100 mt-1 tabular-nums">
                  {report.valid.length}
                </p>
              </div>

              <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-800 rounded-lg">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-700 dark:text-amber-300">
                  <AlertTriangle className="w-4 h-4" />
                  <span>Duplicates</span>
                </div>
                <p className="text-xl font-bold text-amber-900 dark:text-amber-100 mt-1 tabular-nums">
                  {report.duplicates.length}
                </p>
              </div>

              <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-lg">
                <div className="flex items-center gap-1.5 text-xs font-semibold text-rose-700 dark:text-rose-300">
                  <XCircle className="w-4 h-4" />
                  <span>Invalid</span>
                </div>
                <p className="text-xl font-bold text-rose-900 dark:text-rose-100 mt-1 tabular-nums">
                  {report.invalid.length}
                </p>
              </div>
            </div>

            {/* Error detail list */}
            {(report.duplicates.length > 0 || report.invalid.length > 0) && (
              <div className="p-3 bg-slate-50 dark:bg-slate-800/80 rounded-lg text-xs space-y-1.5 max-h-36 overflow-y-auto font-mono text-[11px]">
                {report.duplicates.map((d, i) => (
                  <p key={`dup_${i}`} className="text-amber-700 dark:text-amber-400">
                    Row {d.row}: {d.reason}
                  </p>
                ))}
                {report.invalid.map((inv, i) => (
                  <p key={`inv_${i}`} className="text-rose-600 dark:text-rose-400">
                    Row {inv.row}: {inv.error}
                  </p>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!report || report.valid.length === 0 || isProcessing}
            onClick={handleExecuteImport}
            className={`px-4 py-2 text-xs font-medium text-white rounded-lg transition-colors ${
              !report || report.valid.length === 0
                ? 'bg-slate-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            {isProcessing ? 'Importing...' : `Import ${report?.valid.length || 0} Valid Records`}
          </button>
        </div>
      </div>
    </Modal>
  );
};
