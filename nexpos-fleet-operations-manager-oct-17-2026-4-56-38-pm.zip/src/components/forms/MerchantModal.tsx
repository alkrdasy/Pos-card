import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { Merchant } from '../../types';

interface MerchantModalProps {
  isOpen: boolean;
  onClose: () => void;
  merchantToEdit?: Merchant | null;
  onSuccess?: (merchant: Merchant) => void;
}

export const MerchantModal: React.FC<MerchantModalProps> = ({
  isOpen,
  onClose,
  merchantToEdit,
  onSuccess
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();

  const companies = storageService.getCompanies();
  const locations = storageService.getLocations();

  const [companyId, setCompanyId] = useState('');
  const [merchantName, setMerchantName] = useState('');
  const [merchantIdentifier, setMerchantIdentifier] = useState('');
  const [businessCategory, setBusinessCategory] = useState('Retail & Groceries');
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [locationId, setLocationId] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive' | 'suspended'>('active');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (merchantToEdit) {
        setCompanyId(merchantToEdit.company_id);
        setMerchantName(merchantToEdit.merchant_name);
        setMerchantIdentifier(merchantToEdit.merchant_identifier);
        setBusinessCategory(merchantToEdit.business_category);
        setContactName(merchantToEdit.contact_name);
        setContactPhone(merchantToEdit.contact_phone);
        setLocationId(merchantToEdit.location_id || '');
        setStatus(merchantToEdit.status);
        setNotes(merchantToEdit.notes || '');
      } else {
        setCompanyId(companies[0]?.id || '');
        setMerchantName('');
        setMerchantIdentifier(`MID-${Math.floor(1000000 + Math.random() * 9000000)}`);
        setBusinessCategory('Retail & Groceries');
        setContactName('');
        setContactPhone('');
        setLocationId('');
        setStatus('active');
        setNotes('');
      }
    }
  }, [isOpen, merchantToEdit]);

  const filteredLocations = locations.filter(l => !companyId || l.company_id === companyId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!merchantName.trim()) {
      error('Validation Error', 'Merchant outlet name is required.');
      return;
    }
    if (!merchantIdentifier.trim()) {
      error('Validation Error', 'Merchant Identifier (MID) is required.');
      return;
    }
    if (!companyId) {
      error('Validation Error', 'Parent company is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      let result: Merchant;
      if (merchantToEdit) {
        result = storageService.updateMerchant(
          merchantToEdit.id,
          {
            company_id: companyId,
            merchant_name: merchantName.trim(),
            merchant_identifier: merchantIdentifier.trim(),
            business_category: businessCategory,
            contact_name: contactName.trim(),
            contact_phone: contactPhone.trim(),
            location_id: locationId || undefined,
            status,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Merchant Updated', `Saved profile for ${result.merchant_name}.`);
      } else {
        result = storageService.createMerchant(
          {
            company_id: companyId,
            merchant_name: merchantName.trim(),
            merchant_identifier: merchantIdentifier.trim(),
            business_category: businessCategory,
            contact_name: contactName.trim(),
            contact_phone: contactPhone.trim(),
            location_id: locationId || undefined,
            status,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Merchant Created', `Merchant ${result.merchant_name} created under company.`);
      }

      onSuccess?.(result);
      onClose();
    } catch (err: any) {
      error('Failed to Save Merchant', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={merchantToEdit ? `Edit Merchant: ${merchantToEdit.merchant_name}` : 'Create Merchant Outlet'}
      description="Configure merchant branch, acquiring MID, and physical location"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Parent Operating Company *
          </label>
          <select
            value={companyId}
            onChange={e => setCompanyId(e.target.value)}
            required
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            {companies.map(c => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Merchant Name *
            </label>
            <input
              type="text"
              value={merchantName}
              onChange={e => setMerchantName(e.target.value)}
              required
              placeholder="e.g. ABC Downtown Market"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Merchant Identifier (MID) *
            </label>
            <input
              type="text"
              value={merchantIdentifier}
              onChange={e => setMerchantIdentifier(e.target.value)}
              required
              placeholder="e.g. MID-1002931"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Business Category
            </label>
            <input
              type="text"
              value={businessCategory}
              onChange={e => setBusinessCategory(e.target.value)}
              placeholder="e.g. Consumer Electronics"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Branch Location
            </label>
            <select
              value={locationId}
              onChange={e => setLocationId(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">No Location Assigned</option>
              {filteredLocations.map(l => (
                <option key={l.id} value={l.id}>
                  {l.name} ({l.city})
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Branch Manager / Contact
            </label>
            <input
              type="text"
              value={contactName}
              onChange={e => setContactName(e.target.value)}
              placeholder="Store lead"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Contact Phone
            </label>
            <input
              type="text"
              value={contactPhone}
              onChange={e => setContactPhone(e.target.value)}
              placeholder="+20 100 000 0000"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Status
          </label>
          <select
            value={status}
            onChange={e => setStatus(e.target.value as any)}
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {isSubmitting ? 'Saving...' : merchantToEdit ? 'Save Changes' : 'Create Merchant'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
