import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { UserProfile, UserRole, UserStatus } from '../../types';

interface UserModalProps {
  isOpen: boolean;
  onClose: () => void;
  userToEdit?: UserProfile | null;
  onSuccess?: (user: UserProfile) => void;
}

export const UserModal: React.FC<UserModalProps> = ({
  isOpen,
  onClose,
  userToEdit,
  onSuccess
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();
  const companies = storageService.getCompanies();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('operator');
  const [companyId, setCompanyId] = useState('');
  const [status, setStatus] = useState<UserStatus>('active');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (userToEdit) {
        setFullName(userToEdit.full_name);
        setEmail(userToEdit.email);
        setPhone(userToEdit.phone || '');
        setRole(userToEdit.role);
        setCompanyId(userToEdit.company_id || '');
        setStatus(userToEdit.status);
      } else {
        setFullName('');
        setEmail('');
        setPhone('');
        setRole('operator');
        setCompanyId(companies[0]?.id || '');
        setStatus('active');
      }
    }
  }, [isOpen, userToEdit]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!fullName.trim()) {
      error('Full Name Required', 'Please enter a name for the operator.');
      return;
    }
    if (!email.trim() || !email.includes('@')) {
      error('Valid Email Required', 'Please provide a valid work email.');
      return;
    }

    setIsSubmitting(true);
    try {
      let result: UserProfile;
      if (userToEdit) {
        result = storageService.updateUser(
          userToEdit.id,
          {
            full_name: fullName.trim(),
            email: email.trim(),
            phone: phone.trim(),
            role,
            company_id: companyId || undefined,
            status
          },
          currentUser
        );
        success('User Profile Updated', `Saved profile for ${result.full_name}.`);
      } else {
        result = storageService.createUser(
          {
            auth_user_id: `auth_${Date.now()}`,
            full_name: fullName.trim(),
            email: email.trim(),
            phone: phone.trim(),
            role,
            company_id: companyId || undefined,
            status
          },
          currentUser
        );
        success('Operator Added', `User ${result.full_name} registered with role ${result.role}.`);
      }

      onSuccess?.(result);
      onClose();
    } catch (err: any) {
      error('Failed to Save User', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={userToEdit ? `Edit User: ${userToEdit.full_name}` : 'Create Operator / User Account'}
      description="Configure role permissions and company assignments"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Full Name *
          </label>
          <input
            type="text"
            value={fullName}
            onChange={e => setFullName(e.target.value)}
            required
            placeholder="e.g. Mostafa Mahmoud"
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Email Address *
            </label>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
              placeholder="operator@company.com"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Phone Number
            </label>
            <input
              type="tel"
              value={phone}
              onChange={e => setPhone(e.target.value)}
              placeholder="+20 100 000 0000"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Access Role *
            </label>
            <select
              value={role}
              onChange={e => setRole(e.target.value as UserRole)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="operator">Operator (Field & POS record)</option>
              <option value="admin">Admin (Manage company fleet)</option>
              <option value="super_admin">Super Admin (Global control)</option>
              <option value="viewer">Viewer (Read-only)</option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Assigned Company
            </label>
            <select
              value={companyId}
              onChange={e => setCompanyId(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">Global / Unattached</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Account Status
          </label>
          <select
            value={status}
            onChange={e => setStatus(e.target.value as UserStatus)}
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {isSubmitting ? 'Saving...' : userToEdit ? 'Save Changes' : 'Create Account'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
