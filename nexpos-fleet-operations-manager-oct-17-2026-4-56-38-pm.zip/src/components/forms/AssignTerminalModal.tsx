import React, { useState } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { Terminal } from '../../types';
import { UserCheck, ShieldAlert } from 'lucide-react';

interface AssignTerminalModalProps {
  isOpen: boolean;
  onClose: () => void;
  terminal: Terminal | null;
  onAssigned?: (updated: Terminal) => void;
}

export const AssignTerminalModal: React.FC<AssignTerminalModalProps> = ({
  isOpen,
  onClose,
  terminal,
  onAssigned
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();
  const users = storageService.getUsers().filter(u => u.status === 'active');

  const [newUserId, setNewUserId] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!terminal) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!newUserId) {
      error('Operator Required', 'Please select a designated operator or user.');
      return;
    }

    setIsSubmitting(true);
    try {
      const updated = storageService.assignTerminal(
        terminal.id,
        newUserId,
        currentUser,
        notes.trim() || undefined
      );

      const targetUser = users.find(u => u.id === newUserId);
      success(
        'Terminal Assigned',
        `Assigned ${terminal.terminal_name} to ${targetUser?.full_name || 'operator'}. Historical record created.`
      );
      onAssigned?.(updated);
      onClose();
    } catch (err: any) {
      error('Assignment Failed', err.message || 'Unable to complete assignment.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleUnassign = () => {
    if (!currentUser) return;
    setIsSubmitting(true);
    try {
      const updated = storageService.unassignTerminal(
        terminal.id,
        currentUser,
        notes.trim() || 'Unassigned by administrator'
      );
      success('Terminal Unassigned', `${terminal.terminal_name} is now unassigned.`);
      onAssigned?.(updated);
      onClose();
    } catch (err: any) {
      error('Failed to Unassign', err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Assign Terminal: ${terminal.terminal_name}`}
      description="Transfer hardware responsibility and retain historical audit custody"
      maxWidth="md"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Current status banner */}
        <div className="p-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg flex items-start gap-3">
          <UserCheck className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0" />
          <div className="text-xs">
            <p className="font-semibold text-slate-800 dark:text-slate-200">
              Current Assigned Custodian: {terminal.assigned_user_name || 'Unassigned'}
            </p>
            <p className="text-slate-500 dark:text-slate-400 mt-0.5">
              Terminal ID: <span className="font-mono">{terminal.terminal_identifier}</span> · Serial: <span className="font-mono">{terminal.serial_number}</span>
            </p>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            New Responsible Operator / User *
          </label>
          <select
            value={newUserId}
            onChange={e => setNewUserId(e.target.value)}
            required
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          >
            <option value="">Select an operator...</option>
            {users.map(u => (
              <option key={u.id} value={u.id}>
                {u.full_name} ({u.role.replace('_', ' ')}) - {u.email}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Operational Handover Reason / Custody Notes
          </label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            placeholder="e.g. Shift rotation handover, branch reassignment, or field maintenance dispatch."
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center justify-between pt-3 border-t border-slate-100 dark:border-slate-800">
          {terminal.assigned_user_id ? (
            <button
              type="button"
              onClick={handleUnassign}
              disabled={isSubmitting}
              className="text-xs font-medium text-rose-600 hover:text-rose-700 dark:text-rose-400"
            >
              Unassign Current User
            </button>
          ) : <div />}

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
            >
              {isSubmitting ? 'Assigning...' : 'Confirm Assignment'}
            </button>
          </div>
        </div>
      </form>
    </Modal>
  );
};
