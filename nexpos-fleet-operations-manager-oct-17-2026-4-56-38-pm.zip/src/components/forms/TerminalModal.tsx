import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { Terminal, TerminalStatus, TerminalProvider } from '../../types';
import { TERMINAL_PROVIDERS, TERMINAL_MODELS } from '../../lib/constants';

interface TerminalModalProps {
  isOpen: boolean;
  onClose: () => void;
  terminalToEdit?: Terminal | null;
  onSuccess?: (terminal: Terminal) => void;
}

export const TerminalModal: React.FC<TerminalModalProps> = ({
  isOpen,
  onClose,
  terminalToEdit,
  onSuccess
}) => {
  const { currentUser } = useAuth();
  const { success, error } = useToast();

  const companies = storageService.getCompanies();
  const merchants = storageService.getMerchants();
  const locations = storageService.getLocations();
  const users = storageService.getUsers();

  const [terminalName, setTerminalName] = useState('');
  const [terminalIdentifier, setTerminalIdentifier] = useState('');
  const [serialNumber, setSerialNumber] = useState('');
  const [provider, setProvider] = useState<TerminalProvider>('Ingenico');
  const [terminalModel, setTerminalModel] = useState(TERMINAL_MODELS[0]);
  const [companyId, setCompanyId] = useState('');
  const [merchantId, setMerchantId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [assignedUserId, setAssignedUserId] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [status, setStatus] = useState<TerminalStatus>('active');
  const [installationDate, setInstallationDate] = useState('');
  const [notes, setNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      if (terminalToEdit) {
        setTerminalName(terminalToEdit.terminal_name);
        setTerminalIdentifier(terminalToEdit.terminal_identifier);
        setSerialNumber(terminalToEdit.serial_number);
        setProvider(terminalToEdit.provider);
        setTerminalModel(terminalToEdit.terminal_model);
        setCompanyId(terminalToEdit.company_id);
        setMerchantId(terminalToEdit.merchant_id || '');
        setLocationId(terminalToEdit.location_id || '');
        setAssignedUserId(terminalToEdit.assigned_user_id || '');
        setOwnerName(terminalToEdit.owner_name);
        setStatus(terminalToEdit.status);
        setInstallationDate(terminalToEdit.installation_date || new Date().toISOString().slice(0, 10));
        setNotes(terminalToEdit.notes || '');
      } else {
        const nextNum = Math.floor(1000 + Math.random() * 9000);
        setTerminalName(`POS Terminal ${nextNum}`);
        setTerminalIdentifier(`TID-${nextNum}-X`);
        setSerialNumber(`SN-POS-${Math.floor(100000 + Math.random() * 900000)}`);
        setProvider('Ingenico');
        setTerminalModel(TERMINAL_MODELS[0]);
        setCompanyId(companies[0]?.id || '');
        setMerchantId('');
        setLocationId('');
        setAssignedUserId('');
        setOwnerName('');
        setStatus('active');
        setInstallationDate(new Date().toISOString().slice(0, 10));
        setNotes('');
      }
    }
  }, [isOpen, terminalToEdit]);

  const filteredMerchants = merchants.filter(m => !companyId || m.company_id === companyId);
  const filteredLocations = locations.filter(l => !companyId || l.company_id === companyId);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;

    if (!terminalName.trim()) {
      error('Validation Error', 'Terminal name is required.');
      return;
    }

    if (!terminalIdentifier.trim()) {
      error('Validation Error', 'Terminal Identifier (TID) is required.');
      return;
    }

    if (!serialNumber.trim()) {
      error('Validation Error', 'Hardware Serial Number is required.');
      return;
    }

    if (!companyId) {
      error('Validation Error', 'Company selection is required.');
      return;
    }

    setIsSubmitting(true);
    try {
      let result: Terminal;
      if (terminalToEdit) {
        result = storageService.updateTerminal(
          terminalToEdit.id,
          {
            terminal_name: terminalName.trim(),
            terminal_identifier: terminalIdentifier.trim(),
            serial_number: serialNumber.trim(),
            provider,
            terminal_model: terminalModel,
            company_id: companyId,
            merchant_id: merchantId || undefined,
            location_id: locationId || undefined,
            assigned_user_id: assignedUserId || undefined,
            owner_name: ownerName.trim() || 'Unassigned',
            status,
            installation_date: installationDate,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Terminal Updated', `Terminal ${result.terminal_name} saved successfully.`);
      } else {
        result = storageService.createTerminal(
          {
            terminal_name: terminalName.trim(),
            terminal_identifier: terminalIdentifier.trim(),
            serial_number: serialNumber.trim(),
            provider,
            terminal_model: terminalModel,
            company_id: companyId,
            merchant_id: merchantId || undefined,
            location_id: locationId || undefined,
            assigned_user_id: assignedUserId || undefined,
            owner_name: ownerName.trim() || 'Unassigned',
            status,
            installation_date: installationDate,
            notes: notes.trim() || undefined
          },
          currentUser
        );
        success('Terminal Created', `Terminal ${result.terminal_name} registered into fleet.`);
      }

      onSuccess?.(result);
      onClose();
    } catch (err: any) {
      error('Operation Failed', err.message || 'Error saving terminal.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={terminalToEdit ? `Edit Terminal: ${terminalToEdit.terminal_name}` : 'Register New POS Terminal'}
      description="Configure hardware credentials, company assignment, and location tracking"
      maxWidth="xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Terminal Name & Identifier */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Terminal Name *
            </label>
            <input
              type="text"
              value={terminalName}
              onChange={e => setTerminalName(e.target.value)}
              required
              placeholder="e.g. POS-1042 (Lane 3)"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Terminal Identifier (TID) *
            </label>
            <input
              type="text"
              value={terminalIdentifier}
              onChange={e => setTerminalIdentifier(e.target.value)}
              required
              placeholder="e.g. TID-1042-A"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>
        </div>

        {/* Hardware Serial & Provider */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Hardware Serial Number (Unique) *
            </label>
            <input
              type="text"
              value={serialNumber}
              onChange={e => setSerialNumber(e.target.value)}
              required
              placeholder="e.g. SN-ING-908123"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-mono"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Provider / Hardware OEM *
            </label>
            <select
              value={provider}
              onChange={e => setProvider(e.target.value as TerminalProvider)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              {TERMINAL_PROVIDERS.map(p => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Model & Status */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Terminal Model *
            </label>
            <select
              value={terminalModel}
              onChange={e => setTerminalModel(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              {TERMINAL_MODELS.map(m => (
                <option key={m} value={m}>
                  {m}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Terminal Operational Status *
            </label>
            <select
              value={status}
              onChange={e => setStatus(e.target.value as TerminalStatus)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500 font-semibold"
            >
              <option value="active">ACTIVE</option>
              <option value="inactive">INACTIVE</option>
              <option value="maintenance">MAINTENANCE</option>
              <option value="lost">LOST</option>
              <option value="retired">RETIRED</option>
            </select>
          </div>
        </div>

        {/* Company & Merchant */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Company *
            </label>
            <select
              value={companyId}
              onChange={e => setCompanyId(e.target.value)}
              required
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Assigned Merchant Outlet
            </label>
            <select
              value={merchantId}
              onChange={e => setMerchantId(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">No Specific Merchant</option>
              {filteredMerchants.map(m => (
                <option key={m.id} value={m.id}>
                  {m.merchant_name} ({m.merchant_identifier})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Location & Assigned User */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Branch Location
            </label>
            <select
              value={locationId}
              onChange={e => setLocationId(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">No Location Assigned</option>
              {filteredLocations.map(l => (
                <option key={l.id} value={l.id}>
                  {l.name} - {l.city}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Designated Operator / User
            </label>
            <select
              value={assignedUserId}
              onChange={e => {
                const uId = e.target.value;
                setAssignedUserId(uId);
                const u = users.find(x => x.id === uId);
                if (u) setOwnerName(u.full_name);
              }}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            >
              <option value="">Unassigned</option>
              {users.map(u => (
                <option key={u.id} value={u.id}>
                  {u.full_name} ({u.role})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Installation Date & Notes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Installation Date
            </label>
            <input
              type="date"
              value={installationDate}
              onChange={e => setInstallationDate(e.target.value)}
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Owner Name Display
            </label>
            <input
              type="text"
              value={ownerName}
              onChange={e => setOwnerName(e.target.value)}
              placeholder="Responsible individual"
              className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
            Hardware & Connectivity Notes
          </label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            placeholder="e.g. Primary SIM slot 1 with Vodafone 4G; Wi-Fi backup on SSID 'POS_Secure'."
            className="w-full text-xs p-2 bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 dark:bg-slate-800 dark:text-slate-300 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSubmitting}
            className="px-4 py-2 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors"
          >
            {isSubmitting ? 'Saving...' : terminalToEdit ? 'Save Changes' : 'Register Terminal'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
