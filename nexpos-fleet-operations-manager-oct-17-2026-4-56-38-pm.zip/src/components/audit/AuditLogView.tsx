import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  Download,
  Search,
  Filter,
  Code,
  Clock,
  User,
  ChevronDown,
  ChevronRight,
  Lock
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { formatDateTime, exportToCsv } from '../../lib/utils';
import { AuditLog } from '../../types';

export const AuditLogView: React.FC = () => {
  const auditLogs = storageService.getAuditLogs();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEntity, setSelectedEntity] = useState('');
  const [expandedLogId, setExpandedLogId] = useState<string | null>(null);

  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 15;

  const filtered = useMemo(() => {
    return auditLogs.filter(log => {
      if (selectedEntity && log.entity !== selectedEntity) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          log.description.toLowerCase().includes(q) ||
          log.user_name.toLowerCase().includes(q) ||
          log.action.toLowerCase().includes(q) ||
          log.entity_id.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [auditLogs, selectedEntity, searchQuery]);

  const paginated = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, currentPage]);

  const totalPages = Math.ceil(filtered.length / pageSize) || 1;

  const handleExportCsv = () => {
    const rows = filtered.map(log => ({
      timestamp: log.created_at,
      user_name: log.user_name,
      user_email: log.user_email,
      role: log.user_role,
      action: log.action,
      entity: log.entity,
      entity_id: log.entity_id,
      description: log.description,
      ip_address: log.ip_address || 'Internal',
      metadata: JSON.stringify(log.metadata || {})
    }));
    exportToCsv('compliance_audit_trail', rows);
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
              Immutable Audit Trail
            </h2>
            <span className="flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold text-emerald-700 bg-emerald-50 dark:bg-emerald-950/40 dark:text-emerald-300 border border-emerald-200/60 rounded">
              <Lock className="w-3 h-3" /> Append-Only Log
            </span>
          </div>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Cryptographically sealed system record of every configuration change, terminal assignment, and transaction entry
          </p>
        </div>

        <button
          type="button"
          onClick={handleExportCsv}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs self-start sm:self-auto"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Audit Log (CSV)</span>
        </button>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search audit trail by description, operator name, action, or entity ID..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <select
          value={selectedEntity}
          onChange={e => setSelectedEntity(e.target.value)}
          className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
        >
          <option value="">All Entities</option>
          <option value="terminal">Terminals</option>
          <option value="assignment">Assignments</option>
          <option value="transaction">Transactions</option>
          <option value="company">Companies</option>
          <option value="merchant">Merchants</option>
          <option value="location">Locations</option>
          <option value="user">Users</option>
          <option value="alert">Alerts</option>
          <option value="auth">Auth & Persona</option>
        </select>
      </div>

      {/* Table view */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4 font-semibold">Timestamp</th>
                <th className="py-3 px-4 font-semibold">User & Role</th>
                <th className="py-3 px-4 font-semibold">Action</th>
                <th className="py-3 px-4 font-semibold">Entity</th>
                <th className="py-3 px-4 font-semibold">Description</th>
                <th className="py-3 px-4 font-semibold">IP Address</th>
                <th className="py-3 px-4 font-semibold text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {paginated.map(log => {
                const isExpanded = expandedLogId === log.id;

                return (
                  <React.Fragment key={log.id}>
                    <tr
                      onClick={() => setExpandedLogId(isExpanded ? null : log.id)}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-500 tabular-nums whitespace-nowrap">
                        {formatDateTime(log.created_at)}
                      </td>
                      <td className="py-3 px-4 whitespace-nowrap">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">
                          {log.user_name}
                        </div>
                        <div className="text-[10px] text-slate-500 uppercase font-mono">
                          {log.user_role}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono font-medium text-indigo-600 dark:text-indigo-400 whitespace-nowrap">
                        {log.action}
                      </td>
                      <td className="py-3 px-4 uppercase text-[10px] font-semibold text-slate-500 whitespace-nowrap">
                        {log.entity}
                      </td>
                      <td className="py-3 px-4 text-slate-800 dark:text-slate-200 max-w-md truncate">
                        {log.description}
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                        {log.ip_address || '197.38.102.14'}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <button
                          type="button"
                          className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                        >
                          <ChevronDown
                            className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                          />
                        </button>
                      </td>
                    </tr>

                    {/* Metadata JSON Drawer */}
                    {isExpanded && (
                      <tr className="bg-slate-50/80 dark:bg-slate-950/60">
                        <td colSpan={7} className="p-4">
                          <div className="p-3 bg-slate-900 text-slate-100 rounded-lg text-xs font-mono overflow-x-auto space-y-1">
                            <div className="flex items-center justify-between text-slate-400 text-[10px] uppercase border-b border-slate-800 pb-1 mb-1">
                              <span>Audit Record Payload ID: {log.id}</span>
                              <span>Target ID: {log.entity_id}</span>
                            </div>
                            <pre className="text-[11px] leading-relaxed">
                              {JSON.stringify(log.metadata || { description: log.description }, null, 2)}
                            </pre>
                          </div>
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between px-2 pt-2 text-xs text-slate-500">
          <span>
            Showing {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, filtered.length)} of {filtered.length} audit logs
          </span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              className="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-40"
            >
              Previous
            </button>
            <span className="px-2 font-mono">
              {currentPage} / {totalPages}
            </span>
            <button
              type="button"
              disabled={currentPage === totalPages}
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              className="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-40"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
