import React, { useState, useMemo } from 'react';
import {
  Building2,
  Plus,
  Download,
  Search,
  Store,
  CreditCard,
  MapPin,
  ChevronRight,
  MoreVertical,
  Archive
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { exportToCsv, formatDate } from '../../lib/utils';
import { Company } from '../../types';

interface CompaniesListViewProps {
  onSelectCompany: (companyId: string) => void;
  onOpenCreateModal: () => void;
  onOpenEditModal: (company: Company) => void;
}

export const CompaniesListView: React.FC<CompaniesListViewProps> = ({
  onSelectCompany,
  onOpenCreateModal,
  onOpenEditModal
}) => {
  const { can } = useAuth();
  const companies = storageService.getCompanies();
  const merchants = storageService.getMerchants();
  const terminals = storageService.getTerminals();
  const locations = storageService.getLocations();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');

  const filtered = useMemo(() => {
    return companies.filter(c => {
      if (selectedStatus && c.status !== selectedStatus) return false;
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          c.name.toLowerCase().includes(q) ||
          c.legal_name.toLowerCase().includes(q) ||
          c.registration_number.toLowerCase().includes(q)
        );
      }
      return true;
    });
  }, [companies, selectedStatus, searchQuery]);

  const handleExportCsv = () => {
    const rows = filtered.map(c => ({
      name: c.name,
      legal_name: c.legal_name,
      registration_number: c.registration_number,
      contact_name: c.contact_name,
      contact_phone: c.contact_phone,
      contact_email: c.contact_email,
      status: c.status,
      created_at: c.created_at
    }));
    exportToCsv('companies_directory', rows);
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Companies
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Operating merchant parent companies and corporate accounts
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {can('manage:companies') && (
            <button
              type="button"
              onClick={onOpenCreateModal}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Company</span>
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search by company name, registration CR..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <select
          value={selectedStatus}
          onChange={e => setSelectedStatus(e.target.value)}
          className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
        >
          <option value="">All Statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
          <option value="archived">Archived</option>
        </select>
      </div>

      {/* Table view */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4 font-semibold">Company</th>
                <th className="py-3 px-4 font-semibold">Commercial Reg. (CR)</th>
                <th className="py-3 px-4 font-semibold text-center">Merchants</th>
                <th className="py-3 px-4 font-semibold text-center">POS Terminals</th>
                <th className="py-3 px-4 font-semibold text-center">Locations</th>
                <th className="py-3 px-4 font-semibold">Compliance Contact</th>
                <th className="py-3 px-4 font-semibold">Status</th>
                <th className="py-3 px-4 font-semibold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {filtered.map(comp => {
                const compMerchants = merchants.filter(m => m.company_id === comp.id);
                const compTerminals = terminals.filter(t => t.company_id === comp.id);
                const compLocations = locations.filter(l => l.company_id === comp.id);

                return (
                  <tr
                    key={comp.id}
                    onClick={() => onSelectCompany(comp.id)}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-4">
                      <div className="font-bold text-slate-900 dark:text-slate-100">
                        {comp.name}
                      </div>
                      <div className="text-[11px] text-slate-500 truncate max-w-xs">
                        {comp.legal_name}
                      </div>
                    </td>
                    <td className="py-3 px-4 font-mono font-medium text-slate-700 dark:text-slate-300">
                      {comp.registration_number}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-slate-800 dark:text-slate-200 tabular-nums">
                      {compMerchants.length}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">
                      {compTerminals.length}
                    </td>
                    <td className="py-3 px-4 text-center font-bold text-slate-800 dark:text-slate-200 tabular-nums">
                      {compLocations.length}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800 dark:text-slate-200">
                        {comp.contact_name}
                      </div>
                      <div className="text-[11px] text-slate-500">
                        {comp.contact_email}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      <StatusBadge type="company" status={comp.status} />
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                        {can('edit:company') && (
                          <button
                            type="button"
                            onClick={() => onOpenEditModal(comp)}
                            className="px-2 py-1 text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                          >
                            Edit
                          </button>
                        )}
                        <button
                          type="button"
                          onClick={() => onSelectCompany(comp.id)}
                          className="p-1 text-slate-400 hover:text-slate-700"
                        >
                          <ChevronRight className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
