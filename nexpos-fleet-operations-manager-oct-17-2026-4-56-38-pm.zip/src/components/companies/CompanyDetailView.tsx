import React, { useState } from 'react';
import {
  ArrowLeft,
  Building2,
  Store,
  CreditCard,
  MapPin,
  Receipt,
  Activity,
  Edit,
  Archive,
  Phone,
  Mail,
  FileText
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { formatCurrency, formatDateTime } from '../../lib/utils';
import { Company } from '../../types';

interface CompanyDetailViewProps {
  companyId: string;
  onBack: () => void;
  onOpenEditModal: (company: Company) => void;
  onSelectTerminal: (terminalId: string) => void;
  onSelectMerchant: (merchantId: string) => void;
}

export const CompanyDetailView: React.FC<CompanyDetailViewProps> = ({
  companyId,
  onBack,
  onOpenEditModal,
  onSelectTerminal,
  onSelectMerchant
}) => {
  const { can, currentUser } = useAuth();
  const { success, error } = useToast();

  const company = storageService.getCompanyById(companyId);
  const [activeTab, setActiveTab] = useState<'overview' | 'merchants' | 'terminals' | 'locations' | 'transactions' | 'activity'>('overview');

  if (!company) {
    return (
      <div className="p-8 text-center space-y-3">
        <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Company not found</p>
        <button onClick={onBack} className="px-3 py-1.5 text-xs text-white bg-indigo-600 rounded-md">
          Back to companies
        </button>
      </div>
    );
  }

  const merchants = storageService.getMerchants().filter(m => m.company_id === company.id);
  const terminals = storageService.getTerminals().filter(t => t.company_id === company.id);
  const locations = storageService.getLocations().filter(l => l.company_id === company.id);
  const transactions = storageService.getTransactions().filter(t => t.company_id === company.id);
  const activities = storageService.getActivities().filter(a => a.company_id === company.id);

  const handleArchive = () => {
    if (!currentUser) return;
    try {
      storageService.archiveCompany(company.id, currentUser);
      success('Company Archived', `${company.name} has been placed in archive.`);
    } catch (err: any) {
      error('Failed to archive company', err.message);
    }
  };

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-150">
      <div className="flex items-center gap-2 text-xs text-slate-500">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-400 hover:text-slate-900 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Companies</span>
        </button>
        <span>/</span>
        <span className="text-slate-800 dark:text-slate-200 font-medium truncate max-w-xs">
          {company.name}
        </span>
      </div>

      {/* Header Banner */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                {company.name}
              </h2>
              <StatusBadge type="company" status={company.status} />
            </div>
            <p className="text-xs text-slate-500 mt-1">
              Legal: <strong className="text-slate-700 dark:text-slate-300">{company.legal_name}</strong> · CR: <strong className="font-mono text-indigo-600 dark:text-indigo-400">{company.registration_number}</strong>
            </p>
          </div>

          <div className="flex items-center gap-2">
            {can('edit:company') && (
              <button
                type="button"
                onClick={() => onOpenEditModal(company)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit Profile</span>
              </button>
            )}
            {can('manage:companies') && company.status !== 'archived' && (
              <button
                type="button"
                onClick={handleArchive}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 border border-rose-200 dark:border-rose-800 rounded-lg transition-colors"
              >
                <Archive className="w-3.5 h-3.5" />
                <span>Archive</span>
              </button>
            )}
          </div>
        </div>

        {/* Metric counts */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div>
            <span className="text-slate-500 block text-[11px]">Merchants</span>
            <span className="text-lg font-bold text-slate-800 dark:text-slate-200 tabular-nums">{merchants.length} Outlets</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Fleet POS Terminals</span>
            <span className="text-lg font-bold text-indigo-600 dark:text-indigo-400 tabular-nums">{terminals.length} Hardware Units</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Operating Locations</span>
            <span className="text-lg font-bold text-slate-800 dark:text-slate-200 tabular-nums">{locations.length} Sites</span>
          </div>
          <div>
            <span className="text-slate-500 block text-[11px]">Recorded Volume</span>
            <span className="text-lg font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
              {formatCurrency(transactions.reduce((acc, t) => acc + t.amount, 0), 'EGP')}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
        {(['overview', 'merchants', 'terminals', 'locations', 'transactions', 'activity'] as const).map(tab => (
          <button
            key={tab}
            type="button"
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 text-xs font-semibold border-b-2 transition-colors capitalize whitespace-nowrap ${
              activeTab === tab
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Tab 1: Overview */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 text-xs">
            <h3 className="font-semibold text-slate-500 uppercase tracking-wider text-[11px]">
              Corporate & Registration Info
            </h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Commercial Registration (CR)</span>
                <span className="font-mono font-bold text-slate-900 dark:text-slate-100">{company.registration_number}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Legal Registered Name</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{company.legal_name}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Compliance Status</span>
                <StatusBadge type="company" status={company.status} />
              </div>
            </div>
          </div>

          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 text-xs">
            <h3 className="font-semibold text-slate-500 uppercase tracking-wider text-[11px]">
              Compliance & Contact Officers
            </h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Officer Name</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{company.contact_name}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Contact Phone</span>
                <span className="font-mono text-slate-800 dark:text-slate-200">{company.contact_phone}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Official Email</span>
                <span className="font-medium text-indigo-600 dark:text-indigo-400">{company.contact_email}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Merchants */}
      {activeTab === 'merchants' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
          <div className="p-4 border-b border-slate-100 dark:border-slate-800 flex justify-between items-center">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Merchants Under {company.name} ({merchants.length})
            </h3>
          </div>
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 text-[10px] uppercase">
                <th className="py-3 px-4 font-semibold">Merchant Outlet</th>
                <th className="py-3 px-4 font-semibold">MID</th>
                <th className="py-3 px-4 font-semibold">Category</th>
                <th className="py-3 px-4 font-semibold">Branch Location</th>
                <th className="py-3 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {merchants.map(m => (
                <tr
                  key={m.id}
                  onClick={() => onSelectMerchant(m.id)}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer"
                >
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                    {m.merchant_name}
                  </td>
                  <td className="py-3 px-4 font-mono font-medium text-indigo-600 dark:text-indigo-400">
                    {m.merchant_identifier}
                  </td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                    {m.business_category}
                  </td>
                  <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                    {m.location_name || '—'}
                  </td>
                  <td className="py-3 px-4">
                    <span className="px-2 py-0.5 text-[10px] font-semibold uppercase bg-emerald-50 text-emerald-700 rounded">
                      {m.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Tab 3: Terminals */}
      {activeTab === 'terminals' && (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 text-[10px] uppercase">
                <th className="py-3 px-4 font-semibold">Terminal</th>
                <th className="py-3 px-4 font-semibold">TID</th>
                <th className="py-3 px-4 font-semibold">Provider / Model</th>
                <th className="py-3 px-4 font-semibold">Serial</th>
                <th className="py-3 px-4 font-semibold">Custodian</th>
                <th className="py-3 px-4 font-semibold">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {terminals.map(t => (
                <tr
                  key={t.id}
                  onClick={() => onSelectTerminal(t.id)}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer"
                >
                  <td className="py-3 px-4 font-semibold text-slate-900 dark:text-slate-100">
                    {t.terminal_name}
                  </td>
                  <td className="py-3 px-4 font-mono text-indigo-600 dark:text-indigo-400 font-semibold">
                    {t.terminal_identifier}
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    {t.provider} · {t.terminal_model}
                  </td>
                  <td className="py-3 px-4 font-mono text-[11px] text-slate-500">
                    {t.serial_number}
                  </td>
                  <td className="py-3 px-4 text-slate-700 dark:text-slate-300">
                    {t.assigned_user_name || t.owner_name}
                  </td>
                  <td className="py-3 px-4">
                    <StatusBadge type="terminal" status={t.status} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
