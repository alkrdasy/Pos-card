import React, { useState, useMemo } from 'react';
import {
  Search,
  Filter,
  Download,
  Plus,
  UploadCloud,
  CreditCard,
  Building2,
  MapPin,
  User,
  SlidersHorizontal,
  ChevronRight,
  MoreVertical,
  Wrench,
  UserCheck
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { EmptyState } from '../common/EmptyState';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { exportToCsv, formatRelativeTime, formatDate } from '../../lib/utils';
import { Terminal, TerminalStatus, TerminalProvider } from '../../types';
import { TERMINAL_PROVIDERS } from '../../lib/constants';

interface TerminalsListViewProps {
  onSelectTerminal: (terminalId: string) => void;
  onOpenCreateModal: () => void;
  onOpenAssignModal: (terminal: Terminal) => void;
  onOpenImportModal: () => void;
}

export const TerminalsListView: React.FC<TerminalsListViewProps> = ({
  onSelectTerminal,
  onOpenCreateModal,
  onOpenAssignModal,
  onOpenImportModal
}) => {
  const { activeCompanyFilter, can } = useAuth();
  const terminals = storageService.getTerminals();
  const companies = storageService.getCompanies();
  const merchants = storageService.getMerchants();
  const locations = storageService.getLocations();

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCompany, setSelectedCompany] = useState<string>(activeCompanyFilter !== 'all' ? activeCompanyFilter : '');
  const [selectedMerchant, setSelectedMerchant] = useState<string>('');
  const [selectedProvider, setSelectedProvider] = useState<string>('');
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [selectedLocation, setSelectedLocation] = useState<string>('');
  const [sortField, setSortField] = useState<keyof Terminal>('terminal_name');
  const [sortAsc, setSortAsc] = useState(true);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;

  // Filtered dataset
  const filteredTerminals = useMemo(() => {
    return terminals.filter(t => {
      // Global company scope or local filter
      if (activeCompanyFilter !== 'all' && t.company_id !== activeCompanyFilter) return false;
      if (selectedCompany && t.company_id !== selectedCompany) return false;
      if (selectedMerchant && t.merchant_id !== selectedMerchant) return false;
      if (selectedProvider && t.provider !== selectedProvider) return false;
      if (selectedStatus && t.status !== selectedStatus) return false;
      if (selectedLocation && t.location_id !== selectedLocation) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesName = t.terminal_name.toLowerCase().includes(q);
        const matchesTid = t.terminal_identifier.toLowerCase().includes(q);
        const matchesSerial = t.serial_number.toLowerCase().includes(q);
        const matchesOwner = t.owner_name.toLowerCase().includes(q);
        if (!matchesName && !matchesTid && !matchesSerial && !matchesOwner) return false;
      }

      return true;
    }).sort((a, b) => {
      let valA = a[sortField] || '';
      let valB = b[sortField] || '';
      if (typeof valA === 'string') valA = valA.toLowerCase();
      if (typeof valB === 'string') valB = valB.toLowerCase();
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [
    terminals,
    activeCompanyFilter,
    selectedCompany,
    selectedMerchant,
    selectedProvider,
    selectedStatus,
    selectedLocation,
    searchQuery,
    sortField,
    sortAsc
  ]);

  // Paginated slice
  const paginatedTerminals = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredTerminals.slice(start, start + pageSize);
  }, [filteredTerminals, currentPage]);

  const totalPages = Math.ceil(filteredTerminals.length / pageSize) || 1;

  const handleExportCsv = () => {
    const exportRows = filteredTerminals.map(t => ({
      terminal_name: t.terminal_name,
      terminal_identifier: t.terminal_identifier,
      serial_number: t.serial_number,
      provider: t.provider,
      model: t.terminal_model,
      company: t.company_name,
      merchant: t.merchant_name || 'N/A',
      location: t.location_name || 'N/A',
      assigned_operator: t.assigned_user_name || 'Unassigned',
      status: t.status,
      installation_date: t.installation_date,
      last_seen: t.last_seen_at
    }));
    exportToCsv('pos_terminals_fleet', exportRows);
  };

  const handleSort = (field: keyof Terminal) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      {/* Header with Title and Primary Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            POS Terminals Fleet
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Track hardware inventory, TID assignments, serial numbers, and device operational statuses
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export CSV</span>
          </button>

          {can('create:terminal') && (
            <>
              <button
                type="button"
                onClick={onOpenImportModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <UploadCloud className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Batch Import</span>
              </button>

              <button
                type="button"
                onClick={onOpenCreateModal}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Register Terminal</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => {
                setSearchQuery(e.target.value);
                setCurrentPage(1);
              }}
              placeholder="Search by terminal name, TID, serial number, or owner..."
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
            />
          </div>

          {/* Quick Filters */}
          <div className="grid grid-cols-2 sm:flex items-center gap-2">
            {/* Status Filter */}
            <select
              value={selectedStatus}
              onChange={e => {
                setSelectedStatus(e.target.value);
                setCurrentPage(1);
              }}
              className="text-xs py-2 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">All Statuses</option>
              <option value="active">Active</option>
              <option value="maintenance">Maintenance</option>
              <option value="inactive">Inactive</option>
              <option value="lost">Lost</option>
              <option value="retired">Retired</option>
            </select>

            {/* Provider Filter */}
            <select
              value={selectedProvider}
              onChange={e => {
                setSelectedProvider(e.target.value);
                setCurrentPage(1);
              }}
              className="text-xs py-2 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
            >
              <option value="">All Providers</option>
              {TERMINAL_PROVIDERS.map(p => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>

            {/* Company Filter (if in global scope) */}
            {activeCompanyFilter === 'all' && (
              <select
                value={selectedCompany}
                onChange={e => {
                  setSelectedCompany(e.target.value);
                  setCurrentPage(1);
                }}
                className="text-xs py-2 px-2.5 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg truncate max-w-[140px]"
              >
                <option value="">All Companies</option>
                {companies.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            )}

            {(searchQuery || selectedStatus || selectedProvider || selectedCompany) && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setSelectedStatus('');
                  setSelectedProvider('');
                  setSelectedCompany('');
                  setSelectedMerchant('');
                  setCurrentPage(1);
                }}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline px-2"
              >
                Reset
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Main Content: Desktop Table & Mobile Card View */}
      {filteredTerminals.length === 0 ? (
        <EmptyState
          icon={CreditCard}
          title="No Terminals Found"
          description="No POS hardware matched your filter criteria or search query. Try resetting filters or register a new terminal."
          actionLabel={can('create:terminal') ? '+ Register First Terminal' : undefined}
          onAction={onOpenCreateModal}
        />
      ) : (
        <>
          {/* Desktop Table View (Hidden on mobile) */}
          <div className="hidden lg:block bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl overflow-hidden shadow-2xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-800/40 text-slate-500 uppercase tracking-wider text-[10px]">
                    <th
                      onClick={() => handleSort('terminal_name')}
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-800 dark:hover:text-slate-200"
                    >
                      Terminal Name & TID {sortField === 'terminal_name' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="py-3 px-4 font-semibold">Company & Merchant</th>
                    <th className="py-3 px-4 font-semibold">Provider / Model</th>
                    <th className="py-3 px-4 font-semibold">Serial Number</th>
                    <th className="py-3 px-4 font-semibold">Assigned Operator</th>
                    <th className="py-3 px-4 font-semibold">Location</th>
                    <th
                      onClick={() => handleSort('status')}
                      className="py-3 px-4 font-semibold cursor-pointer hover:text-slate-800 dark:hover:text-slate-200"
                    >
                      Status {sortField === 'status' && (sortAsc ? '↑' : '↓')}
                    </th>
                    <th className="py-3 px-4 font-semibold">Last Heartbeat</th>
                    <th className="py-3 px-4 font-semibold text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {paginatedTerminals.map(terminal => (
                    <tr
                      key={terminal.id}
                      onClick={() => onSelectTerminal(terminal.id)}
                      className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors"
                    >
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 dark:text-slate-100">
                          {terminal.terminal_name}
                        </div>
                        <div className="font-mono text-[11px] text-indigo-600 dark:text-indigo-400 mt-0.5">
                          {terminal.terminal_identifier}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-slate-800 dark:text-slate-200 font-medium">
                          {terminal.company_name}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate max-w-[180px]">
                          {terminal.merchant_name || 'No Merchant Outlet'}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800 dark:text-slate-200">
                          {terminal.provider}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {terminal.terminal_model}
                        </div>
                      </td>
                      <td className="py-3 px-4 font-mono text-[11px] text-slate-700 dark:text-slate-300">
                        {terminal.serial_number}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800 dark:text-slate-200">
                          {terminal.assigned_user_name || terminal.owner_name}
                        </div>
                        <div className="text-[10px] text-slate-500">
                          {terminal.assigned_user_id ? 'Active Custody' : 'Unassigned'}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                        {terminal.location_name || '—'}
                      </td>
                      <td className="py-3 px-4">
                        <StatusBadge type="terminal" status={terminal.status} />
                      </td>
                      <td className="py-3 px-4 text-slate-500 text-[11px] tabular-nums">
                        {formatRelativeTime(terminal.last_seen_at)}
                      </td>
                      <td className="py-3 px-4 text-right">
                        <div className="flex items-center justify-end gap-1.5" onClick={e => e.stopPropagation()}>
                          {can('assign:terminal') && (
                            <button
                              type="button"
                              onClick={() => onOpenAssignModal(terminal)}
                              className="p-1.5 text-slate-500 hover:text-indigo-600 dark:hover:text-indigo-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                              title="Assign / Reassign Operator"
                            >
                              <UserCheck className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => onSelectTerminal(terminal.id)}
                            className="p-1.5 text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded"
                            title="View Details"
                          >
                            <ChevronRight className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Mobile Ergonomic Card Layout (Shown on small screens) */}
          <div className="lg:hidden space-y-3">
            {paginatedTerminals.map(terminal => (
              <div
                key={terminal.id}
                onClick={() => onSelectTerminal(terminal.id)}
                className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-3 cursor-pointer shadow-2xs hover:border-slate-300"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {terminal.terminal_name}
                    </h3>
                    <p className="font-mono text-xs text-indigo-600 dark:text-indigo-400 mt-0.5">
                      {terminal.terminal_identifier} · {terminal.provider}
                    </p>
                  </div>
                  <StatusBadge type="terminal" status={terminal.status} />
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs pt-1 border-t border-slate-100 dark:border-slate-800/80">
                  <div>
                    <span className="text-slate-600 dark:text-slate-400 text-[10px] block">Company</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate block">
                      {terminal.company_name}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-600 dark:text-slate-400 text-[10px] block">Merchant Outlet</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate block">
                      {terminal.merchant_name || 'N/A'}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-600 dark:text-slate-400 text-[10px] block">Assigned Custodian</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate block">
                      {terminal.assigned_user_name || terminal.owner_name}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-600 dark:text-slate-400 text-[10px] block">Branch Location</span>
                    <span className="font-medium text-slate-800 dark:text-slate-200 truncate block">
                      {terminal.location_name || 'N/A'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500">
                  <span>Serial: <span className="font-mono">{terminal.serial_number}</span></span>
                  <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                    {can('assign:terminal') && (
                      <button
                        type="button"
                        onClick={() => onOpenAssignModal(terminal)}
                        className="px-2.5 py-1 text-xs font-medium text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 rounded-md"
                      >
                        Assign
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => onSelectTerminal(terminal.id)}
                      className="px-2.5 py-1 text-xs font-medium text-slate-700 bg-slate-100 dark:bg-slate-800 rounded-md"
                    >
                      View
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between px-2 pt-2 text-xs text-slate-500">
              <span>
                Showing {(currentPage - 1) * pageSize + 1}–{Math.min(currentPage * pageSize, filteredTerminals.length)} of {filteredTerminals.length} terminals
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  className="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-40"
                >
                  Previous
                </button>
                <span className="px-2 font-mono">
                  {currentPage} / {totalPages}
                </span>
                <button
                  type="button"
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  className="px-3 py-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-md disabled:opacity-40"
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
};
