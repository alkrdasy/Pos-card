import React, { useState } from 'react';
import {
  ArrowLeft,
  CreditCard,
  Building2,
  Store,
  MapPin,
  UserCheck,
  Calendar,
  Clock,
  Wrench,
  Receipt,
  Activity,
  History,
  ShieldCheck,
  Edit,
  AlertTriangle
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../common/Toast';
import { formatCurrency, formatDateTime, formatRelativeTime, formatDate } from '../../lib/utils';
import { Terminal, TerminalStatus } from '../../types';

interface TerminalDetailViewProps {
  terminalId: string;
  onBack: () => void;
  onOpenAssignModal: (terminal: Terminal) => void;
  onOpenEditModal: (terminal: Terminal) => void;
  onOpenRecordTx: (terminalId: string) => void;
  onOpenRecordActivity: (terminalId: string) => void;
}

export const TerminalDetailView: React.FC<TerminalDetailViewProps> = ({
  terminalId,
  onBack,
  onOpenAssignModal,
  onOpenEditModal,
  onOpenRecordTx,
  onOpenRecordActivity
}) => {
  const { currentUser, can } = useAuth();
  const { success, error } = useToast();

  const terminal = storageService.getTerminalById(terminalId);
  const [activeTab, setActiveTab] = useState<'overview' | 'activity' | 'transactions' | 'assignments' | 'audit'>('overview');

  if (!terminal) {
    return (
      <div className="p-8 text-center space-y-3">
        <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">Terminal not found</p>
        <button
          onClick={onBack}
          className="px-3 py-1.5 text-xs text-white bg-indigo-600 rounded-md"
        >
          Return to fleet list
        </button>
      </div>
    );
  }

  const activities = storageService.getActivities().filter(a => a.terminal_id === terminal.id);
  const transactions = storageService.getTransactions().filter(t => t.terminal_id === terminal.id);
  const assignments = storageService.getAssignments(terminal.id);
  const auditLogs = storageService.getAuditLogs().filter(
    a => a.entity_id === terminal.id || (a.metadata && a.metadata.terminal_id === terminal.id)
  );

  const handleStatusChange = (newStatus: TerminalStatus) => {
    if (!currentUser) return;
    try {
      storageService.updateTerminalStatus(terminal.id, newStatus, currentUser, 'Updated via terminal overview console');
      success('Status Updated', `Terminal is now marked as ${newStatus.toUpperCase()}.`);
    } catch (err: any) {
      error('Failed to update status', err.message);
    }
  };

  return (
    <div className="space-y-5 pb-12 animate-in fade-in duration-150">
      {/* Back button & Breadcrumb */}
      <div className="flex items-center gap-2 text-xs text-slate-500">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-1 text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-100 transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>Fleet</span>
        </button>
        <span>/</span>
        <span className="text-slate-800 dark:text-slate-200 font-medium truncate max-w-xs">
          {terminal.terminal_name}
        </span>
      </div>

      {/* Main Terminal Header Card */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
                {terminal.terminal_name}
              </h2>
              <StatusBadge type="terminal" status={terminal.status} />
            </div>

            <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-500 pt-1">
              <span>TID: <strong className="font-mono text-indigo-600 dark:text-indigo-400">{terminal.terminal_identifier}</strong></span>
              <span>·</span>
              <span>Serial: <strong className="font-mono text-slate-700 dark:text-slate-300">{terminal.serial_number}</strong></span>
              <span>·</span>
              <span>Provider: <strong className="text-slate-700 dark:text-slate-300">{terminal.provider}</strong></span>
              <span>·</span>
              <span>Model: <span className="text-slate-700 dark:text-slate-300">{terminal.terminal_model}</span></span>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            {can('assign:terminal') && (
              <button
                type="button"
                onClick={() => onOpenAssignModal(terminal)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <UserCheck className="w-3.5 h-3.5 text-indigo-500" />
                <span>Reassign Custody</span>
              </button>
            )}

            {can('record:transaction') && terminal.status !== 'retired' && terminal.status !== 'lost' && (
              <button
                type="button"
                onClick={() => onOpenRecordTx(terminal.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
              >
                <Receipt className="w-3.5 h-3.5" />
                <span>Record TX</span>
              </button>
            )}

            {can('record:activity') && (
              <button
                type="button"
                onClick={() => onOpenRecordActivity(terminal.id)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <Activity className="w-3.5 h-3.5 text-sky-500" />
                <span>Log Activity</span>
              </button>
            )}

            {can('manage:terminals') && (
              <button
                type="button"
                onClick={() => onOpenEditModal(terminal)}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
              >
                <Edit className="w-3.5 h-3.5" />
                <span>Edit Specs</span>
              </button>
            )}
          </div>
        </div>

        {/* Quick Status Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
          <div className="flex items-center gap-4 text-slate-500">
            <span>Custodian: <strong className="text-slate-800 dark:text-slate-200 font-semibold">{terminal.assigned_user_name || terminal.owner_name}</strong></span>
            <span>Branch: <strong className="text-slate-800 dark:text-slate-200">{terminal.location_name || 'Unassigned'}</strong></span>
            <span>Last Seen: <span className="tabular-nums font-mono">{formatRelativeTime(terminal.last_seen_at)}</span></span>
          </div>

          {/* Quick status switcher for Admins */}
          {can('manage:terminals') && (
            <div className="flex items-center gap-1.5 text-xs">
              <span className="text-slate-500">Quick Status:</span>
              {(['active', 'maintenance', 'inactive', 'retired'] as TerminalStatus[]).map(s => (
                <button
                  key={s}
                  type="button"
                  onClick={() => handleStatusChange(s)}
                  className={`px-2 py-0.5 text-[11px] font-semibold uppercase rounded transition-colors ${
                    terminal.status === s
                      ? 'bg-slate-900 text-white dark:bg-slate-100 dark:text-slate-900'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Tabs Bar */}
      <div className="flex items-center gap-1 border-b border-slate-200 dark:border-slate-800 overflow-x-auto">
        <button
          type="button"
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'overview'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
          }`}
        >
          Basic Information
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('activity')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'activity'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
          }`}
        >
          Activity Feed ({activities.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('transactions')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'transactions'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
          }`}
        >
          Authorized Transactions ({transactions.length})
        </button>
        <button
          type="button"
          onClick={() => setActiveTab('assignments')}
          className={`px-4 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
            activeTab === 'assignments'
              ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
              : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
          }`}
        >
          Assignment History ({assignments.length})
        </button>
        {can('view:audit_logs') && (
          <button
            type="button"
            onClick={() => setActiveTab('audit')}
            className={`px-4 py-2 text-xs font-semibold border-b-2 transition-colors whitespace-nowrap ${
              activeTab === 'audit'
                ? 'border-indigo-600 text-indigo-600 dark:text-indigo-400'
                : 'border-transparent text-slate-500 hover:text-slate-900 dark:hover:text-slate-100'
            }`}
          >
            Audit Trail ({auditLogs.length})
          </button>
        )}
      </div>

      {/* Tab 1: Basic Information */}
      {activeTab === 'overview' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Fleet Hierarchy & Custody
            </h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Operating Company</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{terminal.company_name}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Merchant Outlet</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{terminal.merchant_name || 'No direct MID linked'}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Branch Location</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{terminal.location_name || 'Unassigned location'}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Responsible Operator</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">{terminal.assigned_user_name || terminal.owner_name}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Current Custody Status</span>
                <span className="font-semibold text-slate-800 dark:text-slate-200">
                  {terminal.assigned_user_id ? 'Active User Assignment' : 'Unassigned Hardware'}
                </span>
              </div>
            </div>
          </div>

          <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
            <h3 className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              Hardware Credentials & Telecom
            </h3>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 text-xs">
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Terminal Identifier (TID)</span>
                <span className="font-mono font-bold text-indigo-600 dark:text-indigo-400">{terminal.terminal_identifier}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Serial Number (S/N)</span>
                <span className="font-mono font-medium text-slate-800 dark:text-slate-200">{terminal.serial_number}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Hardware OEM</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{terminal.provider}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Model Specification</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{terminal.terminal_model}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Installation Date</span>
                <span className="font-medium text-slate-800 dark:text-slate-200">{formatDate(terminal.installation_date)}</span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-slate-500">Last Telemetry Heartbeat</span>
                <span className="font-mono text-slate-500 tabular-nums">{formatDateTime(terminal.last_seen_at)}</span>
              </div>
            </div>
          </div>

          {terminal.notes && (
            <div className="md:col-span-2 p-4 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs">
              <span className="font-semibold text-slate-700 dark:text-slate-300 block mb-1">Operational & Field Notes:</span>
              <p className="text-slate-600 dark:text-slate-400 leading-relaxed">{terminal.notes}</p>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Activity Feed */}
      {activeTab === 'activity' && (
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Terminal Operational Events
            </h3>
            {can('record:activity') && (
              <button
                type="button"
                onClick={() => onOpenRecordActivity(terminal.id)}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                + Log New Event
              </button>
            )}
          </div>

          {activities.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">
              No operational events logged for this terminal yet.
            </p>
          ) : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {activities.map(act => (
                <div key={act.id} className="py-3 flex items-start gap-3">
                  <div className="w-2.5 h-2.5 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                  <div className="flex-1 min-w-0 text-xs">
                    <p className="font-semibold text-slate-900 dark:text-slate-100">
                      {act.description}
                    </p>
                    <div className="flex items-center gap-2 mt-1 text-[11px] text-slate-500">
                      <span>Operator: <strong>{act.user_name}</strong></span>
                      <span>·</span>
                      <span>{formatDateTime(act.created_at)}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Transactions */}
      {activeTab === 'transactions' && (
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Transactions Recorded on This Terminal
            </h3>
            {can('record:transaction') && (
              <button
                type="button"
                onClick={() => onOpenRecordTx(terminal.id)}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                + Record Transaction
              </button>
            )}
          </div>

          {transactions.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">
              No transactions recorded for this terminal.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 text-[10px] uppercase">
                    <th className="py-2.5 px-3 font-semibold">Reference</th>
                    <th className="py-2.5 px-3 font-semibold">Type</th>
                    <th className="py-2.5 px-3 font-semibold text-right">Amount</th>
                    <th className="py-2.5 px-3 font-semibold">Instrument</th>
                    <th className="py-2.5 px-3 font-semibold">Operator</th>
                    <th className="py-2.5 px-3 font-semibold">Status</th>
                    <th className="py-2.5 px-3 font-semibold">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                  {transactions.map(tx => (
                    <tr key={tx.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/60">
                      <td className="py-2.5 px-3 font-mono font-semibold text-indigo-600 dark:text-indigo-400">
                        {tx.external_reference}
                      </td>
                      <td className="py-2.5 px-3 uppercase text-[10px] text-slate-500">
                        {tx.transaction_type}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                        {formatCurrency(tx.amount, tx.currency)}
                      </td>
                      <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                        {tx.masked_reference || 'POS Slip'}
                      </td>
                      <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                        {tx.operator_name}
                      </td>
                      <td className="py-2.5 px-3">
                        <StatusBadge type="transaction" status={tx.status} />
                      </td>
                      <td className="py-2.5 px-3 text-slate-500 tabular-nums">
                        {formatDateTime(tx.transaction_time)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Assignment History */}
      {activeTab === 'assignments' && (
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Custody & Assignment Audit Trail
              </h3>
              <p className="text-xs text-slate-500">
                Historical records are permanent and never overwritten
              </p>
            </div>
            {can('assign:terminal') && (
              <button
                type="button"
                onClick={() => onOpenAssignModal(terminal)}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
              >
                + Transfer Custody
              </button>
            )}
          </div>

          {assignments.length === 0 ? (
            <p className="text-xs text-slate-500 py-6 text-center">
              No historical assignment records found.
            </p>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 text-[10px] uppercase">
                    <th className="py-2.5 px-3 font-semibold">Assigned To</th>
                    <th className="py-2.5 px-3 font-semibold">Assigned By</th>
                    <th className="py-2.5 px-3 font-semibold">Effective Date</th>
                    <th className="py-2.5 px-3 font-semibold">Unassigned Date</th>
                    <th className="py-2.5 px-3 font-semibold">Status</th>
                    <th className="py-2.5 px-3 font-semibold">Custody Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                  {assignments.map(asgn => (
                    <tr key={asgn.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/60">
                      <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-slate-100">
                        {asgn.user_name}
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">
                        {asgn.assigned_by_name}
                      </td>
                      <td className="py-2.5 px-3 tabular-nums font-mono">
                        {formatDateTime(asgn.assigned_at)}
                      </td>
                      <td className="py-2.5 px-3 tabular-nums font-mono text-slate-500">
                        {asgn.unassigned_at ? formatDateTime(asgn.unassigned_at) : 'Active Current'}
                      </td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 text-[10px] font-semibold rounded uppercase ${
                          asgn.status === 'active'
                            ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300'
                            : 'bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-400'
                        }`}>
                          {asgn.status}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400 italic">
                        {asgn.notes || '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Audit Trail */}
      {activeTab === 'audit' && can('view:audit_logs') && (
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Immutable Terminal Audit Records
              </h3>
            </div>
            <span className="text-[11px] text-slate-500">
              Append-only operational compliance log
            </span>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800 font-mono text-[11px]">
            {auditLogs.map(log => (
              <div key={log.id} className="py-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                  <span className="font-semibold text-slate-900 dark:text-slate-100">
                    {log.description}
                  </span>
                  <div className="text-[10px] text-slate-500 flex items-center gap-2 mt-0.5 font-sans">
                    <span>Actor: {log.user_name} ({log.user_role})</span>
                    <span>·</span>
                    <span>IP: {log.ip_address || '197.38.102.14'}</span>
                  </div>
                </div>
                <span className="text-[10px] text-slate-400 tabular-nums shrink-0">
                  {formatDateTime(log.created_at)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
