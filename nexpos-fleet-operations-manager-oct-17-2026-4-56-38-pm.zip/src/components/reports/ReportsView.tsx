import React, { useState, useMemo } from 'react';
import {
  FileBarChart,
  Download,
  Printer,
  Calendar,
  Building2,
  CreditCard,
  Receipt,
  Users,
  Store,
  ArrowUpRight
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, formatDate, formatDateTime, exportToCsv } from '../../lib/utils';

export const ReportsView: React.FC = () => {
  const { activeCompanyFilter } = useAuth();
  const [reportType, setReportType] = useState<
    'terminals' | 'transactions' | 'companies' | 'operators' | 'activity' | 'audit'
  >('terminals');
  const [dateRange, setDateRange] = useState<'today' | '7days' | '30days' | 'all'>('30days');

  const terminals = storageService.getTerminals();
  const transactions = storageService.getTransactions();
  const companies = storageService.getCompanies();
  const merchants = storageService.getMerchants();
  const users = storageService.getUsers();
  const activities = storageService.getActivities();
  const auditLogs = storageService.getAuditLogs();

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = () => {
    if (reportType === 'terminals') {
      const rows = terminals.map(t => ({
        terminal_name: t.terminal_name,
        tid: t.terminal_identifier,
        serial_number: t.serial_number,
        provider: t.provider,
        model: t.terminal_model,
        company: t.company_name,
        merchant: t.merchant_name || 'N/A',
        operator: t.assigned_user_name || 'Unassigned',
        status: t.status,
        installation_date: t.installation_date,
        last_seen: t.last_seen_at
      }));
      exportToCsv('fleet_terminal_inventory_report', rows);
    } else if (reportType === 'transactions') {
      const rows = transactions.map(tx => ({
        slip_reference: tx.external_reference,
        company: tx.company_name,
        merchant: tx.merchant_name,
        terminal: tx.terminal_name,
        operator: tx.operator_name,
        type: tx.transaction_type,
        amount: tx.amount,
        currency: tx.currency,
        status: tx.status,
        timestamp: tx.transaction_time
      }));
      exportToCsv('transaction_reconciliation_report', rows);
    } else if (reportType === 'companies') {
      const rows = companies.map(c => {
        const compTxs = transactions.filter(t => t.company_id === c.id);
        const volume = compTxs.reduce((sum, t) => sum + (t.status === 'completed' ? t.amount : 0), 0);
        return {
          company_name: c.name,
          registration_number: c.registration_number,
          status: c.status,
          total_terminals: terminals.filter(t => t.company_id === c.id).length,
          total_transactions: compTxs.length,
          gross_volume_egp: volume
        };
      });
      exportToCsv('company_fleet_performance_report', rows);
    } else if (reportType === 'operators') {
      const rows = users.map(u => ({
        operator_name: u.full_name,
        email: u.email,
        role: u.role,
        company: u.company_name || 'Global',
        assigned_terminals_count: terminals.filter(t => t.assigned_user_id === u.id).length,
        recorded_transactions_count: transactions.filter(t => t.operator_id === u.id).length
      }));
      exportToCsv('operator_custody_report', rows);
    }
  };

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Compliance & Operational Reports
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Audit-ready fleet summaries, reconciliation ledgers, and operator custody exports
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-50 transition-colors shadow-2xs"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print View</span>
          </button>

          <button
            type="button"
            onClick={handleExportCsv}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export CSV Report</span>
          </button>
        </div>
      </div>

      {/* Report Selection Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg overflow-x-auto">
        <button
          type="button"
          onClick={() => setReportType('terminals')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            reportType === 'terminals'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Terminal Fleet Inventory
        </button>
        <button
          type="button"
          onClick={() => setReportType('transactions')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            reportType === 'transactions'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Transaction Reconciliation
        </button>
        <button
          type="button"
          onClick={() => setReportType('companies')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            reportType === 'companies'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Company Volumes
        </button>
        <button
          type="button"
          onClick={() => setReportType('operators')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md whitespace-nowrap transition-colors ${
            reportType === 'operators'
              ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
              : 'text-slate-600 dark:text-slate-400'
          }`}
        >
          Operator Custody
        </button>
      </div>

      {/* Report Content Table */}
      <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4 shadow-2xs">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 uppercase tracking-wider text-xs">
              {reportType === 'terminals' && 'Hardware Fleet Status & Serial Master List'}
              {reportType === 'transactions' && 'Reconciled POS Transaction Ledger'}
              {reportType === 'companies' && 'Company Portfolio Fleet & Volume Breakdown'}
              {reportType === 'operators' && 'Authorized Operator Custody & Terminal Allocations'}
            </h3>
            <p className="text-[11px] text-slate-500">
              Generated: {new Date().toLocaleDateString()} · PCI-DSS compliant operational summary
            </p>
          </div>
        </div>

        {/* Dynamic Report Table */}
        <div className="overflow-x-auto">
          {reportType === 'terminals' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-500 uppercase text-[10px]">
                  <th className="py-2.5 px-3 font-semibold">TID</th>
                  <th className="py-2.5 px-3 font-semibold">Terminal</th>
                  <th className="py-2.5 px-3 font-semibold">Hardware S/N</th>
                  <th className="py-2.5 px-3 font-semibold">Company</th>
                  <th className="py-2.5 px-3 font-semibold">Custodian</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                  <th className="py-2.5 px-3 font-semibold">Installation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {terminals.map(t => (
                  <tr key={t.id}>
                    <td className="py-2.5 px-3 font-mono font-bold text-indigo-600">{t.terminal_identifier}</td>
                    <td className="py-2.5 px-3">{t.terminal_name}</td>
                    <td className="py-2.5 px-3 font-mono text-[11px] text-slate-600">{t.serial_number}</td>
                    <td className="py-2.5 px-3">{t.company_name}</td>
                    <td className="py-2.5 px-3">{t.assigned_user_name || t.owner_name}</td>
                    <td className="py-2.5 px-3 uppercase text-[10px] font-bold">{t.status}</td>
                    <td className="py-2.5 px-3 tabular-nums text-slate-500">{formatDate(t.installation_date)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'transactions' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-500 uppercase text-[10px]">
                  <th className="py-2.5 px-3 font-semibold">Reference</th>
                  <th className="py-2.5 px-3 font-semibold">Terminal</th>
                  <th className="py-2.5 px-3 font-semibold">Merchant</th>
                  <th className="py-2.5 px-3 font-semibold">Type</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Amount</th>
                  <th className="py-2.5 px-3 font-semibold">Operator</th>
                  <th className="py-2.5 px-3 font-semibold">Status</th>
                  <th className="py-2.5 px-3 font-semibold">Timestamp</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {transactions.map(tx => (
                  <tr key={tx.id}>
                    <td className="py-2.5 px-3 font-mono font-bold text-indigo-600">{tx.external_reference}</td>
                    <td className="py-2.5 px-3">{tx.terminal_name}</td>
                    <td className="py-2.5 px-3">{tx.merchant_name}</td>
                    <td className="py-2.5 px-3 uppercase text-[10px] text-slate-500">{tx.transaction_type}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                      {formatCurrency(tx.amount, tx.currency)}
                    </td>
                    <td className="py-2.5 px-3">{tx.operator_name}</td>
                    <td className="py-2.5 px-3 uppercase text-[10px] font-semibold">{tx.status}</td>
                    <td className="py-2.5 px-3 text-slate-500 tabular-nums">{formatDateTime(tx.transaction_time)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}

          {reportType === 'companies' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-500 uppercase text-[10px]">
                  <th className="py-2.5 px-3 font-semibold">Company</th>
                  <th className="py-2.5 px-3 font-semibold">CR Registration</th>
                  <th className="py-2.5 px-3 font-semibold text-center">POS Fleet</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Total Tx</th>
                  <th className="py-2.5 px-3 font-semibold text-right">Settled Volume</th>
                  <th className="py-2.5 px-3 font-semibold">Compliance Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {companies.map(c => {
                  const compTxs = transactions.filter(t => t.company_id === c.id);
                  const volume = compTxs.reduce((sum, t) => sum + (t.status === 'completed' ? t.amount : 0), 0);
                  const compTerms = terminals.filter(t => t.company_id === c.id);

                  return (
                    <tr key={c.id}>
                      <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-slate-100">{c.name}</td>
                      <td className="py-2.5 px-3 font-mono">{c.registration_number}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-indigo-600">{compTerms.length}</td>
                      <td className="py-2.5 px-3 text-center font-bold">{compTxs.length}</td>
                      <td className="py-2.5 px-3 text-right font-mono font-bold tabular-nums">
                        {formatCurrency(volume, 'EGP')}
                      </td>
                      <td className="py-2.5 px-3 uppercase text-[10px] font-semibold">{c.status}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}

          {reportType === 'operators' && (
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 text-slate-500 uppercase text-[10px]">
                  <th className="py-2.5 px-3 font-semibold">Operator Name</th>
                  <th className="py-2.5 px-3 font-semibold">Email</th>
                  <th className="py-2.5 px-3 font-semibold">Role</th>
                  <th className="py-2.5 px-3 font-semibold">Assigned Company</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Assigned POS Units</th>
                  <th className="py-2.5 px-3 font-semibold text-center">Recorded Receipts</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
                {users.map(u => {
                  const opTerms = terminals.filter(t => t.assigned_user_id === u.id);
                  const opTxs = transactions.filter(t => t.operator_id === u.id);

                  return (
                    <tr key={u.id}>
                      <td className="py-2.5 px-3 font-bold text-slate-900 dark:text-slate-100">{u.full_name}</td>
                      <td className="py-2.5 px-3 text-slate-600">{u.email}</td>
                      <td className="py-2.5 px-3 uppercase text-[10px]">{u.role.replace('_', ' ')}</td>
                      <td className="py-2.5 px-3">{u.company_name || 'Global Access'}</td>
                      <td className="py-2.5 px-3 text-center font-bold text-indigo-600">{opTerms.length}</td>
                      <td className="py-2.5 px-3 text-center font-bold">{opTxs.length}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
};
