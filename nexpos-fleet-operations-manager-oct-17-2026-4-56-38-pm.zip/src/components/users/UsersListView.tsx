import React, { useState } from 'react';
import {
  Users,
  Plus,
  Search,
  Shield,
  CreditCard,
  Mail,
  Phone,
  UserCheck,
  Edit
} from 'lucide-react';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { UserProfile } from '../../types';

interface UsersListViewProps {
  onOpenCreateModal: () => void;
  onOpenEditModal: (user: UserProfile) => void;
  onSelectTerminal?: (terminalId: string) => void;
}

export const UsersListView: React.FC<UsersListViewProps> = ({
  onOpenCreateModal,
  onOpenEditModal,
  onSelectTerminal
}) => {
  const { allUsers, currentUser, switchPersona, can } = useAuth();
  const terminals = storageService.getTerminals();
  const [searchQuery, setSearchQuery] = useState('');

  const filtered = allUsers.filter(u => {
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        u.full_name.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.role.toLowerCase().includes(q)
      );
    }
    return true;
  });

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Operators & System Users
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Role-based access permissions, terminal custodial assignments, and security profiles
          </p>
        </div>

        {can('manage:users') && (
          <button
            type="button"
            onClick={onOpenCreateModal}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Create Operator Profile</span>
          </button>
        )}
      </div>

      {/* Search */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl">
        <div className="relative">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search team members by name, email, or role..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>
      </div>

      {/* Users Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(user => {
          const assignedTerminals = terminals.filter(t => t.assigned_user_id === user.id);
          const isCurrentActive = currentUser?.id === user.id;

          return (
            <div
              key={user.id}
              className={`p-5 bg-white dark:bg-slate-900 border rounded-xl space-y-4 transition-all shadow-2xs ${
                isCurrentActive
                  ? 'border-indigo-400 dark:border-indigo-600 ring-2 ring-indigo-500/10'
                  : 'border-slate-200 dark:border-slate-800'
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-indigo-100 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 flex items-center justify-center font-bold text-sm uppercase">
                    {user.full_name.slice(0, 2)}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100">
                      {user.full_name}
                    </h3>
                    <p className="text-xs text-slate-500">{user.email}</p>
                  </div>
                </div>

                {can('manage:users') && (
                  <button
                    type="button"
                    onClick={() => onOpenEditModal(user)}
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    title="Edit User Profile"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                )}
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <StatusBadge type="role" status={user.role} />
                <span className="text-[11px] text-slate-500">
                  {user.company_name || 'Global Access'}
                </span>
              </div>

              {/* Custody summary */}
              <div className="p-2.5 bg-slate-50 dark:bg-slate-800/60 rounded-lg text-xs space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned Hardware</span>
                  <span className="font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums">
                    {assignedTerminals.length} POS Units
                  </span>
                </div>
                {assignedTerminals.length > 0 && (
                  <div className="flex flex-wrap gap-1 pt-1">
                    {assignedTerminals.map(t => (
                      <span
                        key={t.id}
                        onClick={() => onSelectTerminal?.(t.id)}
                        className="px-1.5 py-0.5 text-[10px] font-mono bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 rounded cursor-pointer hover:border-indigo-400"
                      >
                        {t.terminal_identifier}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Action */}
              <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                <span className="text-[11px] text-slate-500">
                  {user.phone || 'No phone'}
                </span>
                <button
                  type="button"
                  onClick={() => switchPersona(user.id)}
                  className={`px-3 py-1 text-xs font-medium rounded-lg transition-colors ${
                    isCurrentActive
                      ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300'
                      : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200 hover:bg-slate-200'
                  }`}
                >
                  {isCurrentActive ? 'Active Persona' : 'Switch To This User'}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
