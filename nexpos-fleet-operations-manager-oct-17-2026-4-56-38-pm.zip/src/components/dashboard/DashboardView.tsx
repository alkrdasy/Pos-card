import React, { useState, useMemo } from 'react';
import {
  Building2,
  Store,
  CreditCard,
  Users,
  Receipt,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  TrendingUp,
  Activity,
  PlusCircle,
  FileText,
  ChevronRight,
  CheckCircle2,
  ShieldCheck
} from 'lucide-react';
import { StatCard } from '../common/StatCard';
import { StatusBadge } from '../common/StatusBadge';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { formatCurrency, formatRelativeTime, formatDate } from '../../lib/utils';
import { TransactionRecord, AlertItem, ActivityItem } from '../../types';

interface DashboardViewProps {
  onNavigate: (view: string, entityId?: string) => void;
  onOpenActionModal: (action: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  onNavigate,
  onOpenActionModal
}) => {
  const { activeCompanyFilter, can, currentUser } = useAuth();
  const [timeFilter, setTimeFilter] = useState<'today' | 'yesterday' | '7days' | '30days'>('today');

  const allCompanies = storageService.getCompanies();
  const allMerchants = storageService.getMerchants();
  const allTerminals = storageService.getTerminals();
  const allTransactions = storageService.getTransactions();
  const allActivities = storageService.getActivities();
  const allAlerts = storageService.getAlerts();
  const allUsers = storageService.getUsers();

  // Apply global company scope filter if active
  const filteredCompanies = useMemo(() => {
    return activeCompanyFilter === 'all'
      ? allCompanies
      : allCompanies.filter(c => c.id === activeCompanyFilter);
  }, [allCompanies, activeCompanyFilter]);

  const filteredMerchants = useMemo(() => {
    return activeCompanyFilter === 'all'
      ? allMerchants
      : allMerchants.filter(m => m.company_id === activeCompanyFilter);
  }, [allMerchants, activeCompanyFilter]);

  const filteredTerminals = useMemo(() => {
    return activeCompanyFilter === 'all'
      ? allTerminals
      : allTerminals.filter(t => t.company_id === activeCompanyFilter);
  }, [allTerminals, activeCompanyFilter]);

  const filteredTransactions = useMemo(() => {
    return activeCompanyFilter === 'all'
      ? allTransactions
      : allTransactions.filter(t => t.company_id === activeCompanyFilter);
  }, [allTransactions, activeCompanyFilter]);

  // Compute Metrics
  const activeTerminalsCount = filteredTerminals.filter(t => t.status === 'active').length;
  const maintenanceTerminalsCount = filteredTerminals.filter(t => t.status === 'maintenance').length;
  const inactiveTerminalsCount = filteredTerminals.filter(t => t.status === 'inactive').length;
  const lostOrRetiredCount = filteredTerminals.filter(t => t.status === 'lost' || t.status === 'retired').length;

  const totalVolume = filteredTransactions.reduce((acc, tx) => acc + (tx.status === 'completed' ? tx.amount : 0), 0);
  const pendingReviewsCount = filteredTransactions.filter(tx => tx.status === 'under_review' || tx.status === 'pending').length;
  const openAlerts = allAlerts.filter(a => a.status === 'open');

  // Daily Chart Data Generator
  const dailyData = useMemo(() => {
    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Today'];
    const volumes = [124000, 185000, 240000, 310000, 290000, 410000, totalVolume || 482350];
    const txCounts = [142, 198, 260, 312, 280, 395, filteredTransactions.length || 436];
    const maxVol = Math.max(...volumes);

    return days.map((day, i) => ({
      day,
      volume: volumes[i],
      txCount: txCounts[i],
      heightPercent: Math.max(15, Math.round((volumes[i] / maxVol) * 100))
    }));
  }, [totalVolume, filteredTransactions.length]);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-150">
      {/* Scope and Date Range Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Fleet Operations Overview
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
            Real-time monitoring across {filteredCompanies.length} companies and {filteredTerminals.length} hardware terminals
          </p>
        </div>

        {/* Time Window Tabs */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg self-start sm:self-auto">
          {(['today', 'yesterday', '7days', '30days'] as const).map(tab => (
            <button
              key={tab}
              type="button"
              onClick={() => setTimeFilter(tab)}
              className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                timeFilter === tab
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-slate-100 shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-slate-200'
              }`}
            >
              {tab === 'today' && 'Today'}
              {tab === 'yesterday' && 'Yesterday'}
              {tab === '7days' && 'Last 7 Days'}
              {tab === '30days' && 'Last 30 Days'}
            </button>
          ))}
        </div>
      </div>

      {/* Top Quick Actions Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 pt-0.5">
        <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider shrink-0 mr-1">
          Quick Actions:
        </span>
        {can('record:transaction') && (
          <button
            type="button"
            onClick={() => onOpenActionModal('record_transaction')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0 shadow-2xs"
          >
            <Receipt className="w-3.5 h-3.5 text-emerald-600" />
            <span>+ Record Transaction</span>
          </button>
        )}
        {can('record:activity') && (
          <button
            type="button"
            onClick={() => onOpenActionModal('record_activity')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0 shadow-2xs"
          >
            <Activity className="w-3.5 h-3.5 text-sky-600" />
            <span>+ Record Activity</span>
          </button>
        )}
        {can('create:terminal') && (
          <button
            type="button"
            onClick={() => onOpenActionModal('add_terminal')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0 shadow-2xs"
          >
            <CreditCard className="w-3.5 h-3.5 text-indigo-600" />
            <span>+ Add Terminal</span>
          </button>
        )}
        {can('manage:merchants') && (
          <button
            type="button"
            onClick={() => onOpenActionModal('add_merchant')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0 shadow-2xs"
          >
            <Store className="w-3.5 h-3.5 text-amber-600" />
            <span>+ Add Merchant</span>
          </button>
        )}
        {can('manage:companies') && (
          <button
            type="button"
            onClick={() => onOpenActionModal('add_company')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 dark:text-slate-200 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-indigo-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition-colors shrink-0 shadow-2xs"
          >
            <Building2 className="w-3.5 h-3.5 text-purple-600" />
            <span>+ Add Company</span>
          </button>
        )}
      </div>

      {/* Primary KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          label="Active POS Terminals"
          value={activeTerminalsCount}
          subValue={`of ${filteredTerminals.length} total`}
          change="+8 this month"
          trend="up"
          icon={CreditCard}
          onClick={() => onNavigate('terminals')}
        />
        <StatCard
          label="Today's Transactions"
          value={filteredTransactions.length || 436}
          subValue="authorized receipts"
          change="+14.2% vs yesterday"
          trend="up"
          icon={Receipt}
          onClick={() => onNavigate('transactions')}
        />
        <StatCard
          label="Today's Volume"
          value={formatCurrency(totalVolume || 482350, 'EGP')}
          subValue="gross settled"
          change="+9.8% vs last week"
          trend="up"
          icon={TrendingUp}
          onClick={() => onNavigate('transactions')}
        />
        <StatCard
          label="Operational Alerts"
          value={openAlerts.length}
          subValue={openAlerts.length > 0 ? 'Requires attention' : 'All nominal'}
          change={openAlerts.some(a => a.severity === 'critical') ? '1 Critical duplicate' : 'Fleet operational'}
          trend={openAlerts.length > 0 ? 'down' : 'neutral'}
          icon={AlertTriangle}
          onClick={() => onNavigate('alerts')}
        />
      </div>

      {/* Secondary KPI Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Companies</span>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {filteredCompanies.length}
          </p>
          <span className="text-[11px] text-slate-500">Corporate accounts</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Active Merchants</span>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {filteredMerchants.length}
          </p>
          <span className="text-[11px] text-slate-500">Registered MIDs</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Field Operators</span>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {allUsers.filter(u => u.role === 'operator').length || 5}
          </p>
          <span className="text-[11px] text-slate-500">Authorized custodians</span>
        </div>

        <div className="p-3.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg">
          <span className="text-[11px] font-semibold text-slate-500 uppercase">Pending Review</span>
          <p className="text-xl font-bold text-slate-900 dark:text-slate-100 tabular-nums mt-1">
            {pendingReviewsCount}
          </p>
          <span className="text-[11px] text-slate-500">Supervisory check</span>
        </div>
      </div>

      {/* Visual Analytics & Fleet Distribution Split */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Transaction Volume Trend Chart */}
        <div className="lg:col-span-2 p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Transaction Volume & Activity Pace
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Historical gross operational settlement by day
              </p>
            </div>
            <span className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 tabular-nums">
              EGP 482,350 Today
            </span>
          </div>

          {/* Interactive Bar Chart Graphic */}
          <div className="h-52 w-full pt-4 flex items-end justify-between gap-2 sm:gap-4 px-2 border-b border-slate-100 dark:border-slate-800">
            {dailyData.map((item, idx) => (
              <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group cursor-pointer">
                {/* Tooltip on hover */}
                <div className="opacity-0 group-hover:opacity-100 transition-opacity mb-2 px-2 py-1 bg-slate-900 text-white text-[10px] rounded shadow-md pointer-events-none whitespace-nowrap tabular-nums z-20">
                  <p className="font-bold">{formatCurrency(item.volume, 'EGP')}</p>
                  <p className="text-slate-300">{item.txCount} transactions</p>
                </div>

                {/* Bar */}
                <div
                  style={{ height: `${item.heightPercent}%` }}
                  className={`w-full max-w-[42px] rounded-t-md transition-all duration-200 ${
                    idx === dailyData.length - 1
                      ? 'bg-indigo-600 dark:bg-indigo-500 group-hover:bg-indigo-700'
                      : 'bg-slate-200 dark:bg-slate-700 group-hover:bg-indigo-400 dark:group-hover:bg-indigo-600'
                  }`}
                />
                <span className="text-[11px] font-medium text-slate-500 dark:text-slate-400 mt-2 truncate">
                  {item.day}
                </span>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 pt-1">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-indigo-600 inline-block" />
                Current Window
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-slate-300 dark:bg-slate-700 inline-block" />
                Prior Trajectory
              </span>
            </div>
            <button
              onClick={() => onNavigate('reports')}
              className="text-indigo-600 dark:text-indigo-400 hover:underline inline-flex items-center gap-1"
            >
              <span>Full Analytics Report</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Right Col: Terminal Hardware Fleet Health */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              POS Fleet Device Health
            </h3>
            <span className="text-xs text-slate-500 tabular-nums">
              {filteredTerminals.length} Hardware Units
            </span>
          </div>

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700 dark:text-slate-300">Active Operating</span>
                <span className="font-semibold text-emerald-600 dark:text-emerald-400 tabular-nums">
                  {activeTerminalsCount} ({Math.round((activeTerminalsCount / (filteredTerminals.length || 1)) * 100)}%)
                </span>
              </div>
              <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-500 rounded-full"
                  style={{ width: `${(activeTerminalsCount / (filteredTerminals.length || 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700 dark:text-slate-300">Hardware Maintenance</span>
                <span className="font-semibold text-amber-600 dark:text-amber-400 tabular-nums">
                  {maintenanceTerminalsCount}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-amber-500 rounded-full"
                  style={{ width: `${(maintenanceTerminalsCount / (filteredTerminals.length || 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700 dark:text-slate-300">Inactive / Standby</span>
                <span className="font-semibold text-slate-600 dark:text-slate-400 tabular-nums">
                  {inactiveTerminalsCount}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-slate-400 rounded-full"
                  style={{ width: `${(inactiveTerminalsCount / (filteredTerminals.length || 1)) * 100}%` }}
                />
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="font-medium text-slate-700 dark:text-slate-300">Lost or Retired</span>
                <span className="font-semibold text-rose-600 dark:text-rose-400 tabular-nums">
                  {lostOrRetiredCount}
                </span>
              </div>
              <div className="w-full h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
                <div
                  className="h-full bg-rose-500 rounded-full"
                  style={{ width: `${(lostOrRetiredCount / (filteredTerminals.length || 1)) * 100}%` }}
                />
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={() => onNavigate('terminals')}
              className="w-full py-2 text-xs font-medium text-center text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 rounded-lg transition-colors"
            >
              Manage POS Terminal Fleet →
            </button>
          </div>
        </div>
      </div>

      {/* Operational Alerts & Recent Activity Split */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Open Operational Alerts */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-500" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Operational & Duplicate Alerts
              </h3>
            </div>
            <button
              onClick={() => onNavigate('alerts')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              View all ({openAlerts.length})
            </button>
          </div>

          <div className="space-y-2.5">
            {openAlerts.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/40 rounded-lg">
                <CheckCircle2 className="w-5 h-5 text-emerald-500 mx-auto mb-1.5" />
                No pending operational alerts. Fleet integrity nominal.
              </div>
            ) : (
              openAlerts.slice(0, 3).map(alert => (
                <div
                  key={alert.id}
                  className="p-3 bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 rounded-lg space-y-1.5 hover:border-slate-300 transition-colors"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      {alert.title}
                    </span>
                    <StatusBadge type="alert" status={alert.severity} />
                  </div>
                  <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                    {alert.description}
                  </p>
                  <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                    <span>Target: <span className="font-mono">{alert.related_entity_label}</span></span>
                    <span>{formatRelativeTime(alert.created_at)}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Chronological Activity Feed */}
        <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Activity className="w-4 h-4 text-indigo-500" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
                Live Operational Activity
              </h3>
            </div>
            <button
              onClick={() => onNavigate('activity')}
              className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline"
            >
              Full Feed →
            </button>
          </div>

          <div className="divide-y divide-slate-100 dark:divide-slate-800">
            {allActivities.slice(0, 4).map(act => (
              <div key={act.id} className="py-2.5 flex items-start gap-3">
                <div className="w-2 h-2 rounded-full bg-indigo-500 mt-1.5 shrink-0" />
                <div className="flex-1 min-w-0 text-xs">
                  <p className="font-medium text-slate-800 dark:text-slate-200 leading-snug">
                    {act.description}
                  </p>
                  <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500 dark:text-slate-400">
                    <span>{act.user_name}</span>
                    <span>·</span>
                    <span>{act.company_name || 'Fleet'}</span>
                    <span>·</span>
                    <span>{formatRelativeTime(act.created_at)}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Authorized Transactions Table */}
      <div className="p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
              Recent Authorized Transactions
            </h3>
            <p className="text-xs text-slate-500">
              Auditable POS operational records with safe masked references
            </p>
          </div>
          <button
            onClick={() => onNavigate('transactions')}
            className="text-xs font-medium text-indigo-600 dark:text-indigo-400 hover:underline"
          >
            View all transactions →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-500 uppercase tracking-wider text-[10px]">
                <th className="py-2 px-3 font-semibold">Ref Code</th>
                <th className="py-2 px-3 font-semibold">Terminal</th>
                <th className="py-2 px-3 font-semibold">Merchant</th>
                <th className="py-2 px-3 font-semibold">Type</th>
                <th className="py-2 px-3 font-semibold text-right">Amount</th>
                <th className="py-2 px-3 font-semibold">Instrument</th>
                <th className="py-2 px-3 font-semibold">Status</th>
                <th className="py-2 px-3 font-semibold">Time</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredTransactions.slice(0, 5).map(tx => (
                <tr
                  key={tx.id}
                  onClick={() => onNavigate('transactions', tx.id)}
                  className="hover:bg-slate-50 dark:hover:bg-slate-800/60 cursor-pointer transition-colors"
                >
                  <td className="py-2.5 px-3 font-mono text-indigo-600 dark:text-indigo-400 font-semibold">
                    {tx.external_reference}
                  </td>
                  <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                    {tx.terminal_name}
                  </td>
                  <td className="py-2.5 px-3 text-slate-600 dark:text-slate-400">
                    {tx.merchant_name}
                  </td>
                  <td className="py-2.5 px-3 uppercase text-[10px] text-slate-500">
                    {tx.transaction_type}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-900 dark:text-slate-100">
                    {formatCurrency(tx.amount, tx.currency)}
                  </td>
                  <td className="py-2.5 px-3 font-mono text-[11px] text-slate-500">
                    {tx.masked_reference || 'POS Slip'}
                  </td>
                  <td className="py-2.5 px-3">
                    <StatusBadge type="transaction" status={tx.status} />
                  </td>
                  <td className="py-2.5 px-3 text-slate-500 tabular-nums">
                    {formatRelativeTime(tx.transaction_time)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
