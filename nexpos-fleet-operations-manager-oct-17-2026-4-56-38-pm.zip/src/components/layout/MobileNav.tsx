import React from 'react';
import { LayoutDashboard, CreditCard, PlusCircle, Activity, AlertTriangle } from 'lucide-react';
import { storageService } from '../../services/storageService';
import { cn } from '../../lib/utils';
import { useAuth } from '../../context/AuthContext';

interface MobileNavProps {
  currentView: string;
  onNavigate: (view: string) => void;
  onOpenRecordTx: () => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({
  currentView,
  onNavigate,
  onOpenRecordTx
}) => {
  const { can } = useAuth();
  const alerts = storageService.getAlerts();
  const openAlertsCount = alerts.filter(a => a.status === 'open').length;

  return (
    <nav className="fixed bottom-0 inset-x-0 z-30 flex items-center justify-around h-16 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-t border-slate-200/80 dark:border-slate-800 lg:hidden px-2">
      <button
        type="button"
        onClick={() => onNavigate('dashboard')}
        className={cn(
          'flex flex-col items-center justify-center flex-1 py-1 text-[11px] font-medium transition-colors',
          currentView === 'dashboard'
            ? 'text-indigo-600 dark:text-indigo-400'
            : 'text-slate-500 dark:text-slate-400'
        )}
      >
        <LayoutDashboard className="w-5 h-5 mb-0.5" />
        <span>Home</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('terminals')}
        className={cn(
          'flex flex-col items-center justify-center flex-1 py-1 text-[11px] font-medium transition-colors',
          currentView === 'terminals'
            ? 'text-indigo-600 dark:text-indigo-400'
            : 'text-slate-500 dark:text-slate-400'
        )}
      >
        <CreditCard className="w-5 h-5 mb-0.5" />
        <span>Fleet</span>
      </button>

      {/* Primary Record Action */}
      {can('record:transaction') && (
        <button
          type="button"
          onClick={onOpenRecordTx}
          className="flex flex-col items-center justify-center -mt-5 mx-1"
          aria-label="Record transaction"
        >
          <div className="flex items-center justify-center w-12 h-12 rounded-full bg-indigo-600 text-white shadow-lg hover:bg-indigo-700 transition-transform active:scale-95">
            <PlusCircle className="w-6 h-6" />
          </div>
          <span className="text-[10px] font-semibold text-indigo-600 dark:text-indigo-400 mt-1">
            Record
          </span>
        </button>
      )}

      <button
        type="button"
        onClick={() => onNavigate('activity')}
        className={cn(
          'flex flex-col items-center justify-center flex-1 py-1 text-[11px] font-medium transition-colors',
          currentView === 'activity'
            ? 'text-indigo-600 dark:text-indigo-400'
            : 'text-slate-500 dark:text-slate-400'
        )}
      >
        <Activity className="w-5 h-5 mb-0.5" />
        <span>Activity</span>
      </button>

      <button
        type="button"
        onClick={() => onNavigate('alerts')}
        className={cn(
          'relative flex flex-col items-center justify-center flex-1 py-1 text-[11px] font-medium transition-colors',
          currentView === 'alerts'
            ? 'text-indigo-600 dark:text-indigo-400'
            : 'text-slate-500 dark:text-slate-400'
        )}
      >
        <AlertTriangle className="w-5 h-5 mb-0.5" />
        <span>Alerts</span>
        {openAlertsCount > 0 && (
          <span className="absolute top-1 right-5 w-2 h-2 rounded-full bg-rose-500" />
        )}
      </button>
    </nav>
  );
};
