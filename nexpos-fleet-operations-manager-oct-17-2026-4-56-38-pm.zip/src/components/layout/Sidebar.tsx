import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Store,
  CreditCard,
  Users,
  MapPin,
  Activity,
  Receipt,
  AlertTriangle,
  FileBarChart,
  ShieldCheck,
  Settings,
  ChevronDown,
  Radio
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { storageService } from '../../services/storageService';
import { cn } from '../../lib/utils';

interface SidebarProps {
  currentView: string;
  onNavigate: (view: string) => void;
  isOpenMobile: boolean;
  onCloseMobile: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  onNavigate,
  isOpenMobile,
  onCloseMobile
}) => {
  const { currentUser, can, activeCompanyFilter, setActiveCompanyFilter } = useAuth();
  const companies = storageService.getCompanies();
  const alerts = storageService.getAlerts();
  const openAlertsCount = alerts.filter(a => a.status === 'open').length;

  const navItems = [
    { id: 'dashboard', name: 'Dashboard', icon: LayoutDashboard },
    { id: 'companies', name: 'Companies', icon: Building2 },
    { id: 'merchants', name: 'Merchants', icon: Store },
    { id: 'terminals', name: 'POS Terminals', icon: CreditCard },
    { id: 'transactions', name: 'Transactions', icon: Receipt },
    { id: 'activity', name: 'Operational Activity', icon: Activity },
    {
      id: 'alerts',
      name: 'Alerts',
      icon: AlertTriangle,
      badge: openAlertsCount > 0 ? openAlertsCount : undefined,
      badgeVariant: 'critical' as const
    },
    { id: 'locations', name: 'Locations', icon: MapPin },
    { id: 'users', name: 'Operators & Users', icon: Users },
    { id: 'reports', name: 'Reports', icon: FileBarChart },
    {
      id: 'audit',
      name: 'Audit Trail',
      icon: ShieldCheck,
      hidden: !can('view:audit_logs')
    },
    {
      id: 'settings',
      name: 'Settings',
      icon: Settings,
      hidden: !can('manage:settings')
    }
  ];

  return (
    <>
      {/* Mobile backdrop */}
      {isOpenMobile && (
        <div
          className="fixed inset-0 z-40 bg-slate-900/60 lg:hidden backdrop-blur-xs"
          onClick={onCloseMobile}
        />
      )}

      <aside
        className={cn(
          'fixed inset-y-0 left-0 z-40 flex flex-col w-64 bg-white dark:bg-slate-900 border-r border-slate-200/80 dark:border-slate-800 transition-transform duration-200 lg:translate-x-0',
          isOpenMobile ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        {/* Brand Header */}
        <div className="flex items-center justify-between h-16 px-5 border-b border-slate-100 dark:border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="flex items-center justify-center w-8 h-8 rounded-lg bg-indigo-600 text-white shadow-xs">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <span className="text-sm font-bold tracking-tight text-slate-900 dark:text-slate-100">
                NexPOS Fleet
              </span>
              <span className="block text-[10px] font-medium text-slate-600 dark:text-slate-400">
                Operations Platform
              </span>
            </div>
          </div>
        </div>

        {/* Global Company Scope Selector */}
        <div className="p-3 border-b border-slate-100 dark:border-slate-800">
          <label className="block text-[10px] font-semibold tracking-wider uppercase text-slate-600 dark:text-slate-400 mb-1">
            Fleet Company Scope
          </label>
          <div className="relative">
            <select
              value={activeCompanyFilter}
              onChange={e => setActiveCompanyFilter(e.target.value)}
              className="w-full text-xs py-1.5 pl-2.5 pr-7 bg-slate-50 dark:bg-slate-800 text-slate-800 dark:text-slate-200 border border-slate-200 dark:border-slate-700 rounded-md focus:outline-hidden focus:ring-1 focus:ring-indigo-500 appearance-none cursor-pointer truncate"
            >
              <option value="all">All Companies ({companies.length})</option>
              {companies.map(c => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-2 top-2.5 w-3.5 h-3.5 text-slate-400 pointer-events-none" />
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
          {navItems.map(item => {
            if (item.hidden) return null;
            const isActive = currentView === item.id;
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  onNavigate(item.id);
                  onCloseMobile();
                }}
                className={cn(
                  'flex items-center justify-between w-full px-3 py-2 text-xs font-medium rounded-lg transition-colors whitespace-nowrap',
                  isActive
                    ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300 font-semibold'
                    : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100'
                )}
              >
                <div className="flex items-center gap-2.5">
                  <Icon className={cn('w-4 h-4', isActive ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400')} />
                  <span>{item.name}</span>
                </div>
                {item.badge !== undefined && (
                  <span
                    className={cn(
                      'px-1.5 py-0.5 text-[10px] font-bold rounded-full tabular-nums',
                      item.badgeVariant === 'critical'
                        ? 'bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300'
                        : 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                    )}
                  >
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* User profile strip */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800">
          <div className="flex items-center gap-3 p-2 rounded-lg bg-slate-50 dark:bg-slate-800/60">
            <div className="w-8 h-8 rounded-full bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 flex items-center justify-center font-bold text-xs uppercase shrink-0">
              {currentUser?.full_name?.slice(0, 2) || 'OP'}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-xs font-semibold text-slate-900 dark:text-slate-100 truncate">
                {currentUser?.full_name || 'Operator'}
              </p>
              <p className="text-[10px] text-slate-600 dark:text-slate-400 capitalize truncate">
                {currentUser?.role?.replace('_', ' ') || 'User'}
              </p>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
};
