import React, { useState } from 'react';
import {
  Menu,
  Search,
  Moon,
  Sun,
  Plus,
  Receipt,
  Activity,
  CreditCard,
  Building2,
  Store,
  ChevronDown,
  UserCheck
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { UserRole } from '../../types';

interface TopbarProps {
  currentView: string;
  onOpenMobileMenu: () => void;
  onOpenCommandPalette: () => void;
  onOpenActionModal: (action: string) => void;
}

export const Topbar: React.FC<TopbarProps> = ({
  currentView,
  onOpenMobileMenu,
  onOpenCommandPalette,
  onOpenActionModal
}) => {
  const { currentUser, allUsers, switchPersona, isDarkMode, toggleDarkMode, can } = useAuth();
  const [showPersonaMenu, setShowPersonaMenu] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(false);

  const viewTitles: Record<string, string> = {
    dashboard: 'Operations Dashboard',
    companies: 'Companies',
    merchants: 'Merchants & Outlets',
    terminals: 'POS Terminals Fleet',
    transactions: 'Transaction Records',
    activity: 'Operational Activity Feed',
    alerts: 'Operational Alerts Center',
    locations: 'Locations & Branches',
    users: 'Operators & User Management',
    reports: 'Compliance & Fleet Reports',
    audit: 'Immutable Audit Trail',
    settings: 'Platform Settings & Supabase DDL'
  };

  const roleLabels: Record<UserRole, string> = {
    super_admin: 'Super Admin',
    admin: 'Admin',
    operator: 'Operator',
    viewer: 'Viewer'
  };

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between h-16 px-4 sm:px-6 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xs border-b border-slate-200/80 dark:border-slate-800">
      {/* Left: Menu button + Breadcrumb */}
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onOpenMobileMenu}
          className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 lg:hidden rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Open sidebar"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-600 dark:text-slate-400 hidden sm:inline">Fleet</span>
          <span className="text-xs text-slate-400 dark:text-slate-600 hidden sm:inline">/</span>
          <h1 className="text-sm font-semibold text-slate-900 dark:text-slate-100 whitespace-nowrap">
            {viewTitles[currentView] || 'Overview'}
          </h1>
        </div>
      </div>

      {/* Middle: Quick Omnisearch Trigger */}
      <div className="flex-1 max-w-md mx-4 hidden md:block">
        <button
          type="button"
          onClick={onOpenCommandPalette}
          className="flex items-center justify-between w-full px-3 py-1.5 text-xs text-slate-500 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg hover:border-slate-300 dark:hover:border-slate-600 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <span>Search fleet (TID, merchants, ref)...</span>
          </div>
          <kbd className="px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-white dark:bg-slate-700 border border-slate-200 dark:border-slate-600 rounded">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Right controls */}
      <div className="flex items-center gap-2">
        {/* Mobile Search button */}
        <button
          type="button"
          onClick={onOpenCommandPalette}
          className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 md:hidden rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
          aria-label="Search"
        >
          <Search className="w-4 h-4" />
        </button>

        {/* Quick Action Button */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowQuickActions(!showQuickActions)}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 shadow-xs transition-colors whitespace-nowrap shrink-0"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Quick Action</span>
            <ChevronDown className="w-3 h-3 text-indigo-200" />
          </button>

          {showQuickActions && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowQuickActions(false)}
              />
              <div className="absolute right-0 mt-1.5 w-52 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 p-1.5 animate-in fade-in zoom-in-95">
                {can('record:transaction') && (
                  <button
                    onClick={() => {
                      setShowQuickActions(false);
                      onOpenActionModal('record_transaction');
                    }}
                    className="flex items-center gap-2.5 w-full px-2.5 py-2 text-xs text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Receipt className="w-4 h-4 text-emerald-600" />
                    <span>Record Transaction</span>
                  </button>
                )}
                {can('record:activity') && (
                  <button
                    onClick={() => {
                      setShowQuickActions(false);
                      onOpenActionModal('record_activity');
                    }}
                    className="flex items-center gap-2.5 w-full px-2.5 py-2 text-xs text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Activity className="w-4 h-4 text-sky-600" />
                    <span>Record Activity</span>
                  </button>
                )}
                {can('create:terminal') && (
                  <button
                    onClick={() => {
                      setShowQuickActions(false);
                      onOpenActionModal('add_terminal');
                    }}
                    className="flex items-center gap-2.5 w-full px-2.5 py-2 text-xs text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <CreditCard className="w-4 h-4 text-indigo-600" />
                    <span>Add POS Terminal</span>
                  </button>
                )}
                {can('manage:merchants') && (
                  <button
                    onClick={() => {
                      setShowQuickActions(false);
                      onOpenActionModal('add_merchant');
                    }}
                    className="flex items-center gap-2.5 w-full px-2.5 py-2 text-xs text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Store className="w-4 h-4 text-amber-600" />
                    <span>Add Merchant</span>
                  </button>
                )}
                {can('manage:companies') && (
                  <button
                    onClick={() => {
                      setShowQuickActions(false);
                      onOpenActionModal('add_company');
                    }}
                    className="flex items-center gap-2.5 w-full px-2.5 py-2 text-xs text-left text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-md transition-colors"
                  >
                    <Building2 className="w-4 h-4 text-purple-600" />
                    <span>Add Company</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>

        {/* Dark Mode Toggle */}
        <button
          type="button"
          onClick={toggleDarkMode}
          className="p-2 text-slate-500 hover:text-slate-700 dark:hover:text-slate-300 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          aria-label="Toggle theme"
        >
          {isDarkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Persona Switcher / Role Selector for Immediate Review Testing */}
        <div className="relative">
          <button
            type="button"
            onClick={() => setShowPersonaMenu(!showPersonaMenu)}
            className="flex items-center gap-2 px-2.5 py-1.5 text-xs text-slate-700 dark:text-slate-200 bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-700/80 transition-colors"
          >
            <UserCheck className="w-3.5 h-3.5 text-indigo-500" />
            <div className="text-left hidden sm:block">
              <span className="block text-[10px] text-slate-600 dark:text-slate-400 leading-none">
                Role Persona
              </span>
              <span className="font-semibold text-xs leading-tight">
                {currentUser ? roleLabels[currentUser.role] : 'Select'}
              </span>
            </div>
            <ChevronDown className="w-3 h-3 text-slate-400" />
          </button>

          {showPersonaMenu && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={() => setShowPersonaMenu(false)}
              />
              <div className="absolute right-0 mt-1.5 w-64 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-xl z-50 p-2 animate-in fade-in zoom-in-95">
                <div className="px-2 py-1.5 mb-1 border-b border-slate-100 dark:border-slate-800">
                  <p className="text-[10px] font-semibold text-slate-600 dark:text-slate-400 uppercase tracking-wider">
                    Test Role Permissions
                  </p>
                  <p className="text-[11px] text-slate-500 mt-0.5">
                    Switch user to verify Super Admin, Admin, Operator, or Viewer access
                  </p>
                </div>
                <div className="space-y-1">
                  {allUsers.map(user => {
                    const isSelected = currentUser?.id === user.id;
                    return (
                      <button
                        key={user.id}
                        type="button"
                        onClick={() => {
                          switchPersona(user.id);
                          setShowPersonaMenu(false);
                        }}
                        className={`flex items-center justify-between w-full px-2.5 py-2 text-xs rounded-lg text-left transition-colors ${
                          isSelected
                            ? 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 font-medium'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
                        }`}
                      >
                        <div>
                          <p className="font-semibold">{user.full_name}</p>
                          <p className="text-[11px] text-slate-600 dark:text-slate-400">
                            {user.email}
                          </p>
                        </div>
                        <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 capitalize">
                          {user.role.replace('_', ' ')}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </header>
  );
};
