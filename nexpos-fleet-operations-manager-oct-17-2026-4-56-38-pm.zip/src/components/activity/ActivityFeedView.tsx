import React, { useState, useMemo } from 'react';
import {
  Activity,
  Filter,
  Plus,
  Search,
  CreditCard,
  Building2,
  Calendar,
  Clock,
  Wrench,
  Receipt,
  UserCheck
} from 'lucide-react';
import { storageService } from '../../services/storageService';
import { useAuth } from '../../context/AuthContext';
import { formatDateTime, formatRelativeTime } from '../../lib/utils';
import { ActivityType } from '../../types';

interface ActivityFeedViewProps {
  onOpenRecordActivity: () => void;
  onSelectTerminal?: (terminalId: string) => void;
}

export const ActivityFeedView: React.FC<ActivityFeedViewProps> = ({
  onOpenRecordActivity,
  onSelectTerminal
}) => {
  const { activeCompanyFilter, can } = useAuth();
  const activities = storageService.getActivities();
  const companies = storageService.getCompanies();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('');

  const filtered = useMemo(() => {
    return activities.filter(act => {
      if (activeCompanyFilter !== 'all' && act.company_id !== activeCompanyFilter) return false;
      if (selectedType && act.type !== selectedType) return false;

      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        return (
          act.description.toLowerCase().includes(q) ||
          act.user_name.toLowerCase().includes(q) ||
          (act.terminal_name && act.terminal_name.toLowerCase().includes(q))
        );
      }
      return true;
    });
  }, [activities, activeCompanyFilter, selectedType, searchQuery]);

  return (
    <div className="space-y-4 pb-12 animate-in fade-in duration-150">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-slate-100">
            Operational Activity Feed
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Real-time chronological log of hardware custody transfers, maintenance events, and field operations
          </p>
        </div>

        {can('record:activity') && (
          <button
            type="button"
            onClick={onOpenRecordActivity}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-white bg-indigo-600 rounded-lg hover:bg-indigo-700 transition-colors shadow-xs"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Operational Event</span>
          </button>
        )}
      </div>

      {/* Filters */}
      <div className="p-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            placeholder="Search activities by description, operator name, terminal..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <select
          value={selectedType}
          onChange={e => setSelectedType(e.target.value)}
          className="text-xs py-2 px-3 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-lg"
        >
          <option value="">All Activity Types</option>
          <option value="terminal_assigned">Terminal Assigned</option>
          <option value="transaction_recorded">Transaction Recorded</option>
          <option value="maintenance_started">Maintenance Started</option>
          <option value="maintenance_completed">Maintenance Completed</option>
          <option value="location_changed">Location Changed</option>
          <option value="terminal_created">Terminal Registered</option>
        </select>
      </div>

      {/* Timeline List */}
      <div className="p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xs">
        {filtered.length === 0 ? (
          <p className="text-center text-xs text-slate-500 py-8">
            No activities match your search filters.
          </p>
        ) : (
          <div className="relative border-l border-slate-200 dark:border-slate-800 ml-4 space-y-6">
            {filtered.map(act => (
              <div key={act.id} className="relative pl-6 group">
                {/* Bullet */}
                <div className="absolute -left-1.5 top-1.5 w-3 h-3 rounded-full border-2 border-white dark:border-slate-900 bg-indigo-600" />

                <div className="space-y-1">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs font-semibold text-slate-900 dark:text-slate-100">
                      {act.description}
                    </p>
                    <span className="text-[11px] text-slate-600 dark:text-slate-400 font-mono tabular-nums">
                      {formatDateTime(act.created_at)} ({formatRelativeTime(act.created_at)})
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-[11px] text-slate-600 dark:text-slate-400">
                    <span>
                      Operator: <strong className="text-slate-800 dark:text-slate-200">{act.user_name}</strong>
                    </span>
                    <span>·</span>
                    <span>
                      Company: <strong>{act.company_name || 'Fleet'}</strong>
                    </span>
                    {act.terminal_name && (
                      <>
                        <span>·</span>
                        <span
                          onClick={() => act.terminal_id && onSelectTerminal?.(act.terminal_id)}
                          className="text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer font-medium"
                        >
                          {act.terminal_name}
                        </span>
                      </>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
