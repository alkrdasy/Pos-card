import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ToastProvider, useToast } from './components/common/Toast';
import { Sidebar } from './components/layout/Sidebar';
import { Topbar } from './components/layout/Topbar';
import { MobileNav } from './components/layout/MobileNav';
import { CommandPalette } from './components/common/CommandPalette';

// Views
import { DashboardView } from './components/dashboard/DashboardView';
import { TerminalsListView } from './components/terminals/TerminalsListView';
import { TerminalDetailView } from './components/terminals/TerminalDetailView';
import { CompaniesListView } from './components/companies/CompaniesListView';
import { CompanyDetailView } from './components/companies/CompanyDetailView';
import { MerchantsListView } from './components/merchants/MerchantsListView';
import { MerchantDetailView } from './components/merchants/MerchantDetailView';
import { TransactionsListView } from './components/transactions/TransactionsListView';
import { ActivityFeedView } from './components/activity/ActivityFeedView';
import { AlertCenterView } from './components/alerts/AlertCenterView';
import { LocationsListView } from './components/locations/LocationsListView';
import { UsersListView } from './components/users/UsersListView';
import { ReportsView } from './components/reports/ReportsView';
import { AuditLogView } from './components/audit/AuditLogView';
import { SettingsView } from './components/settings/SettingsView';
import { LoginView } from './components/auth/LoginView';

// Modals
import { RecordTransactionModal } from './components/forms/RecordTransactionModal';
import { RecordActivityModal } from './components/forms/RecordActivityModal';
import { TerminalModal } from './components/forms/TerminalModal';
import { AssignTerminalModal } from './components/forms/AssignTerminalModal';
import { CompanyModal } from './components/forms/CompanyModal';
import { MerchantModal } from './components/forms/MerchantModal';
import { LocationModal } from './components/forms/LocationModal';
import { UserModal } from './components/forms/UserModal';
import { CsvImportModal } from './components/forms/CsvImportModal';

// Types
import { Terminal, Company, Merchant, Location, UserProfile } from './types';

function AppContent() {
  const { isAuthenticated, currentUser } = useAuth();
  const [currentView, setCurrentView] = useState<string>('dashboard');
  const [selectedTerminalId, setSelectedTerminalId] = useState<string | null>(null);
  const [selectedCompanyId, setSelectedCompanyId] = useState<string | null>(null);
  const [selectedMerchantId, setSelectedMerchantId] = useState<string | null>(null);
  const [selectedTransactionId, setSelectedTransactionId] = useState<string | undefined>(undefined);

  // Mobile menu & Command palette
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCommandPaletteOpen, setIsCommandPaletteOpen] = useState(false);

  // Modals state
  const [isRecordTxOpen, setIsRecordTxOpen] = useState(false);
  const [recordTxTerminalId, setRecordTxTerminalId] = useState<string | undefined>(undefined);

  const [isRecordActivityOpen, setIsRecordActivityOpen] = useState(false);
  const [recordActivityTerminalId, setRecordActivityTerminalId] = useState<string | undefined>(undefined);

  const [isTerminalModalOpen, setIsTerminalModalOpen] = useState(false);
  const [terminalToEdit, setTerminalToEdit] = useState<Terminal | null>(null);

  const [isAssignModalOpen, setIsAssignModalOpen] = useState(false);
  const [terminalToAssign, setTerminalToAssign] = useState<Terminal | null>(null);

  const [isCompanyModalOpen, setIsCompanyModalOpen] = useState(false);
  const [companyToEdit, setCompanyToEdit] = useState<Company | null>(null);

  const [isMerchantModalOpen, setIsMerchantModalOpen] = useState(false);
  const [merchantToEdit, setMerchantToEdit] = useState<Merchant | null>(null);

  const [isLocationModalOpen, setIsLocationModalOpen] = useState(false);
  const [locationToEdit, setLocationToEdit] = useState<Location | null>(null);

  const [isUserModalOpen, setIsUserModalOpen] = useState(false);
  const [userToEdit, setUserToEdit] = useState<UserProfile | null>(null);

  const [isCsvImportOpen, setIsCsvImportOpen] = useState(false);

  // Navigation router helper
  const handleNavigate = (view: string, entityId?: string) => {
    setCurrentView(view);
    if (view === 'terminals') {
      setSelectedTerminalId(entityId || null);
    } else if (view === 'companies') {
      setSelectedCompanyId(entityId || null);
    } else if (view === 'merchants') {
      setSelectedMerchantId(entityId || null);
    } else if (view === 'transactions') {
      setSelectedTransactionId(entityId);
    } else {
      setSelectedTerminalId(null);
      setSelectedCompanyId(null);
      setSelectedMerchantId(null);
      setSelectedTransactionId(undefined);
    }
  };

  const handleOpenActionModal = (action: string) => {
    switch (action) {
      case 'record_transaction':
        setRecordTxTerminalId(undefined);
        setIsRecordTxOpen(true);
        break;
      case 'record_activity':
        setRecordActivityTerminalId(undefined);
        setIsRecordActivityOpen(true);
        break;
      case 'add_terminal':
        setTerminalToEdit(null);
        setIsTerminalModalOpen(true);
        break;
      case 'add_merchant':
        setMerchantToEdit(null);
        setIsMerchantModalOpen(true);
        break;
      case 'add_company':
        setCompanyToEdit(null);
        setIsCompanyModalOpen(true);
        break;
      case 'add_location':
        setLocationToEdit(null);
        setIsLocationModalOpen(true);
        break;
      case 'add_user':
        setUserToEdit(null);
        setIsUserModalOpen(true);
        break;
      case 'import_csv':
        setIsCsvImportOpen(true);
        break;
      default:
        break;
    }
  };

  // Keyboard shortcut listener for Command Palette (Cmd+K / Ctrl+K / '/')
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsCommandPaletteOpen(prev => !prev);
      } else if (e.key === '/' && (e.target as HTMLElement).tagName !== 'INPUT' && (e.target as HTMLElement).tagName !== 'TEXTAREA') {
        e.preventDefault();
        setIsCommandPaletteOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!isAuthenticated) {
    return <LoginView onSuccess={() => setCurrentView('dashboard')} />;
  }

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col antialiased selection:bg-indigo-500/20 selection:text-indigo-900">
      {/* Sidebar (Desktop fixed + Mobile drawer) */}
      <Sidebar
        currentView={currentView}
        onNavigate={handleNavigate}
        isOpenMobile={isMobileMenuOpen}
        onCloseMobile={() => setIsMobileMenuOpen(false)}
      />

      {/* Main Container Area */}
      <div className="flex-1 lg:pl-64 flex flex-col min-h-screen">
        {/* Topbar */}
        <Topbar
          currentView={currentView}
          onOpenMobileMenu={() => setIsMobileMenuOpen(true)}
          onOpenCommandPalette={() => setIsCommandPaletteOpen(true)}
          onOpenActionModal={handleOpenActionModal}
        />

        {/* Dynamic Main Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto pb-20 lg:pb-12">
          {currentView === 'dashboard' && (
            <DashboardView
              onNavigate={handleNavigate}
              onOpenActionModal={handleOpenActionModal}
            />
          )}

          {currentView === 'terminals' && (
            selectedTerminalId ? (
              <TerminalDetailView
                terminalId={selectedTerminalId}
                onBack={() => setSelectedTerminalId(null)}
                onOpenAssignModal={terminal => {
                  setTerminalToAssign(terminal);
                  setIsAssignModalOpen(true);
                }}
                onOpenEditModal={terminal => {
                  setTerminalToEdit(terminal);
                  setIsTerminalModalOpen(true);
                }}
                onOpenRecordTx={termId => {
                  setRecordTxTerminalId(termId);
                  setIsRecordTxOpen(true);
                }}
                onOpenRecordActivity={termId => {
                  setRecordActivityTerminalId(termId);
                  setIsRecordActivityOpen(true);
                }}
              />
            ) : (
              <TerminalsListView
                onSelectTerminal={id => setSelectedTerminalId(id)}
                onOpenCreateModal={() => {
                  setTerminalToEdit(null);
                  setIsTerminalModalOpen(true);
                }}
                onOpenAssignModal={terminal => {
                  setTerminalToAssign(terminal);
                  setIsAssignModalOpen(true);
                }}
                onOpenImportModal={() => setIsCsvImportOpen(true)}
              />
            )
          )}

          {currentView === 'companies' && (
            selectedCompanyId ? (
              <CompanyDetailView
                companyId={selectedCompanyId}
                onBack={() => setSelectedCompanyId(null)}
                onOpenEditModal={comp => {
                  setCompanyToEdit(comp);
                  setIsCompanyModalOpen(true);
                }}
                onSelectTerminal={termId => {
                  setCurrentView('terminals');
                  setSelectedTerminalId(termId);
                }}
                onSelectMerchant={merchId => {
                  setCurrentView('merchants');
                  setSelectedMerchantId(merchId);
                }}
              />
            ) : (
              <CompaniesListView
                onSelectCompany={id => setSelectedCompanyId(id)}
                onOpenCreateModal={() => {
                  setCompanyToEdit(null);
                  setIsCompanyModalOpen(true);
                }}
                onOpenEditModal={comp => {
                  setCompanyToEdit(comp);
                  setIsCompanyModalOpen(true);
                }}
              />
            )
          )}

          {currentView === 'merchants' && (
            selectedMerchantId ? (
              <MerchantDetailView
                merchantId={selectedMerchantId}
                onBack={() => setSelectedMerchantId(null)}
                onOpenEditModal={m => {
                  setMerchantToEdit(m);
                  setIsMerchantModalOpen(true);
                }}
                onSelectTerminal={termId => {
                  setCurrentView('terminals');
                  setSelectedTerminalId(termId);
                }}
              />
            ) : (
              <MerchantsListView
                onSelectMerchant={id => setSelectedMerchantId(id)}
                onOpenCreateModal={() => {
                  setMerchantToEdit(null);
                  setIsMerchantModalOpen(true);
                }}
                onOpenEditModal={m => {
                  setMerchantToEdit(m);
                  setIsMerchantModalOpen(true);
                }}
              />
            )
          )}

          {currentView === 'transactions' && (
            <TransactionsListView
              onOpenRecordModal={() => {
                setRecordTxTerminalId(undefined);
                setIsRecordTxOpen(true);
              }}
              selectedTransactionId={selectedTransactionId}
            />
          )}

          {currentView === 'activity' && (
            <ActivityFeedView
              onOpenRecordActivity={() => {
                setRecordActivityTerminalId(undefined);
                setIsRecordActivityOpen(true);
              }}
              onSelectTerminal={termId => {
                setCurrentView('terminals');
                setSelectedTerminalId(termId);
              }}
            />
          )}

          {currentView === 'alerts' && (
            <AlertCenterView
              onNavigateToEntity={(type, id) => {
                if (type === 'terminal') {
                  setCurrentView('terminals');
                  setSelectedTerminalId(id);
                } else if (type === 'transaction') {
                  setCurrentView('transactions');
                  setSelectedTransactionId(id);
                }
              }}
            />
          )}

          {currentView === 'locations' && (
            <LocationsListView
              onOpenCreateModal={() => {
                setLocationToEdit(null);
                setIsLocationModalOpen(true);
              }}
              onOpenEditModal={loc => {
                setLocationToEdit(loc);
                setIsLocationModalOpen(true);
              }}
              onSelectTerminal={termId => {
                setCurrentView('terminals');
                setSelectedTerminalId(termId);
              }}
            />
          )}

          {currentView === 'users' && (
            <UsersListView
              onOpenCreateModal={() => {
                setUserToEdit(null);
                setIsUserModalOpen(true);
              }}
              onOpenEditModal={u => {
                setUserToEdit(u);
                setIsUserModalOpen(true);
              }}
              onSelectTerminal={termId => {
                setCurrentView('terminals');
                setSelectedTerminalId(termId);
              }}
            />
          )}

          {currentView === 'reports' && <ReportsView />}

          {currentView === 'audit' && <AuditLogView />}

          {currentView === 'settings' && <SettingsView />}
        </main>
      </div>

      {/* Mobile Ergonomic Bottom Navigation */}
      <MobileNav
        currentView={currentView}
        onNavigate={handleNavigate}
        onOpenRecordTx={() => {
          setRecordTxTerminalId(undefined);
          setIsRecordTxOpen(true);
        }}
      />

      {/* Global Command Palette */}
      <CommandPalette
        isOpen={isCommandPaletteOpen}
        onClose={() => setIsCommandPaletteOpen(false)}
        onNavigate={handleNavigate}
        onOpenActionModal={handleOpenActionModal}
      />

      {/* Action Modals */}
      <RecordTransactionModal
        isOpen={isRecordTxOpen}
        onClose={() => setIsRecordTxOpen(false)}
        preselectedTerminalId={recordTxTerminalId}
      />

      <RecordActivityModal
        isOpen={isRecordActivityOpen}
        onClose={() => setIsRecordActivityOpen(false)}
        preselectedTerminalId={recordActivityTerminalId}
      />

      <TerminalModal
        isOpen={isTerminalModalOpen}
        onClose={() => setIsTerminalModalOpen(false)}
        terminalToEdit={terminalToEdit}
        onSuccess={t => {
          setSelectedTerminalId(t.id);
          setCurrentView('terminals');
        }}
      />

      <AssignTerminalModal
        isOpen={isAssignModalOpen}
        onClose={() => setIsAssignModalOpen(false)}
        terminal={terminalToAssign}
      />

      <CompanyModal
        isOpen={isCompanyModalOpen}
        onClose={() => setIsCompanyModalOpen(false)}
        companyToEdit={companyToEdit}
      />

      <MerchantModal
        isOpen={isMerchantModalOpen}
        onClose={() => setIsMerchantModalOpen(false)}
        merchantToEdit={merchantToEdit}
      />

      <LocationModal
        isOpen={isLocationModalOpen}
        onClose={() => setIsLocationModalOpen(false)}
        locationToEdit={locationToEdit}
      />

      <UserModal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        userToEdit={userToEdit}
      />

      <CsvImportModal
        isOpen={isCsvImportOpen}
        onClose={() => setIsCsvImportOpen(false)}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <ToastProvider>
        <AppContent />
      </ToastProvider>
    </AuthProvider>
  );
}
