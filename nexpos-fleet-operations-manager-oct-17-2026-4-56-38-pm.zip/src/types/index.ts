export type UserRole = 'super_admin' | 'admin' | 'operator' | 'viewer';

export type UserStatus = 'active' | 'inactive' | 'suspended';

export interface UserProfile {
  id: string;
  auth_user_id: string;
  full_name: string;
  email: string;
  phone: string;
  role: UserRole;
  avatar_url?: string;
  company_id?: string; // Optional: assigned company if not super_admin
  company_name?: string;
  status: UserStatus;
  created_at: string;
  updated_at: string;
}

export type CompanyStatus = 'active' | 'inactive' | 'archived';

export interface Company {
  id: string;
  name: string;
  legal_name: string;
  registration_number: string;
  contact_name: string;
  contact_phone: string;
  contact_email: string;
  status: CompanyStatus;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Merchant {
  id: string;
  company_id: string;
  company_name?: string;
  merchant_name: string;
  merchant_identifier: string; // MID
  business_category: string;
  contact_name: string;
  contact_phone: string;
  location_id?: string;
  location_name?: string;
  status: 'active' | 'inactive' | 'suspended';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export type TerminalStatus = 'active' | 'inactive' | 'maintenance' | 'lost' | 'retired';

export type TerminalProvider = 'Verifone' | 'Ingenico' | 'PAX' | 'Sunmi' | 'Castles' | 'Clover' | 'Other';

export interface Terminal {
  id: string;
  company_id: string;
  company_name?: string;
  merchant_id?: string;
  merchant_name?: string;
  terminal_name: string;
  terminal_identifier: string; // TID (unique)
  terminal_model: string;
  provider: TerminalProvider;
  serial_number: string; // Serial (unique)
  owner_name: string;
  assigned_user_id?: string;
  assigned_user_name?: string;
  location_id?: string;
  location_name?: string;
  status: TerminalStatus;
  installation_date: string;
  last_seen_at: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface Location {
  id: string;
  company_id: string;
  company_name?: string;
  name: string;
  address: string;
  city: string;
  area: string;
  latitude?: number;
  longitude?: number;
  contact_name: string;
  contact_phone: string;
  status: 'active' | 'inactive';
  notes?: string;
  created_at: string;
  updated_at: string;
}

export interface AssignmentHistory {
  id: string;
  terminal_id: string;
  terminal_name?: string;
  user_id: string;
  user_name: string;
  assigned_by: string;
  assigned_by_name: string;
  assigned_at: string;
  unassigned_at?: string | null;
  status: 'active' | 'completed' | 'transferred';
  notes?: string;
  created_at: string;
}

export type TransactionType = 'sale' | 'refund' | 'void' | 'adjustment' | 'other';

export type TransactionStatus = 'pending' | 'completed' | 'failed' | 'cancelled' | 'under_review';

export interface TransactionRecord {
  id: string;
  company_id: string;
  company_name?: string;
  merchant_id: string;
  merchant_name?: string;
  terminal_id: string;
  terminal_name?: string;
  operator_id: string;
  operator_name?: string;
  external_reference: string; // Reference number from POS slip
  masked_reference?: string; // e.g. "VISA ************4242"
  transaction_type: TransactionType;
  amount: number;
  currency: string;
  status: TransactionStatus;
  transaction_time: string;
  recorded_at: string;
  notes?: string;
  is_duplicate_warning?: boolean;
  created_at: string;
  updated_at: string;
}

export type ActivityType =
  | 'terminal_created'
  | 'terminal_updated'
  | 'terminal_assigned'
  | 'terminal_unassigned'
  | 'terminal_activated'
  | 'terminal_deactivated'
  | 'maintenance_started'
  | 'maintenance_completed'
  | 'location_changed'
  | 'operator_login'
  | 'transaction_recorded'
  | 'transaction_updated'
  | 'transaction_reviewed'
  | 'company_created'
  | 'merchant_created';

export interface ActivityItem {
  id: string;
  type: ActivityType;
  terminal_id?: string;
  terminal_name?: string;
  company_id: string;
  company_name?: string;
  user_id: string;
  user_name: string;
  description: string;
  metadata?: Record<string, any>;
  created_at: string;
}

export type AlertSeverity = 'critical' | 'warning' | 'info';

export type AlertStatus = 'open' | 'acknowledged' | 'resolved';

export interface AlertItem {
  id: string;
  severity: AlertSeverity;
  title: string;
  description: string;
  related_entity_type: 'terminal' | 'transaction' | 'merchant' | 'company' | 'user';
  related_entity_id: string;
  related_entity_label: string;
  status: AlertStatus;
  acknowledged_by?: string;
  acknowledged_at?: string;
  resolved_by?: string;
  resolved_at?: string;
  created_at: string;
}

export interface AuditLog {
  id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  user_role: UserRole;
  action: string;
  entity: 'terminal' | 'transaction' | 'company' | 'merchant' | 'location' | 'assignment' | 'user' | 'alert' | 'settings' | 'auth';
  entity_id: string;
  description: string;
  ip_address?: string;
  metadata?: Record<string, any>;
  created_at: string;
}

export interface NavigationItem {
  name: string;
  href: string;
  icon: string;
  badge?: number;
  badgeVariant?: 'default' | 'danger' | 'warning';
  roles: UserRole[];
}
