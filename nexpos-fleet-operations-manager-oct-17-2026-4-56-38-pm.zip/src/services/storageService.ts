import {
  Company,
  Merchant,
  Terminal,
  Location,
  UserProfile,
  TransactionRecord,
  ActivityItem,
  AlertItem,
  AuditLog,
  AssignmentHistory,
  TerminalStatus,
  TransactionStatus
} from '../types';
import {
  INITIAL_COMPANIES,
  INITIAL_MERCHANTS,
  INITIAL_TERMINALS,
  INITIAL_LOCATIONS,
  INITIAL_USERS,
  INITIAL_TRANSACTIONS,
  INITIAL_ACTIVITIES,
  INITIAL_ALERTS,
  INITIAL_AUDIT_LOGS,
  INITIAL_ASSIGNMENTS
} from '../lib/constants';

const STORAGE_KEYS = {
  COMPANIES: 'nexpos_companies_v1',
  MERCHANTS: 'nexpos_merchants_v1',
  TERMINALS: 'nexpos_terminals_v1',
  LOCATIONS: 'nexpos_locations_v1',
  USERS: 'nexpos_users_v1',
  TRANSACTIONS: 'nexpos_transactions_v1',
  ACTIVITIES: 'nexpos_activities_v1',
  ALERTS: 'nexpos_alerts_v1',
  AUDIT_LOGS: 'nexpos_audit_logs_v1',
  ASSIGNMENTS: 'nexpos_assignments_v1',
  INITIALIZED: 'nexpos_db_initialized_v1'
};

class StorageService {
  private companies: Company[] = [];
  private merchants: Merchant[] = [];
  private terminals: Terminal[] = [];
  private locations: Location[] = [];
  private users: UserProfile[] = [];
  private transactions: TransactionRecord[] = [];
  private activities: ActivityItem[] = [];
  private alerts: AlertItem[] = [];
  private auditLogs: AuditLog[] = [];
  private assignments: AssignmentHistory[] = [];
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.init();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify() {
    this.listeners.forEach(fn => {
      try {
        fn();
      } catch (err) {
        console.error('Error in storage listener', err);
      }
    });
  }

  private init() {
    try {
      const isInitialized = localStorage.getItem(STORAGE_KEYS.INITIALIZED);
      if (!isInitialized) {
        this.resetToDefaults();
        return;
      }

      this.companies = this.load(STORAGE_KEYS.COMPANIES, INITIAL_COMPANIES);
      this.merchants = this.load(STORAGE_KEYS.MERCHANTS, INITIAL_MERCHANTS);
      this.terminals = this.load(STORAGE_KEYS.TERMINALS, INITIAL_TERMINALS);
      this.locations = this.load(STORAGE_KEYS.LOCATIONS, INITIAL_LOCATIONS);
      this.users = this.load(STORAGE_KEYS.USERS, INITIAL_USERS);
      this.transactions = this.load(STORAGE_KEYS.TRANSACTIONS, INITIAL_TRANSACTIONS);
      this.activities = this.load(STORAGE_KEYS.ACTIVITIES, INITIAL_ACTIVITIES);
      this.alerts = this.load(STORAGE_KEYS.ALERTS, INITIAL_ALERTS);
      this.auditLogs = this.load(STORAGE_KEYS.AUDIT_LOGS, INITIAL_AUDIT_LOGS);
      this.assignments = this.load(STORAGE_KEYS.ASSIGNMENTS, INITIAL_ASSIGNMENTS);
    } catch (e) {
      console.warn('Failed to load from localStorage, initializing in-memory store', e);
      this.resetToDefaults();
    }
  }

  public resetToDefaults() {
    this.companies = [...INITIAL_COMPANIES];
    this.merchants = [...INITIAL_MERCHANTS];
    this.terminals = [...INITIAL_TERMINALS];
    this.locations = [...INITIAL_LOCATIONS];
    this.users = [...INITIAL_USERS];
    this.transactions = [...INITIAL_TRANSACTIONS];
    this.activities = [...INITIAL_ACTIVITIES];
    this.alerts = [...INITIAL_ALERTS];
    this.auditLogs = [...INITIAL_AUDIT_LOGS];
    this.assignments = [...INITIAL_ASSIGNMENTS];

    this.persistAll();
    localStorage.setItem(STORAGE_KEYS.INITIALIZED, 'true');
    this.notify();
  }

  private load<T>(key: string, fallback: T[]): T[] {
    const data = localStorage.getItem(key);
    if (!data) return fallback;
    try {
      return JSON.parse(data);
    } catch {
      return fallback;
    }
  }

  private save(key: string, data: any) {
    try {
      localStorage.setItem(key, JSON.stringify(data));
    } catch (e) {
      console.error(`Failed to save to localStorage key: ${key}`, e);
    }
  }

  private persistAll() {
    this.save(STORAGE_KEYS.COMPANIES, this.companies);
    this.save(STORAGE_KEYS.MERCHANTS, this.merchants);
    this.save(STORAGE_KEYS.TERMINALS, this.terminals);
    this.save(STORAGE_KEYS.LOCATIONS, this.locations);
    this.save(STORAGE_KEYS.USERS, this.users);
    this.save(STORAGE_KEYS.TRANSACTIONS, this.transactions);
    this.save(STORAGE_KEYS.ACTIVITIES, this.activities);
    this.save(STORAGE_KEYS.ALERTS, this.alerts);
    this.save(STORAGE_KEYS.AUDIT_LOGS, this.auditLogs);
    this.save(STORAGE_KEYS.ASSIGNMENTS, this.assignments);
  }

  // ==========================================
  // AUDIT LOGGING (Immutable server-style trail)
  // ==========================================
  public logAudit(entry: Omit<AuditLog, 'id' | 'created_at'>): AuditLog {
    const newLog: AuditLog = {
      ...entry,
      id: `aud_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      created_at: new Date().toISOString()
    };
    this.auditLogs.unshift(newLog);
    this.save(STORAGE_KEYS.AUDIT_LOGS, this.auditLogs);
    this.notify();
    return newLog;
  }

  public getAuditLogs(): AuditLog[] {
    return [...this.auditLogs];
  }

  // ==========================================
  // ACTIVITY LOGGING
  // ==========================================
  public logActivity(entry: Omit<ActivityItem, 'id' | 'created_at'>): ActivityItem {
    const newActivity: ActivityItem = {
      ...entry,
      id: `act_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
      created_at: new Date().toISOString()
    };
    this.activities.unshift(newActivity);
    this.save(STORAGE_KEYS.ACTIVITIES, this.activities);
    this.notify();
    return newActivity;
  }

  public getActivities(limit = 100): ActivityItem[] {
    return this.activities.slice(0, limit);
  }

  // ==========================================
  // COMPANIES
  // ==========================================
  public getCompanies(): Company[] {
    return [...this.companies];
  }

  public getCompanyById(id: string): Company | undefined {
    return this.companies.find(c => c.id === id);
  }

  public createCompany(data: Omit<Company, 'id' | 'created_at' | 'updated_at'>, actor: UserProfile): Company {
    // Uniqueness validation on registration number
    const exists = this.companies.find(
      c => c.registration_number.toLowerCase() === data.registration_number.trim().toLowerCase()
    );
    if (exists) {
      throw new Error(`Company registration number '${data.registration_number}' is already registered.`);
    }

    const now = new Date().toISOString();
    const newCompany: Company = {
      ...data,
      id: `comp_${Date.now()}`,
      created_at: now,
      updated_at: now
    };

    this.companies.unshift(newCompany);
    this.save(STORAGE_KEYS.COMPANIES, this.companies);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'company_created',
      entity: 'company',
      entity_id: newCompany.id,
      description: `Created company '${newCompany.name}' (${newCompany.registration_number})`,
      metadata: { ...newCompany }
    });

    this.logActivity({
      type: 'company_created',
      company_id: newCompany.id,
      company_name: newCompany.name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} created company ${newCompany.name}`
    });

    this.notify();
    return newCompany;
  }

  public updateCompany(id: string, data: Partial<Company>, actor: UserProfile): Company {
    const index = this.companies.findIndex(c => c.id === id);
    if (index === -1) throw new Error('Company not found');

    const old = this.companies[index];
    const updated: Company = {
      ...old,
      ...data,
      updated_at: new Date().toISOString()
    };

    this.companies[index] = updated;
    this.save(STORAGE_KEYS.COMPANIES, this.companies);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'company_updated',
      entity: 'company',
      entity_id: updated.id,
      description: `Updated company details for '${updated.name}'`,
      metadata: { before: old, after: updated }
    });

    this.notify();
    return updated;
  }

  public archiveCompany(id: string, actor: UserProfile): Company {
    return this.updateCompany(id, { status: 'archived' }, actor);
  }

  // ==========================================
  // MERCHANTS
  // ==========================================
  public getMerchants(): Merchant[] {
    return [...this.merchants];
  }

  public getMerchantById(id: string): Merchant | undefined {
    return this.merchants.find(m => m.id === id);
  }

  public createMerchant(data: Omit<Merchant, 'id' | 'created_at' | 'updated_at'>, actor: UserProfile): Merchant {
    // Uniqueness validation on merchant identifier (MID)
    const exists = this.merchants.find(
      m => m.merchant_identifier.toLowerCase() === data.merchant_identifier.trim().toLowerCase()
    );
    if (exists) {
      throw new Error(`Merchant Identifier (MID) '${data.merchant_identifier}' already exists.`);
    }

    const company = this.getCompanyById(data.company_id);
    const location = data.location_id ? this.getLocationById(data.location_id) : undefined;

    const now = new Date().toISOString();
    const newMerchant: Merchant = {
      ...data,
      id: `merch_${Date.now()}`,
      company_name: company?.name || data.company_name,
      location_name: location?.name || data.location_name,
      created_at: now,
      updated_at: now
    };

    this.merchants.unshift(newMerchant);
    this.save(STORAGE_KEYS.MERCHANTS, this.merchants);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'merchant_created',
      entity: 'merchant',
      entity_id: newMerchant.id,
      description: `Created merchant '${newMerchant.merchant_name}' under '${company?.name || 'Company'}'`,
      metadata: { ...newMerchant }
    });

    this.notify();
    return newMerchant;
  }

  public updateMerchant(id: string, data: Partial<Merchant>, actor: UserProfile): Merchant {
    const index = this.merchants.findIndex(m => m.id === id);
    if (index === -1) throw new Error('Merchant not found');

    const old = this.merchants[index];
    const updated: Merchant = {
      ...old,
      ...data,
      updated_at: new Date().toISOString()
    };

    this.merchants[index] = updated;
    this.save(STORAGE_KEYS.MERCHANTS, this.merchants);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'merchant_updated',
      entity: 'merchant',
      entity_id: updated.id,
      description: `Updated merchant '${updated.merchant_name}'`,
      metadata: { before: old, after: updated }
    });

    this.notify();
    return updated;
  }

  // ==========================================
  // POS TERMINALS
  // ==========================================
  public getTerminals(): Terminal[] {
    return [...this.terminals];
  }

  public getTerminalById(id: string): Terminal | undefined {
    return this.terminals.find(t => t.id === id);
  }

  public createTerminal(data: Omit<Terminal, 'id' | 'created_at' | 'updated_at' | 'last_seen_at'>, actor: UserProfile): Terminal {
    // Uniqueness validation on terminal_identifier (TID)
    const existingTid = this.terminals.find(
      t => t.terminal_identifier.trim().toLowerCase() === data.terminal_identifier.trim().toLowerCase()
    );
    if (existingTid) {
      throw new Error(`Terminal Identifier (TID) '${data.terminal_identifier}' is already registered.`);
    }

    // Uniqueness validation on serial_number
    const existingSerial = this.terminals.find(
      t => t.serial_number.trim().toLowerCase() === data.serial_number.trim().toLowerCase()
    );
    if (existingSerial) {
      throw new Error(`Serial Number '${data.serial_number}' is already assigned to terminal '${existingSerial.terminal_name}'.`);
    }

    const company = this.getCompanyById(data.company_id);
    const merchant = data.merchant_id ? this.getMerchantById(data.merchant_id) : undefined;
    const location = data.location_id ? this.getLocationById(data.location_id) : undefined;
    const assignedUser = data.assigned_user_id ? this.getUserById(data.assigned_user_id) : undefined;

    const now = new Date().toISOString();
    const newTerminal: Terminal = {
      ...data,
      id: `term_${Date.now()}`,
      company_name: company?.name || data.company_name,
      merchant_name: merchant?.merchant_name || data.merchant_name,
      location_name: location?.name || data.location_name,
      assigned_user_name: assignedUser?.full_name || data.assigned_user_name,
      last_seen_at: now,
      created_at: now,
      updated_at: now
    };

    this.terminals.unshift(newTerminal);
    this.save(STORAGE_KEYS.TERMINALS, this.terminals);

    // If initial assignment is made
    if (newTerminal.assigned_user_id) {
      this.recordAssignment(
        newTerminal.id,
        newTerminal.assigned_user_id,
        actor,
        'Initial deployment assignment'
      );
    }

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'terminal_created',
      entity: 'terminal',
      entity_id: newTerminal.id,
      description: `Registered POS Terminal '${newTerminal.terminal_name}' (${newTerminal.terminal_identifier})`,
      metadata: { ...newTerminal }
    });

    this.logActivity({
      type: 'terminal_created',
      terminal_id: newTerminal.id,
      terminal_name: newTerminal.terminal_name,
      company_id: newTerminal.company_id,
      company_name: newTerminal.company_name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} created terminal ${newTerminal.terminal_name} (${newTerminal.terminal_identifier})`
    });

    this.notify();
    return newTerminal;
  }

  public updateTerminal(id: string, data: Partial<Terminal>, actor: UserProfile): Terminal {
    const index = this.terminals.findIndex(t => t.id === id);
    if (index === -1) throw new Error('Terminal not found');

    const old = this.terminals[index];

    // Check TID uniqueness if modified
    if (data.terminal_identifier && data.terminal_identifier.trim().toLowerCase() !== old.terminal_identifier.trim().toLowerCase()) {
      const conflict = this.terminals.find(
        t => t.id !== id && t.terminal_identifier.trim().toLowerCase() === data.terminal_identifier!.trim().toLowerCase()
      );
      if (conflict) {
        throw new Error(`Terminal Identifier '${data.terminal_identifier}' is already in use.`);
      }
    }

    // Check Serial uniqueness if modified
    if (data.serial_number && data.serial_number.trim().toLowerCase() !== old.serial_number.trim().toLowerCase()) {
      const conflict = this.terminals.find(
        t => t.id !== id && t.serial_number.trim().toLowerCase() === data.serial_number!.trim().toLowerCase()
      );
      if (conflict) {
        throw new Error(`Serial Number '${data.serial_number}' is already in use.`);
      }
    }

    const company = data.company_id ? this.getCompanyById(data.company_id) : undefined;
    const merchant = data.merchant_id ? this.getMerchantById(data.merchant_id) : undefined;
    const location = data.location_id ? this.getLocationById(data.location_id) : undefined;
    const assignedUser = data.assigned_user_id ? this.getUserById(data.assigned_user_id) : undefined;

    const updated: Terminal = {
      ...old,
      ...data,
      company_name: company ? company.name : (data.company_name || old.company_name),
      merchant_name: merchant ? merchant.merchant_name : (data.merchant_name || old.merchant_name),
      location_name: location ? location.name : (data.location_name || old.location_name),
      assigned_user_name: assignedUser ? assignedUser.full_name : (data.assigned_user_id === null ? undefined : old.assigned_user_name),
      updated_at: new Date().toISOString()
    };

    this.terminals[index] = updated;
    this.save(STORAGE_KEYS.TERMINALS, this.terminals);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'terminal_updated',
      entity: 'terminal',
      entity_id: updated.id,
      description: `Updated terminal specs for '${updated.terminal_name}'`,
      metadata: { before: old, after: updated }
    });

    this.notify();
    return updated;
  }

  public updateTerminalStatus(id: string, newStatus: TerminalStatus, actor: UserProfile, reason?: string): Terminal {
    const terminal = this.getTerminalById(id);
    if (!terminal) throw new Error('Terminal not found');

    const oldStatus = terminal.status;
    const updated = this.updateTerminal(id, { status: newStatus }, actor);

    let activityType: ActivityItem['type'] = 'terminal_updated';
    if (newStatus === 'maintenance') activityType = 'maintenance_started';
    else if (oldStatus === 'maintenance' && newStatus === 'active') activityType = 'maintenance_completed';
    else if (newStatus === 'active') activityType = 'terminal_activated';
    else if (newStatus === 'inactive') activityType = 'terminal_deactivated';

    this.logActivity({
      type: activityType,
      terminal_id: terminal.id,
      terminal_name: terminal.terminal_name,
      company_id: terminal.company_id,
      company_name: terminal.company_name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} changed ${terminal.terminal_name} status from ${oldStatus} to ${newStatus}${reason ? `: ${reason}` : ''}`
    });

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'terminal_status_changed',
      entity: 'terminal',
      entity_id: terminal.id,
      description: `Status changed from ${oldStatus} to ${newStatus}`,
      metadata: { old_status: oldStatus, new_status: newStatus, reason }
    });

    this.notify();
    return updated;
  }

  // ==========================================
  // TERMINAL ASSIGNMENTS (Historical tracking)
  // ==========================================
  public assignTerminal(terminalId: string, newUserId: string, actor: UserProfile, notes?: string): Terminal {
    const terminal = this.getTerminalById(terminalId);
    if (!terminal) throw new Error('Terminal not found');

    if (terminal.status === 'retired' || terminal.status === 'lost') {
      throw new Error(`Cannot assign a terminal marked as ${terminal.status}.`);
    }

    const newUser = this.getUserById(newUserId);
    if (!newUser) throw new Error('Assignee user not found');

    const previousUserId = terminal.assigned_user_id;
    const previousUserName = terminal.assigned_user_name;

    // 1. Close current open assignment in history
    const now = new Date().toISOString();
    const openAssignment = this.assignments.find(a => a.terminal_id === terminalId && a.status === 'active');
    if (openAssignment) {
      openAssignment.unassigned_at = now;
      openAssignment.status = 'transferred';
    }

    // 2. Create new assignment entry
    const newAssignment: AssignmentHistory = {
      id: `asgn_${Date.now()}`,
      terminal_id: terminal.id,
      terminal_name: terminal.terminal_name,
      user_id: newUser.id,
      user_name: newUser.full_name,
      assigned_by: actor.id,
      assigned_by_name: actor.full_name,
      assigned_at: now,
      unassigned_at: null,
      status: 'active',
      notes: notes || 'Operational reassignment',
      created_at: now
    };
    this.assignments.unshift(newAssignment);
    this.save(STORAGE_KEYS.ASSIGNMENTS, this.assignments);

    // 3. Update terminal state
    const updatedTerminal = this.updateTerminal(
      terminalId,
      {
        assigned_user_id: newUser.id,
        assigned_user_name: newUser.full_name,
        owner_name: newUser.full_name
      },
      actor
    );

    // 4. Log activity
    this.logActivity({
      type: 'terminal_assigned',
      terminal_id: terminal.id,
      terminal_name: terminal.terminal_name,
      company_id: terminal.company_id,
      company_name: terminal.company_name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} assigned ${terminal.terminal_name} to ${newUser.full_name}${previousUserName ? ` (previously ${previousUserName})` : ''}`
    });

    // 5. Audit Log
    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'terminal_assigned',
      entity: 'assignment',
      entity_id: newAssignment.id,
      description: `Assigned ${terminal.terminal_name} to ${newUser.full_name}`,
      metadata: {
        terminal_id: terminal.id,
        terminal_identifier: terminal.terminal_identifier,
        previous_user_id: previousUserId,
        previous_user_name: previousUserName,
        new_user_id: newUser.id,
        new_user_name: newUser.full_name,
        notes
      }
    });

    this.notify();
    return updatedTerminal;
  }

  public unassignTerminal(terminalId: string, actor: UserProfile, notes?: string): Terminal {
    const terminal = this.getTerminalById(terminalId);
    if (!terminal) throw new Error('Terminal not found');

    const previousUserId = terminal.assigned_user_id;
    const previousUserName = terminal.assigned_user_name;

    const now = new Date().toISOString();
    const openAssignment = this.assignments.find(a => a.terminal_id === terminalId && a.status === 'active');
    if (openAssignment) {
      openAssignment.unassigned_at = now;
      openAssignment.status = 'completed';
      if (notes) openAssignment.notes = `${openAssignment.notes ? openAssignment.notes + ' | ' : ''}Unassigned: ${notes}`;
    }
    this.save(STORAGE_KEYS.ASSIGNMENTS, this.assignments);

    const updatedTerminal = this.updateTerminal(
      terminalId,
      {
        assigned_user_id: undefined,
        assigned_user_name: undefined
      },
      actor
    );

    this.logActivity({
      type: 'terminal_unassigned',
      terminal_id: terminal.id,
      terminal_name: terminal.terminal_name,
      company_id: terminal.company_id,
      company_name: terminal.company_name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} unassigned ${terminal.terminal_name} from ${previousUserName || 'operator'}`
    });

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'terminal_unassigned',
      entity: 'assignment',
      entity_id: terminalId,
      description: `Unassigned ${terminal.terminal_name} from ${previousUserName || 'operator'}`,
      metadata: { previousUserId, previousUserName, notes }
    });

    this.notify();
    return updatedTerminal;
  }

  private recordAssignment(terminalId: string, userId: string, actor: UserProfile, notes?: string) {
    const terminal = this.getTerminalById(terminalId);
    const user = this.getUserById(userId);
    if (!terminal || !user) return;

    const now = new Date().toISOString();
    const assignment: AssignmentHistory = {
      id: `asgn_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      terminal_id: terminalId,
      terminal_name: terminal.terminal_name,
      user_id: user.id,
      user_name: user.full_name,
      assigned_by: actor.id,
      assigned_by_name: actor.full_name,
      assigned_at: now,
      unassigned_at: null,
      status: 'active',
      notes: notes || 'System assignment',
      created_at: now
    };
    this.assignments.unshift(assignment);
    this.save(STORAGE_KEYS.ASSIGNMENTS, this.assignments);
  }

  public getAssignments(terminalId?: string): AssignmentHistory[] {
    if (terminalId) {
      return this.assignments.filter(a => a.terminal_id === terminalId);
    }
    return [...this.assignments];
  }

  // ==========================================
  // TRANSACTIONS & DUPLICATE DETECTION
  // ==========================================
  public getTransactions(): TransactionRecord[] {
    return [...this.transactions];
  }

  public getTransactionById(id: string): TransactionRecord | undefined {
    return this.transactions.find(t => t.id === id);
  }

  /**
   * Checks whether an external reference already exists in the system.
   * Required for duplicate prevention.
   */
  public isDuplicateReference(externalReference: string, excludeId?: string): boolean {
    if (!externalReference || !externalReference.trim()) return false;
    const cleanRef = externalReference.trim().toLowerCase();
    return this.transactions.some(
      t => (!excludeId || t.id !== excludeId) && t.external_reference.trim().toLowerCase() === cleanRef
    );
  }

  /**
   * Check for potential duplicate pattern:
   * Same terminal, same amount, within a 15-minute window.
   */
  public hasDuplicatePattern(terminalId: string, amount: number, timestampStr: string): TransactionRecord | undefined {
    const targetTime = new Date(timestampStr).getTime();
    return this.transactions.find(t => {
      if (t.terminal_id !== terminalId) return false;
      if (Math.abs(t.amount - amount) > 0.001) return false;
      const txTime = new Date(t.transaction_time).getTime();
      const diffMinutes = Math.abs(targetTime - txTime) / (1000 * 60);
      return diffMinutes <= 15;
    });
  }

  public recordTransaction(
    data: Omit<TransactionRecord, 'id' | 'created_at' | 'updated_at' | 'recorded_at'>,
    actor: UserProfile
  ): TransactionRecord {
    // 1. Mandatory business rule: Check for duplicate external reference
    if (data.external_reference && this.isDuplicateReference(data.external_reference)) {
      // Trigger an operational alert
      this.createAlert({
        severity: 'critical',
        title: 'DUPLICATE TRANSACTION REFERENCE BLOCKED',
        description: `Blocked entry: Reference '${data.external_reference}' is already registered in the system.`,
        related_entity_type: 'transaction',
        related_entity_id: data.terminal_id,
        related_entity_label: data.external_reference
      });

      throw new Error(`DUPLICATE TRANSACTION REFERENCE: The reference '${data.external_reference}' already exists.`);
    }

    // 2. Validate terminal status
    const terminal = this.getTerminalById(data.terminal_id);
    if (!terminal) throw new Error('Terminal not found');
    if (terminal.status === 'retired') {
      throw new Error('Retired terminals cannot record new transactions.');
    }
    if (terminal.status === 'lost') {
      throw new Error('Lost terminals cannot record new transactions.');
    }

    const company = this.getCompanyById(data.company_id);
    const merchant = this.getMerchantById(data.merchant_id);

    const now = new Date().toISOString();
    const patternDuplicate = this.hasDuplicatePattern(data.terminal_id, data.amount, data.transaction_time || now);

    const newTx: TransactionRecord = {
      ...data,
      id: `tx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      company_name: company?.name || data.company_name,
      merchant_name: merchant?.merchant_name || data.merchant_name,
      terminal_name: terminal.terminal_name,
      operator_name: actor.full_name,
      recorded_at: now,
      transaction_time: data.transaction_time || now,
      is_duplicate_warning: !!patternDuplicate,
      created_at: now,
      updated_at: now
    };

    // If pattern duplicate exists (same terminal, same amount within 15 min), flag warning alert
    if (patternDuplicate) {
      this.createAlert({
        severity: 'warning',
        title: 'Potential Repeated Transaction Pattern',
        description: `Terminal ${terminal.terminal_identifier} recorded identical amount (${data.currency} ${data.amount}) within 15 minutes of # ${patternDuplicate.external_reference}.`,
        related_entity_type: 'transaction',
        related_entity_id: newTx.id,
        related_entity_label: newTx.external_reference
      });
    }

    this.transactions.unshift(newTx);
    this.save(STORAGE_KEYS.TRANSACTIONS, this.transactions);

    // Update terminal's last_seen_at
    terminal.last_seen_at = now;
    this.save(STORAGE_KEYS.TERMINALS, this.terminals);

    // Log Activity
    this.logActivity({
      type: 'transaction_recorded',
      terminal_id: terminal.id,
      terminal_name: terminal.terminal_name,
      company_id: terminal.company_id,
      company_name: terminal.company_name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} recorded ${newTx.transaction_type} #${newTx.external_reference} (${newTx.currency} ${newTx.amount.toFixed(2)})`
    });

    // Log Audit
    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'transaction_recorded',
      entity: 'transaction',
      entity_id: newTx.id,
      description: `Recorded transaction reference ${newTx.external_reference}`,
      metadata: {
        terminal_id: newTx.terminal_id,
        terminal_identifier: terminal.terminal_identifier,
        amount: newTx.amount,
        currency: newTx.currency,
        type: newTx.transaction_type,
        status: newTx.status
      }
    });

    this.notify();
    return newTx;
  }

  public updateTransactionStatus(id: string, status: TransactionStatus, actor: UserProfile, reason?: string): TransactionRecord {
    const index = this.transactions.findIndex(t => t.id === id);
    if (index === -1) throw new Error('Transaction not found');

    const old = this.transactions[index];
    const updated: TransactionRecord = {
      ...old,
      status,
      updated_at: new Date().toISOString()
    };

    this.transactions[index] = updated;
    this.save(STORAGE_KEYS.TRANSACTIONS, this.transactions);

    this.logActivity({
      type: 'transaction_reviewed',
      terminal_id: updated.terminal_id,
      terminal_name: updated.terminal_name,
      company_id: updated.company_id,
      company_name: updated.company_name,
      user_id: actor.id,
      user_name: actor.full_name,
      description: `${actor.full_name} marked transaction #${updated.external_reference} as ${status}${reason ? `: ${reason}` : ''}`
    });

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'transaction_status_changed',
      entity: 'transaction',
      entity_id: updated.id,
      description: `Transaction ${updated.external_reference} status changed to ${status}`,
      metadata: { old_status: old.status, new_status: status, reason }
    });

    this.notify();
    return updated;
  }

  // ==========================================
  // LOCATIONS
  // ==========================================
  public getLocations(): Location[] {
    return [...this.locations];
  }

  public getLocationById(id: string): Location | undefined {
    return this.locations.find(l => l.id === id);
  }

  public createLocation(data: Omit<Location, 'id' | 'created_at' | 'updated_at'>, actor: UserProfile): Location {
    const company = this.getCompanyById(data.company_id);
    const now = new Date().toISOString();
    const newLocation: Location = {
      ...data,
      id: `loc_${Date.now()}`,
      company_name: company?.name || data.company_name,
      created_at: now,
      updated_at: now
    };

    this.locations.unshift(newLocation);
    this.save(STORAGE_KEYS.LOCATIONS, this.locations);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'location_created',
      entity: 'location',
      entity_id: newLocation.id,
      description: `Created location '${newLocation.name}' (${newLocation.city})`,
      metadata: { ...newLocation }
    });

    this.notify();
    return newLocation;
  }

  public updateLocation(id: string, data: Partial<Location>, actor: UserProfile): Location {
    const index = this.locations.findIndex(l => l.id === id);
    if (index === -1) throw new Error('Location not found');

    const old = this.locations[index];
    const updated: Location = {
      ...old,
      ...data,
      updated_at: new Date().toISOString()
    };

    this.locations[index] = updated;
    this.save(STORAGE_KEYS.LOCATIONS, this.locations);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'location_updated',
      entity: 'location',
      entity_id: updated.id,
      description: `Updated location '${updated.name}'`,
      metadata: { before: old, after: updated }
    });

    this.notify();
    return updated;
  }

  // ==========================================
  // USERS
  // ==========================================
  public getUsers(): UserProfile[] {
    return [...this.users];
  }

  public getUserById(id: string): UserProfile | undefined {
    return this.users.find(u => u.id === id);
  }

  public createUser(data: Omit<UserProfile, 'id' | 'created_at' | 'updated_at'>, actor: UserProfile): UserProfile {
    const exists = this.users.find(u => u.email.toLowerCase() === data.email.trim().toLowerCase());
    if (exists) {
      throw new Error(`User with email '${data.email}' already exists.`);
    }

    const company = data.company_id ? this.getCompanyById(data.company_id) : undefined;
    const now = new Date().toISOString();
    const newUser: UserProfile = {
      ...data,
      id: `user_${Date.now()}`,
      company_name: company?.name || data.company_name,
      created_at: now,
      updated_at: now
    };

    this.users.unshift(newUser);
    this.save(STORAGE_KEYS.USERS, this.users);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'user_created',
      entity: 'user',
      entity_id: newUser.id,
      description: `Created operator profile '${newUser.full_name}' with role ${newUser.role}`,
      metadata: { ...newUser }
    });

    this.notify();
    return newUser;
  }

  public updateUser(id: string, data: Partial<UserProfile>, actor: UserProfile): UserProfile {
    const index = this.users.findIndex(u => u.id === id);
    if (index === -1) throw new Error('User not found');

    const old = this.users[index];
    const company = data.company_id ? this.getCompanyById(data.company_id) : undefined;

    const updated: UserProfile = {
      ...old,
      ...data,
      company_name: company ? company.name : (data.company_name || old.company_name),
      updated_at: new Date().toISOString()
    };

    this.users[index] = updated;
    this.save(STORAGE_KEYS.USERS, this.users);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'user_updated',
      entity: 'user',
      entity_id: updated.id,
      description: `Updated profile for '${updated.full_name}'`,
      metadata: { before: old, after: updated }
    });

    this.notify();
    return updated;
  }

  // ==========================================
  // ALERTS
  // ==========================================
  public getAlerts(): AlertItem[] {
    return [...this.alerts];
  }

  public createAlert(data: Omit<AlertItem, 'id' | 'created_at' | 'status'>): AlertItem {
    const newAlert: AlertItem = {
      ...data,
      id: `alt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      status: 'open',
      created_at: new Date().toISOString()
    };
    this.alerts.unshift(newAlert);
    this.save(STORAGE_KEYS.ALERTS, this.alerts);
    this.notify();
    return newAlert;
  }

  public acknowledgeAlert(id: string, actor: UserProfile): AlertItem {
    const alert = this.alerts.find(a => a.id === id);
    if (!alert) throw new Error('Alert not found');

    alert.status = 'acknowledged';
    alert.acknowledged_by = actor.full_name;
    alert.acknowledged_at = new Date().toISOString();

    this.save(STORAGE_KEYS.ALERTS, this.alerts);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'alert_acknowledged',
      entity: 'alert',
      entity_id: alert.id,
      description: `Acknowledged alert: '${alert.title}'`
    });

    this.notify();
    return alert;
  }

  public resolveAlert(id: string, actor: UserProfile): AlertItem {
    const alert = this.alerts.find(a => a.id === id);
    if (!alert) throw new Error('Alert not found');

    alert.status = 'resolved';
    alert.resolved_by = actor.full_name;
    alert.resolved_at = new Date().toISOString();

    this.save(STORAGE_KEYS.ALERTS, this.alerts);

    this.logAudit({
      user_id: actor.id,
      user_name: actor.full_name,
      user_email: actor.email,
      user_role: actor.role,
      action: 'alert_resolved',
      entity: 'alert',
      entity_id: alert.id,
      description: `Resolved operational alert: '${alert.title}'`
    });

    this.notify();
    return alert;
  }
}

export const storageService = new StorageService();
