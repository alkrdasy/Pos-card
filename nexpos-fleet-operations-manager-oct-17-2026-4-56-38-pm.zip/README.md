# NexPOS Fleet & Operations Platform

> **Enterprise POS Fleet, Merchant Hierarchy, and Transaction Operations Management System**

NexPOS Fleet is a centralized, audit-friendly SaaS management platform designed for businesses operating fleets of point-of-sale (POS) terminals across multiple parent companies, acquiring merchant outlets, physical locations, and field operators.

---

## 1. Project Overview & Vision

Managing 40+ POS terminals across 8 merchants, 20 retail sites, and multiple field employees via spreadsheets and messaging apps creates massive operational risk, missing hardware tracking, and reconciliation blind spots.

NexPOS establishes transparent operational governance:
```
COMPANY
  └── MERCHANTS (MID)
        └── LOCATIONS / OUTLETS
              └── POS TERMINALS (TID & Serial)
                    └── CUSTODIAN / ASSIGNED OPERATOR
                          ├── OPERATIONAL ACTIVITY LOGS
                          ├── AUTHORIZED TRANSACTION RECORDS
                          └── IMMUTABLE AUDIT TRAIL
```

### Important Compliance & Operational Boundary
NexPOS is an **operational management platform**. It is designed to make device status, custody, and transaction receipts **more transparent, auditable, and accountable**.
- It does **NOT** tamper with cardholder data or bypass fraud/risk systems.
- It enforces strict **duplicate transaction reference detection** to prevent accidental double-billing and data corruption.
- It strictly enforces **PCI-DSS data boundaries**: Raw card numbers (PAN), CVVs, and magnetic stripes are never stored or exposed; only safe masked tokens (e.g. `VISA ···· 4821`) and slip references are retained.

---

## 2. Core Features

1. **Operations Dashboard**:
   - Live KPI cards: Active POS Terminals, Today's Transactions, Gross Settled Volume, Operational Alerts, Companies, Merchants, Operators, and Pending Reviews.
   - Interactive SVG transaction volume chart by day with tooltip inspection.
   - Device fleet health distribution bar (Active, Maintenance, Inactive, Lost, Retired).
   - Global Company Scope filter for multi-tenant isolation.
   - Quick Action strip (+ Record Transaction, + Log Activity, + Add Terminal, + Add Merchant, + Add Company).

2. **POS Terminals Fleet Management**:
   - Centralized hardware inventory: TID, Serial Number, Provider (Ingenico, Verifone, PAX, Sunmi, Castles, Clover), Model, Location, Owner, Assigned User, and Status.
   - Uniqueness enforcement: TID and Hardware Serial Number validations prevent duplicate hardware registrations.
   - Responsive design: Full-density tabular data table on desktop, responsive card layout on mobile.
   - Deep-dive Terminal view with 5 distinct operational tabs:
     - Basic Information & Hardware Credentials
     - Chronological Activity Feed
     - Transaction Ledger for the terminal
     - Custodial Assignment History (permanent historical records)
     - Immutable Audit Trail

3. **Transaction Records & Duplicate Prevention**:
   - Records authorized POS slip references, amount, currency, transaction type (`sale`, `refund`, `void`, `adjustment`), timestamp, and operator attribution.
   - **Real-Time Duplicate Prevention**: Entering an existing slip reference flags `"DUPLICATE TRANSACTION REFERENCE"` in real time and blocks creation.
   - Pattern duplicate warnings: Flags transactions on the same terminal with identical amounts within a 15-minute window.
   - Supervisory review workflow (`completed`, `under_review`, `cancelled`).

4. **Temporal Custody & Assignment History**:
   - Assign or transfer terminal responsibility to operators.
   - Closes prior assignment with `unassigned_at` timestamp and preserves full custody history.

5. **Operational Alerts Center**:
   - Severity tiers: Critical, Warning, Info.
   - Automatic triggers: Duplicate transaction reference attempts, inactive terminal heartbeat (>48h), missing operator assignments, hardware maintenance.
   - Lifecycle workflow: Open → Acknowledged → Resolved with audit log tracking.

6. **Companies, Merchants & Locations**:
   - Hierarchical data model connecting corporate registrations (CR), acquiring MIDs, and branch facilities.

7. **Omnisearch & Command Palette**:
   - Trigger with `⌘K`, `Ctrl+K`, or `/`.
   - Omnisearch across all terminals, transactions, merchants, companies, locations, and quick actions.

8. **Compliance & Export Reporting**:
   - Pre-built reports: Terminal Inventory Report, Transaction Reconciliation Report, Company Volume Report, Operator Custody Report.
   - RFC4180-compliant CSV downloads and browser-native print layout.

9. **Immutable Audit Trail**:
   - Append-only audit log capturing actor name, role, email, timestamp, action, entity ID, IP address, and JSON metadata changes.

10. **Batch CSV Import**:
    - Import Terminals, Companies, Merchants, and Locations via CSV.
    - Downloadable CSV templates provided.
    - Pre-import validation engine reporting Valid Rows, Invalid Rows, and Duplicate Rows.

11. **Dark & Light Mode**:
    - Full color token compensation across both themes with local storage persistence.

---

## 3. Technology Stack

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Motion
- **Icons**: Lucide React
- **Architecture**: Domain-driven service architecture with reactive local database engine and Supabase PostgreSQL migration layer
- **Styling**: Anti-slop enterprise aesthetic inspired by Linear and Stripe (zero-pill typography, tabular figures, single-elevation surfaces)
- **Database / Backend**: PostgreSQL schema with Row-Level Security (RLS) policies and Supabase migration script

---

## 4. Database Schema & Tables

The schema is located at `supabase/migrations/20250101000000_init_pos_fleet.sql` and includes:

| Table | Primary Purpose |
|---|---|
| `companies` | Corporate parent business entities and commercial registration (CR) numbers. |
| `merchants` | Merchant trade names, category classifications, and Acquiring Merchant IDs (MIDs). |
| `terminals` | Hardware assets, models, providers, unique TIDs, unique serial numbers, statuses. |
| `assignments` | Historical operator custody records with `assigned_at` and `unassigned_at` timestamps. |
| `locations` | Physical branch sites, addresses, coordinates, and site supervisors. |
| `profiles` | Users and operator credentials with RBAC roles (`super_admin`, `admin`, `operator`, `viewer`). |
| `transaction_records` | Operational transaction receipts with unique external references, amounts, and masked tokens. |
| `activity` | Chronological operational events and hardware status transitions. |
| `alerts` | System exception flags, duplicate alerts, and maintenance tracking. |
| `audit_logs` | Immutable, append-only compliance audit trail. |

### Indexes
- Performance indexes on `terminals.terminal_identifier`, `terminals.serial_number`, `terminals.status`, `terminals.company_id`.
- Indexes on `transaction_records.external_reference`, `transaction_records.transaction_time`, `transaction_records.terminal_id`.
- Indexes on `audit_logs.created_at` and `audit_logs.user_id`.

---

## 5. Authentication & Role-Based Access Control (RBAC)

The platform supports 4 distinct user roles:

1. **Super Admin** (`admin@example.com` - Karim Mansour):
   - Full global control: create/archive companies, configure system settings, manage users, reassign terminals, view audit trail.
2. **Admin** (`nadia.admin@example.com` - Nadia El-Sayed):
   - Company fleet control: manage assigned companies, register terminals, assign operators, view reports.
3. **Operator** (`operator@example.com` - Ahmed Hassan):
   - Field operations: view assigned terminals, record authorized transaction receipts, log maintenance activity.
4. **Viewer** (`viewer@example.com` - Sara Tawfik):
   - Read-only access to authorized terminals and reports.

*Tip: Use the **Role Persona** switcher in the top navigation bar to test the application under any role with one click.*

---

## 6. Local Development & Installation

### Prerequisites
- Node.js (v18+)
- npm or bun

### Setup
```bash
# Clone the repository
git clone <repo-url>
cd nexpos-fleet-operations

# Install dependencies
npm install

# Copy environment template
cp .env.example .env

# Start development server
npm run dev
```

Open `http://localhost:3000` in your browser.

---

## 7. Supabase Database Setup

1. Create a new project in your [Supabase Dashboard](https://supabase.com).
2. Navigate to the **SQL Editor** in the Supabase Dashboard.
3. Copy the contents of `supabase/migrations/20250101000000_init_pos_fleet.sql` and run the query.
4. Copy the contents of `supabase/seed.sql` to populate initial demo records.
5. In your project settings, copy your **Project URL** and **Anon Key** into your `.env` file:
   ```env
   NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
   SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
   ```

---

## 8. Deployment to Vercel

1. Push your repository to GitHub or GitLab.
2. Log in to [Vercel](https://vercel.com) and click **"Add New Project"**.
3. Import the repository.
4. Add the environment variables from `.env.example` in the Vercel project settings:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Click **Deploy**. Vercel will build the Vite/React application and serve it globally with edge CDN caching.

---

## 9. Security & Compliance Safeguards

- **Zero Cardholder Data Storage**: No magnetic stripes, CVVs, or full PANs are ever collected, transmitted, or stored.
- **Server & Storage Authorization**: All mutations are validated against user role permissions before persisting.
- **Append-Only Auditing**: Audit logs are generated automatically on every write operation and cannot be modified or deleted via UI controls.
- **Duplicate Collision Detection**: Strict uniqueness checks on `external_reference`, `terminal_identifier`, and `serial_number`.

---

## 10. License

Apache 2.0. Built for enterprise POS fleet and operations management.
